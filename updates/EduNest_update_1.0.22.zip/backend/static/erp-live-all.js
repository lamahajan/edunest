/* Live everywhere: when another PC saves marks, fee structure, class setup, timetable, exam schedule, concessions, fee imposition, teachers ... this PC
   loads the change into the page's own data at once (no reload, no "click to refresh") and redraws the open screen when that is safe.
   erp-sync.js calls the functions registered below (ERP.liveFn); if one fails, the old "refresh when safe" path still runs.
   Rules that protect typed work:
   - Mark Entry: only boxes the teacher has NOT touched follow the server; a typed mark stays until Save.
   - Attendance: a mark the teacher changed (not yet saved) stays; every other student follows the server.
   - A screen is redrawn in place (open windows stay open) only when the cursor is not inside a box and nobody has typed / clicked for 1.5 seconds. */
(function () {
  'use strict';
  var lastAct = Date.now();
  ['keydown', 'input', 'mousedown', 'touchstart'].forEach(function (ev) { document.addEventListener(ev, function () { lastAct = Date.now(); }, true); });
  function has(n) { return typeof window[n] === 'function'; }
  function editing() { var a = document.activeElement; return !!a && (/^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName) || a.isContentEditable); }   // cursor is inside a box
  function clone(o) { try { return JSON.parse(JSON.stringify(o)); } catch (e) { return {}; } }

  // ---- 1. load a changed setting into the page's own object, in place (the page keeps using the same object)
  function put(target, text) {
    var n = JSON.parse(text || 'null');
    if (Array.isArray(target)) { if (!Array.isArray(n)) return false; target.length = 0; Array.prototype.push.apply(target, n); return true; }
    if (!n || typeof n !== 'object' || Array.isArray(n)) return false;
    Object.keys(n).forEach(function (k) { target[k] = n[k]; });   // whole top-level fields are replaced, the object itself stays
    return true;
  }
  var STORES = {
    eacademics_acad:      function () { return ACAD; },
    eacademics_feestruct: function () { return FEESTRUCT; },
    eacademics_feeplan:   function () { return FEEPLAN; },
    eacademics_conc2:     function () { return CONC; },
    eacademics_tt:        function () { return TT; },
    eacademics_exam:      function () { return EX; },
    eacademics_teachers:  function () { return TEACH; },
    eacademics_feeimp:    function () { return FI; },
    eacademics_classes:   function () { return CLASSES; },
    eacademics_tcfg:      function () { return TCFG; }
  };
  var AFTER = {
    eacademics_acad: function (before) { meMerge(before, ACAD); },
    eacademics_feestruct: function () { try { FEESTRUCT.heads.forEach(function (h) { if (h.route === undefined) h.route = /transport/i.test(h.name); if (h.route) h.all = false; }); } catch (e) {} }
  };
  function register() {
    if (!window.ERP || !ERP.liveFn) return false;
    Object.keys(STORES).forEach(function (k) {
      ERP.liveFn[k] = function (text) {
        var target = STORES[k](), before = k === 'eacademics_acad' ? clone(target) : null;
        if (!put(target, text)) return false;
        if (AFTER[k]) AFTER[k](before);
        ask(); return true;
      };
    });
    return true;
  }

  // ---- 2. Mark Entry: update the boxes the teacher has not touched, keep everything typed
  function meMerge(oldA, newA) {
    try {
      if (typeof curPage === 'undefined' || curPage !== 'markEntry' || typeof meSt === 'undefined' || !meSt.rows || !meSt.rows.length) return;
      var S = meSt, t = S.term && S.term.id, o, n;
      if (S.mode === 'S') {
        o = ((oldA.mkdata || {})[t] || {})[S.code] || {}; n = ((newA.mkdata || {})[t] || {})[S.code] || {};
        S.rows.forEach(function (r, i) {
          S.subs.forEach(function (x, j) {
            var ov = (o[r.adm] || {})[x.name], nv = (n[r.adm] || {})[x.name], os = ov === undefined ? '' : String(ov), ns = nv === undefined ? '' : String(nv);
            if (os === ns || String(r.vals[j]) !== os) return;       // unchanged elsewhere, or the teacher typed something different here: leave it
            var el = document.querySelector('.me-in[data-i="' + i + '"][data-j="' + j + '"]');
            if (el) { el.value = ns; meSet(i, j, el); } else r.vals[j] = ns;
          });
        });
      } else if (S.mode === 'C' && S.area) {
        o = ((oldA.cogr || {})[t] || {})[S.area.id] || {}; n = ((newA.cogr || {})[t] || {})[S.area.id] || {};
        S.rows.forEach(function (r, i) {
          var os = o[r.adm] || '', ns = n[r.adm] || '';
          if (os === ns || String(r.vals[0]) !== os) return;
          r.vals[0] = ns; var el = document.querySelector('.me-g[data-i="' + i + '"]'); if (el) el.value = ns;
        });
      }
    } catch (e) { console.warn(e); }
  }

  // ---- 3. redraw the open screen when it is safe (screens that only show data; screens with typed work are left alone)
  var REDRAW = {
    dashboard:      function () { if (has('dashRefresh')) dashRefresh(); },
    feeReceipt:     function () { if (typeof rc === 'undefined' || (rc.mode === 'new' && rc.adm)) return; if (rc.mode === 'view') refreshReceipt(); else rcRender(); },
    ledger:         function () { if (typeof rc !== 'undefined' && rc.adm && has('lgRender')) lgRender(); },
    attendanceDesk: function () { if (typeof att !== 'undefined' && !Object.keys(att.dirty || {}).length) attRender(); },
    markRegister:   function () { if (typeof mrAll !== 'undefined' && mrAll.cols && mrAll.cols.length) mrView(); },
    reports:        function () { if (typeof rpState !== 'undefined' && rpState.out && has('rpRun')) rpRun(); },
    examSchedule:   function () { if (has('exBody')) exBody(); },
    timetable:      function () { if (has('ttBody')) ttBody(); },
    promotion:      function () { if (has('prRender')) prRender(); },
    concession:     function () { if (has('ccSideRefresh')) ccSideRefresh(); }
  };
  var want = false, tries = 0, tk = null;
  function ask() { want = true; tries = 0; if (!tk) tk = setInterval(tick, 700); }
  function tick() {
    if (!want || ++tries > 900) { want = false; clearInterval(tk); tk = null; return; }
    if (editing() || Date.now() - lastAct < 1500) return;   // wait until the cursor is out of every box and nobody is typing / clicking (a window that is open stays open: the screen behind it is simply redrawn)
    want = false; clearInterval(tk); tk = null;
    try { var f = typeof curPage !== 'undefined' ? REDRAW[curPage] : null; if (f) f(); } catch (e) { console.warn(e); }
  }
  window.addEventListener('erp-adm', ask);                     // a student changed on another PC: reports, dues, ledger, mark register follow
  window.addEventListener('erp-att', function () {              // attendance: erp-att-live.js keeps the "Mark" tab exact; the report tab is redrawn here
    try { if (typeof curPage !== 'undefined' && curPage === 'attendanceDesk' && att.tab !== 'mark') ask(); else if (curPage === 'dashboard') ask(); } catch (e) {}
  });

  if (!register()) { var n = 0, iv = setInterval(function () { if (register() || ++n > 40) clearInterval(iv); }, 250); }
})();
