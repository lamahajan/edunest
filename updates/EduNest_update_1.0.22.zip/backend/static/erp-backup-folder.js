/* Setup > School Setup > "Backup folder": where the school server keeps its backups (administrator only). The card itself is part of the ERP
   page (build_frontend.py); this file fills it in and handles Test / Save / Backup now. */
(function () {
  'use strict';
  var $ = function (id) { return document.getElementById(id); };
  function api(method, url, body) {
    return fetch('/api/sync/' + url, { method: method, headers: { 'Authorization': 'Token ' + localStorage.getItem('erp_token'), 'Content-Type': 'application/json' }, body: body === undefined ? undefined : JSON.stringify(body) })
      .then(function (r) { return { status: r.status, headers: r.headers, json: function () { return r.json().catch(function () { return {}; }); } }; });
  }
  function msg(text, bad) { var n = $('bkDirInfo'); if (n) { n.textContent = text; n.className = 'text-xs mt-2 ' + (bad ? 'text-red-600' : 'text-gray-600 dark:text-gray-300'); } }
  function size(b) { return b == null ? '?' : b >= 1073741824 ? (b / 1073741824).toFixed(1) + ' GB' : (b / 1048576).toFixed(0) + ' MB'; }
  function show(info) {
    $('bkDir').value = info.custom ? info.folder : '';
    msg('Backups go to: ' + info.folder + (info.custom ? '' : ' (the program\'s own folder)') + '. ' + info.count + ' backup' + (info.count === 1 ? '' : 's') + ' there' +
        (info.last ? ', the latest ' + info.last.name + ' (' + info.last.time + ', ' + size(info.last.size) + ')' : '') + '. Free space: ' + size(info.free_bytes) + '.' +
        (info.reachable ? '' : ' This folder cannot be reached right now (drive not plugged in?): backups will go to the program\'s own folder until it is back.'), !info.reachable);
  }
  window.bkFolderFill = function () {
    if (!$('bkDir')) return;
    if (!localStorage.getItem('erp_token')) return msg('Please log in to the ERP first.', true);
    api('GET', 'backup-folder/').then(function (r) {
      if (r.status === 403) { msg('Only an administrator can see or change the backup folder.', true); return; }
      return r.json().then(function (j) { if (j.info) show(j.info); else msg('Could not read the backup folder (HTTP ' + r.status + ').', true); });
    });
  };
  window.bkFolderAct = function (act) {
    var path = $('bkDir').value.trim();
    if (act === 'now') {
      msg('Making the backup ... (this can take a minute)');
      return api('POST', 'backup/').then(function (r) {
        if (r.status === 403) return msg('Only an administrator can take a backup.', true);
        if (r.status !== 200) return r.json().then(function (j) { msg('Backup failed: ' + (j.error || 'the server said ' + r.status), true); });
        var warn = r.headers.get('X-Backup-Warning');
        msg('Backup saved: ' + r.headers.get('X-Backup-Saved') + (warn ? '. ' + warn : ''), !!warn);
      });
    }
    msg(act === 'test' ? 'Testing ...' : 'Saving ...');
    api('POST', 'backup-folder/', { path: path, test: act === 'test' }).then(function (r) {
      r.json().then(function (j) {
        if (r.status === 403) return msg('Only an administrator can change the backup folder.', true);
        if (!j.ok) return msg(j.error || 'The folder was not accepted.', true);
        if (act === 'test') return msg('This folder works: it can be created and written to.');
        show(j.info); var n = $('bkDirInfo'); n.textContent = 'Saved. ' + n.textContent;
      });
    });
  };
})();

/* Setup > School Setup > Backup: what goes into a backup (photos / documents every time and / or on the last date of each month). */
(function () {
  'use strict';
  var $ = function (id) { return document.getElementById(id); };
  function size(b) { return b >= 1073741824 ? (b / 1073741824).toFixed(1) + ' GB' : (b / 1048576).toFixed(0) + ' MB'; }
  function call(method, body) {
    return fetch('/api/sync/backup-options/', { method: method, headers: { 'Authorization': 'Token ' + localStorage.getItem('erp_token'), 'Content-Type': 'application/json' }, body: body === undefined ? undefined : JSON.stringify(body) })
      .then(function (r) { return r.json().catch(function () { return {}; }).then(function (j) { return { status: r.status, j: j }; }); });
  }
  function info(text, bad) { var n = $('bkOptInfo'); if (n) { n.textContent = text; n.className = 'text-xs mt-1 ' + (bad ? 'text-red-600' : 'text-gray-600 dark:text-gray-300'); } }
  function show(o) {
    $('bkMediaEvery').checked = !!o.media_every; $('bkMediaMonth').checked = !!o.media_monthend;
    var t = 'Photos & documents on this server: ' + o.media_files + ' file' + (o.media_files === 1 ? '' : 's') + ', ' + size(o.media_bytes) + '. ' +
      (o.month_end_today ? 'Today is the last date of the month. ' : '') + 'A backup taken now ' + (o.media_now ? 'INCLUDES' : 'does NOT include') + ' photos & documents.';
    if (!o.media_every && !o.media_monthend) t += ' Photos & documents are never backed up while both boxes are off (only the database).';
    info(t, !o.media_every && !o.media_monthend);
  }
  window.bkOptFill = function () {
    if (!$('bkMediaEvery')) return;
    if (!localStorage.getItem('erp_token')) return info('Please log in to the ERP first.', true);
    call('GET').then(function (r) { if (r.status === 403) return info('Only an administrator can see or change this.', true); if (r.j.options) show(r.j.options); else info('Could not read the backup options (HTTP ' + r.status + ').', true); });
  };
  window.bkOptSave = function () {
    info('Saving ...');
    call('POST', { media_every: $('bkMediaEvery').checked, media_monthend: $('bkMediaMonth').checked }).then(function (r) {
      if (r.status === 403) return info('Only an administrator can change this.', true);
      if (r.j.options) { show(r.j.options); var n = $('bkOptInfo'); n.textContent = 'Saved. ' + n.textContent; } else info('Could not save (HTTP ' + r.status + ').', true);
    });
  };
})();
