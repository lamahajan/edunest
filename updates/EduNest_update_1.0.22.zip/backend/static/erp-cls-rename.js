/* Renaming a class (Setup > Classes) now renames it everywhere in this session, so nothing is left pointing at the old name:
   students (class and admission class), fee structure, concession rates, attendance, timetable, exam date sheet, subjects / marks / assessment
   setup, co-scholastic areas, fee imposition, concession requests and gate passes. Past sessions keep their own class names.
   Works through the Save button of the class window: it remembers each row's original name, asks once, saves, then updates the linked data
   and reloads this screen. Other PCs receive every changed record through the normal live sync. */
(function () {
  'use strict';
  function rekey(o, fn) {                                  // rename the keys of an object in place (order kept; swaps like A<->B work)
    if (!o || typeof o !== 'object' || Array.isArray(o)) return 0;
    var ks = Object.keys(o), ent = ks.map(function (k) { return [fn(k), o[k], k]; }), n = ent.filter(function (e) { return e[0] !== e[2]; }).length;
    if (!n) return 0;
    ks.forEach(function (k) { delete o[k]; }); ent.forEach(function (e) { o[e[0]] = e[1]; });
    return n;
  }
  function cascade(map, old) {
    var streams = {}; old.forEach(function (c) { streams[c.name] = c.streams || []; });
    var own = Object.prototype.hasOwnProperty;
    function ck(k) {                                       // "6th"  or  "11th - Science"  ->  new name
      if (typeof k !== 'string') return k;
      if (own.call(map, k)) return map[k];
      for (var o in map) if (own.call(map, o) && k.indexOf(o + ' - ') === 0 && streams[o].indexOf(k.slice(o.length + 3)) >= 0) return map[o] + k.slice(o.length);
      return k;
    }
    function comp(s) {                                     // "6th-A" (class-section text kept on requests and passes)
      if (typeof s !== 'string') return s;
      for (var o in map) if (own.call(map, o) && s.indexOf(o + '-') === 0 && s.length > o.length + 1) return map[o] + s.slice(o.length);
      return s;
    }
    var total = 0;
    function save(key, obj) { try { localStorage.setItem(key, JSON.stringify(obj)); } catch (e) { console.warn(e); } }
    function step(name, f) { try { var c = f() || 0; total += c; } catch (e) { console.warn('class rename: ' + name, e); } }
    step('students', function () {
      var c = 0; ADM.forEach(function (r) { ['cls', 'admClass'].forEach(function (f) { if (r[f]) { var v = ck(r[f]); if (v !== r[f]) { r[f] = v; c++; } } }); });
      if (c) admPersist(); return c;
    });
    step('fees', function () { var c = rekey(FEESTRUCT.amounts, ck); if (c) save('eacademics_feestruct', FEESTRUCT); return c; });
    step('concession', function () { var c = rekey((CONC.staff || {}).vals, ck) + rekey((CONC.sib || {}).vals, ck); if (c) save('eacademics_conc2', CONC); return c; });
    step('attendance', function () {
      var c = rekey(ATT, function (k) { var p = k.split('|'); if (p.length === 3) { var v = ck(p[1]); if (v !== p[1]) { p[1] = v; return p.join('|'); } } return k; });
      if (c) save('eacademics_att', ATT); return c;
    });
    step('timetable', function () {
      var c = rekey(TT.grid, function (k) { var i = k.lastIndexOf('|'); return i < 0 ? ck(k) : ck(k.slice(0, i)) + k.slice(i); }) + rekey(TT.weekly, ck) + rekey(TT.rules, ck);
      if (c) save('eacademics_tt', TT); return c;
    });
    step('exams', function () { var c = 0; Object.keys(EX.sched || {}).forEach(function (id) { c += rekey(EX.sched[id], ck); }); if (c) save('eacademics_exam', EX); return c; });
    step('academics', function () {
      var c = rekey(ACAD.subjects, ck) + rekey(ACAD.marks, ck) + rekey(ACAD.amap, ck);
      (ACAD.coschol || []).forEach(function (a) { if (Array.isArray(a.classes)) a.classes = a.classes.map(function (k) { var v = ck(k); if (v !== k) c++; return v; }); });
      if (c) acadPersist(); return c;
    });
    function listCls(name, arr, key) { step(name, function () { var c = 0; (arr || []).forEach(function (x) { var v = comp(x.cls); if (v !== x.cls) { x.cls = v; c++; } }); if (c) save(key, arr); return c; }); }
    listCls('fee imposition', FI, 'eacademics_feeimp'); listCls('concession requests', CR, 'eacademics_concreq'); listCls('gate passes', GP, 'eacademics_gp');
    return total;
  }
  function install() {
    if (typeof window.clsFill !== 'function' || typeof window.clsSave !== 'function' || window.clsSave.__ren) return false;
    var oFill = window.clsFill, oSave = window.clsSave;
    window.clsFill = function () { var r = oFill.apply(this, arguments); try { clsDraft.forEach(function (c) { c._orig = c.name; }); } catch (e) {} return r; };   // each row remembers the name it had when the window opened
    window.clsSave = async function () {
      var self = this, args = arguments, old = CLASSES.map(function (c) { return { name: c.name, streams: (c.streams || []).slice() }; }), map = {}, pairs = [];
      clsDraft.forEach(function (c) {
        var nn = String(c.name || '').trim();
        if (c._orig !== undefined && nn && c._orig !== nn && old.some(function (o) { return o.name === c._orig; })) { map[c._orig] = nn; pairs.push('"' + c._orig + '" → "' + nn + '"'); }
      });
      var clash = Object.keys(map).map(function (o) { return map[o]; }).filter(function (nn) { return old.some(function (o) { return o.name === nn; }) && !Object.prototype.hasOwnProperty.call(map, nn); })[0];
      if (clash) return showToast('Class "' + clash + '" already exists. Rename or remove that one first.');
      if (!pairs.length) return oSave.apply(self, args);
      if (typeof SESS_VIEWONLY !== 'undefined' && SESS_VIEWONLY) return oSave.apply(self, args);
      if (!(await rcConfirm('Rename class ' + pairs.join(', ') + '?\n\nStudents, fees, concessions, attendance, timetable, exam schedule and marks setup of this session will be changed to the new name everywhere.'))) return;
      var before = CLASSES; oSave.apply(self, args);
      if (CLASSES === before) return;                      // the class window refused to save (message already shown)
      var n = 0; try { n = cascade(map, old); } catch (e) { console.warn(e); }
      showToast('Class renamed. ' + n + ' linked item' + (n === 1 ? '' : 's') + ' updated. Refreshing...');
      var go = function () { setTimeout(function () { location.reload(); }, 400); };
      if (window.ERP && ERP.flush) ERP.flush().then(go, go); else go();
    };
    window.clsSave.__ren = 1; return true;
  }
  if (!install()) { var t = 0, iv = setInterval(function () { if (install() || ++t > 40) clearInterval(iv); }, 250); }
})();
