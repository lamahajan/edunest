/* Live students: when another PC adds, changes or deletes a student, this PC's Admission screen (form, side tables, "Admission list" window)
   and Attendance screen show it at once - no reload needed. erp-sync.js announces each such change as 'erp-adm'.
   Safe by design: a form that is being typed in (New / Modify) is never overwritten; only the saved record that is open in view mode is refreshed. */
(function () {
  'use strict';
  var timer = null;
  function shown(id) { var p = document.getElementById(id); return !!p && p.offsetParent !== null; }
  function admPage() {
    var cur = String((ad && ad.adm) || ''), i = ADM.findIndex(function (r) { return r.adm === cur; });
    if (adm.mode === 'view' && adm.idx >= 0) {
      if (i < 0) { admNew(); showToast('This student was deleted on another PC'); }
      else admLoad(i);                                      // re-reads the saved record (admLoad draws form + side tables + buttons)
      listRows(); return;
    }
    if (adm.mode === 'modify') {                            // somebody is editing: keep every typed letter, only follow the record's new position
      if (i >= 0) adm.idx = i;
      else { adm.mode = 'new'; adm.idx = -1; showToast('This student was deleted on another PC. Save will add it again.'); }
    } else if (adm.mode === 'new' && cur && ADM.some(function (r) { return r.adm === cur; })) {   // another PC just used the number this form was going to give
      ad.adm = admNextNo();
      var el = document.getElementById('adm_adm'); if (el) el.value = ad.adm;
      if (typeof admStrip === 'function') admStrip();
      showToast('Admission ID ' + cur + ' was just used on another PC. New ID: ' + ad.adm);
    }
    admRenderSide(); admRenderBar(); listRows();
  }
  function listRows() { if (document.getElementById('admListRows')) admListRows(); }   // the "Admission list" window is open: its rows follow too
  function refresh() {
    timer = null;
    try {
      if (shown('pageAdmission') && typeof admStarted !== 'undefined' && admStarted) admPage();
      else if (document.getElementById('admListRows') && typeof admListRows === 'function') admListRows();
      if (shown('pageAttendance') && typeof att !== 'undefined' && typeof attRender === 'function' && !Object.keys(att.dirty || {}).length) attRender();   // a class list never loses a mark the teacher has not saved yet
    } catch (e) { console.warn(e); }
  }
  window.addEventListener('erp-adm', function () { if (!timer) timer = setTimeout(refresh, 150); });   // several students at once = one redraw
})();
