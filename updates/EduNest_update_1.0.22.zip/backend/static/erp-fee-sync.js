/* Online fee payments (UPI-Redirect / DigiFee) <-> ERP, browser part.
   Everything here is EVENT DRIVEN (no clock ticking every few seconds): the ERP's live channel tells this page when data changed
   ('erp-changed') or when the payment queue changed ('erp-events' / feeq). One slow safety timer (10 min) only covers a missed
   message and the date changing at midnight.
   1. When ERP data changes this page works out who owes how much with the ERP's own Dues Report engine (rpDueItems) and sends the list
      to the server, which keeps the cloud Due List equal to it. So parents always see what Reports > Dues Report shows.
   2. Online payments the server has picked up are posted as fee receipts AUTOMATICALLY: this page does exactly what the accountant does
      (opens Fee Receipt, picks the student, the ERP's own default periods / imposed charges / concession come on, Save) - using the ERP's
      own rcSave, so every fee rule applies. The amount may be more or less than the dues: more pays the next months in advance, less pays the
      oldest months first and the rest as a part payment on the next month (imposed charges are always paid in full). The proof of the payment is
      its RRN, which the server has already checked (12 digits, not on another student's receipt). A payment that cannot be placed stays in the
      "N online payments waiting" button for the accountant.
   It waits for a quiet moment (nobody typing, no receipt half-made) and returns to the page the person was on.
   Does nothing when the server has no online-fee setup. */
(function () {
  'use strict';
  var TOKEN = localStorage.getItem('erp_token'), LAST = '', LASTAT = 0, ON = null, QUEUE = {}, DENIED = false;
  function api(method, url, body) {
    return fetch('/api/sync/' + url, { method: method, headers: { 'Authorization': 'Token ' + TOKEN, 'Content-Type': 'application/json' }, body: body === undefined ? undefined : JSON.stringify(body) })
      .then(function (r) { if (r.status === 403) DENIED = true; return r.ok ? r.json() : null; }).catch(function () { return null; });
  }
  var esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };
  function ready() { try { return typeof rpDueItems === 'function' && typeof rpActive === 'function' && typeof RC_STUDENTS !== 'undefined' && typeof SESS !== 'undefined'; } catch (e) { return false; } }
  function latestSession() { try { var a = JSON.parse(localStorage.getItem('eacademics_sessions') || '[]'); return a.length ? a[a.length - 1].id : SESS; } catch (e) { return SESS; } }

  function sendDues() {
    if (!ready() || latestSession() !== SESS) return;                                // dues are for the running session only
    var today = rcToday(), dues = {}, active = rpActive();
    if (!active.length) return;                                                      // nothing loaded yet: never send an empty list
    active.forEach(function (r) {
      var st = RC_STUDENTS[r.adm]; if (!st) return;
      var d = 0; try { d = rpDueItems(r.adm, today).total; } catch (e) { return; }
      if (d > 0) dues[r.adm] = { balance: d, name: st.name || '', cls: (st.cls || r.cls || '') + (st.sec || r.sec ? '-' + (st.sec || r.sec) : ''), mob: st.mobile || '' };
    });
    var sig = JSON.stringify(dues);
    if (sig === LAST && Date.now() - LASTAT < 600000) return;                        // unchanged: tell the server only every 10 minutes
    api('POST', 'fee-dues/', { session: SESS, asOn: today, total: active.length, dues: dues }).then(function (j) { if (j) { LAST = sig; LASTAT = Date.now(); ON = j.on; } });
  }

  // ---- payments waiting to be posted
  var btn;
  function badge(n) {
    if (!btn) {
      btn = document.createElement('button');
      btn.style.cssText = 'position:fixed;left:16px;bottom:16px;z-index:9998;background:#0b57d0;color:#fff;border:0;border-radius:999px;padding:10px 16px;font:600 13px sans-serif;box-shadow:0 2px 10px rgba(0,0,0,.3);cursor:pointer;display:none';
      btn.onclick = openList; document.body.appendChild(btn);
    }
    btn.style.display = n ? 'block' : 'none';
    btn.textContent = '\uD83D\uDCB3 ' + n + ' online payment' + (n === 1 ? '' : 's') + ' waiting';
  }
  function pollTxns() {
    api('GET', 'fee-txns/').then(function (j) {
      if (!j) return; ON = j.on; QUEUE = j.items || {}; badge(Object.keys(QUEUE).length); armAuto(Math.max(0, lastAct + 20500 - Date.now()));
      if (document.getElementById('feeTxnBox')) openList();                          // refresh an open list
    });
  }
  function closeList() { var o = document.getElementById('feeTxnBox'); if (o) o.remove(); }
  function openList() {
    closeList();
    var keys = Object.keys(QUEUE).sort(function (a, b) { return QUEUE[a].paid_at - QUEUE[b].paid_at; });
    var rows = keys.map(function (k) {
      var q = QUEUE[k], t = q.paid_at ? new Date(q.paid_at * 1000).toLocaleString('en-IN') : '';
      return '<tr style="border-top:1px solid #ddd"><td style="padding:6px">' + esc(q.name) + '<br><small>' + esc(q.adm) + ' &middot; ' + esc(q.cls) + '</small></td><td style="padding:6px;text-align:right"><b>\u20B9 ' + Number(q.amount).toLocaleString('en-IN') + '</b></td><td style="padding:6px"><small>' + esc(t) + '<br>Ref ' + esc(q.ref) + '</small>' + (q.hold ? '<br><small style="color:#b3261e">Held: ' + esc(q.hold) + '</small>' : '') + '</td>' +
        '<td style="padding:6px;white-space:nowrap"><button data-k="' + esc(k) + '" data-a="post" style="background:#0b57d0;color:#fff;border:0;border-radius:8px;padding:6px 10px;cursor:pointer">Post receipt</button> <button data-k="' + esc(k) + '" data-a="review" style="background:#eee;border:0;border-radius:8px;padding:6px 10px;cursor:pointer">Review</button></td></tr>';
    }).join('');
    var o = document.createElement('div'); o.id = 'feeTxnBox';
    o.style.cssText = 'position:fixed;inset:0;z-index:9999;background:rgba(0,0,0,.45);display:flex;align-items:center;justify-content:center;padding:12px';
    o.innerHTML = '<div style="background:#fff;color:#111;border-radius:16px;max-width:760px;width:100%;max-height:85vh;overflow:auto;padding:18px;font:14px sans-serif"><div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px"><b style="font-size:16px">Online payments to post</b><button data-a="close" style="border:0;background:none;font-size:20px;cursor:pointer">\u2715</button></div>' +
      (keys.length ? '<table style="width:100%;border-collapse:collapse">' + rows + '</table>' : '<p>Nothing waiting.</p>') +
      '<p style="margin-top:10px;font-size:12px;color:#555">Payments are posted as receipts automatically (more than the dues pays the next months, less is a part payment). These are waiting because they are being posted right now, or because they were held back (RRN problem) or could not be placed. "Post receipt" opens the Fee Receipt screen with the student, UPI and reference filled in: tick the periods and save; the payment closes in the cloud by itself. "Review" sets a payment aside (refund, paid twice).</p></div>';
    o.addEventListener('click', function (e) {
      var a = e.target.getAttribute && e.target.getAttribute('data-a'), k = e.target.getAttribute && e.target.getAttribute('data-k');
      if (e.target === o || a === 'close') return closeList();
      if (a === 'post' && QUEUE[k]) { closeList(); return fill(QUEUE[k]); }
      if (a === 'review' && QUEUE[k]) {
        var why = prompt('Why is this payment being set aside? (refund, paid twice, wrong student ...)'); if (!why) return;
        api('POST', 'fee-txns/' + encodeURIComponent(k) + '/review/', { reason: why }).then(function () { delete QUEUE[k]; badge(Object.keys(QUEUE).length); openList(); });
      }
    });
    document.body.appendChild(o);
  }
  function fill(q) {
    try {
      go('feeReceipt'); rcNew();
      setTimeout(function () {
        rcEl('rcAdm').value = q.adm; rcAdmCommit(q.adm);
        rcEl('rcMode').value = 'UPI'; rcRefSync(true); rcEl('rcRef').value = q.ref;
        showToast('Online payment of \u20B9 ' + Number(q.amount).toLocaleString('en-IN') + ': tick the periods and save');
      }, 250);
    } catch (e) { alert('Open Fee Receipt and enter: ' + q.adm + ', UPI, reference ' + q.ref); }
  }

  // ---- automatic receipts
  var lastAct = Date.now(), busy = false, TRIED = {};
  var autoT = null;
  function hasWork() { return Object.keys(QUEUE).some(function (k) { return (TRIED[k] || 0) < 2 && !QUEUE[k].hold; }); }
  function armAuto(ms) { clearTimeout(autoT); if (hasWork()) autoT = setTimeout(autoPost, ms); }          // one timer, only while a payment is waiting
  ['keydown', 'input', 'mousedown', 'touchstart'].forEach(function (ev) { document.addEventListener(ev, function () { lastAct = Date.now(); if (hasWork()) armAuto(20500); }, true); });
  function typing() { var a = document.activeElement; return !!a && (/^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName) || a.isContentEditable); }
  function midReceipt() { try { return rc.mode === 'new' && !!rc.adm; } catch (e) { return true; } }
  function quiet() { return Date.now() - lastAct > 20000 && !typing() && !midReceipt() && !(window.ERP && ERP.unsaved && ERP.unsaved()); }
  function localDate(sec) { var d = sec ? new Date(sec * 1000) : new Date(); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
  function manual(key, why) { TRIED[key] = 99; console.log('online payment ' + key + ' left for manual posting: ' + why); }
  function finish(prevHash, prevPrint) {
    try { rc.printAfter = prevPrint; } catch (e) {}
    try { rcNew(); if (location.hash !== prevHash) location.hash = prevHash; } catch (e) {}      // blank receipt again; back to where the person was
    busy = false;
  }
  // ---- work out which periods / heads this payment pays, with the ERP's own engine. Returns true, or the reason it must be posted by hand.
  function setP(arr) { rc.blank = false; rc.periods = new Set(arr); rc.recv = {}; rc.extra = []; rc.auto = []; rcAutoExtras(); return rcCalcLive(); }
  function plan(A) {
    var adm = rc.adm, paid = rcPaidMap(adm), num = function (a, b) { return a - b; };
    var all = RC_PERIODS.map(function (p, i) { return i; }).filter(function (i) { return paid[i] === undefined; });
    var sel = Array.from(rc.periods).sort(num);
    if (!adm || !sel.length) return 'no unpaid period for this student';
    var calc = setP(sel);
    if (calc.recv < A - 0.5) {                                                                        // more than the dues: following months in advance
      all.filter(function (i) { return i > sel[sel.length - 1]; }).sort(num).some(function (p) {
        if (setP(sel.concat(p)).recv <= A + 0.5) { sel.push(p); return false; } return true;
      });
    } else if (calc.recv > A + 0.5) {                                                                 // less than the dues: oldest months first
      while (sel.length > 1 && setP(sel).recv > A + 0.5) sel.pop();
    }
    calc = setP(sel);
    if (Math.abs(calc.recv - A) < 0.5) return true;                                                   // whole months, exact
    if (calc.recv < A) {                                                                              // left-over money: part payment on the next month
      var nx = all.filter(function (i) { return i > sel[sel.length - 1]; }).sort(num)[0];
      if (nx === undefined) return 'amount is more than all the fees of the session';
      sel.push(nx); calc = setP(sel);
    }
    var rows = calc.rows, conc = rows.filter(function (r) { return r.key === 'c'; }).reduce(function (t, r) { return t + r.recv; }, 0);
    var budget = A - conc, imposed = rows.filter(function (r) { return /^x/.test(r.key); });
    var need = imposed.reduce(function (t, r) { return t + r.total; }, 0);
    if (budget < need - 0.5) return 'amount is less than the imposed charges';                       // imposed charges are never part-paid
    budget -= need;
    rows.filter(function (r) { return r.key === 'l'; }).concat(rows.filter(function (r) { return /^h/.test(r.key); })).forEach(function (r) {   // late fee, then heads in order
      var v = Math.min(r.total, Math.max(budget, 0)); rc.recv[r.key] = v; budget -= v;
    });
    return Math.abs(rcCalcLive().recv - A) < 0.5 ? true : 'could not split the amount';
  }

  function postOne(key, q) {
    var prevHash = location.hash, prevPrint = true;
    try { prevPrint = rc.printAfter; go('feeReceipt'); rcNew(); } catch (e) { busy = false; return; }
    setTimeout(function () {
      try {
        rcEl('rcDate').value = localDate(q.paid_at);                                               // late fee is worked out for the day it was paid
        rcAdmCommit(q.adm);
        var res = plan(q.amount);
        if (res !== true) { manual(key, res); return finish(prevHash, prevPrint); }
        rcEl('rcMode').value = 'UPI'; rcRefSync(true); rcEl('rcRef').value = q.ref; rcEl('rcNarr').value = 'Online payment ' + q.ref;
        rc.printAfter = false;
        var n = RC_RECEIPTS.length; rcSave();
        var tries = 0, t = setInterval(function () {
          var r = RC_RECEIPTS.length > n ? RC_RECEIPTS[RC_RECEIPTS.length - 1] : null;
          if (r && r.ref === q.ref && r._sid) {                                                    // the server accepted the receipt
            clearInterval(t); delete QUEUE[key]; badge(Object.keys(QUEUE).length);
            api('POST', 'fee-txns/' + encodeURIComponent(key) + '/done/', { voucher: r.v }).then(function () { finish(prevHash, prevPrint); });
          } else if (++tries > 80) { clearInterval(t); manual(key, 'not confirmed'); finish(prevHash, prevPrint); }
        }, 100);
      } catch (e) { manual(key, String(e)); finish(prevHash, prevPrint); }
    }, 300);
  }
  function autoPost() {
    autoT = null;
    if (busy || DENIED || ON !== true || !ready() || latestSession() !== SESS) return;
    if (!quiet()) return armAuto(10000);                                                             // somebody is working: try again a little later
    var key = Object.keys(QUEUE).filter(function (k) { return (TRIED[k] || 0) < 2 && !QUEUE[k].hold; }).sort(function (a, b) { return QUEUE[a].paid_at - QUEUE[b].paid_at; })[0];
    if (!key) return;
    var q = QUEUE[key];
    busy = true; TRIED[key] = (TRIED[key] || 0) + 1;
    api('POST', 'fee-txns/' + encodeURIComponent(key) + '/claim/', {}).then(function (j) { if (!j) { busy = false; return; } postOne(key, q); });
  }
  window.__feeSync = { getQueue: function () { return QUEUE; }, idle: function () { lastAct = 0; }, arm: armAuto, autoPost: autoPost, postOne: postOne, quiet: quiet, setQueue: function (x, on) { QUEUE = x; ON = on; }, tried: TRIED };

  function start() {
    if (!TOKEN) return;
    var wait = setInterval(function () {
      if (!ready()) return; clearInterval(wait);
      pollTxns(); sendDues();
      var dt = null;
      window.addEventListener('erp-changed', function () { if (DENIED) return; clearTimeout(dt); dt = setTimeout(sendDues, 2500); });          // ERP data changed -> new dues
      window.addEventListener('erp-events', function (e) { if (DENIED) return; (e.detail || []).forEach(function (x) { if (x.coll === 'feeq') pollTxns(); }); });   // payment queue changed
      document.addEventListener('visibilitychange', function () { if (!document.hidden && !DENIED) { pollTxns(); sendDues(); } });
      setInterval(function () { if (!document.hidden && !DENIED) { pollTxns(); sendDues(); } }, 600000);                                       // safety net only
    }, 1000);
  }
  start();
})();
