/* Parent App + Teacher App (Firestore), browser part. Server part: backend/sync/cloud_parent.py.
   Like the online-fee due list (erp-fee-sync.js), the numbers come from the ERP's OWN engines on this page, so the app shows what the ERP shows:
     fee   rpDueItems (Dues Report): due, months, period text; paid this session and the last 10 receipts (rpRecAmt)
     att   ATT ('date|cls|sec' -> {adm: P/A/L}): whole session, this month, last 30 days
     teachers  TEACH + USERS (login name, active) + ACAD subjects (subject teacher = every section of that class) + class teacher
   One snapshot of every studying student and teacher is posted to /api/sync/parent-app/ when the ERP data changes (and every 10 minutes);
   the server writes only what changed to Firebase. Does nothing when the Parent App is not set up (Setup > School Setup > Cloud Sync).
   secId = CLASS-SECTION in capitals without spaces (5TH-A, PRENURSERY-B): the same in students/{adm}.secId, the login claims and teachers/{uid}.secs.
   Subject key = subject name in small letters, a-z 0-9 _ only (maths, social_science). */
(function () {
  'use strict';
  var TOKEN = localStorage.getItem('erp_token'), ON = null, LAST = '', LASTAT = 0, DENIED = false;
  function api(method, body) {
    return fetch('/api/sync/parent-app/', { method: method, headers: { 'Authorization': 'Token ' + TOKEN, 'Content-Type': 'application/json' }, body: body === undefined ? undefined : JSON.stringify(body) })
      .then(function (r) { if (r.status === 403) DENIED = true; return r.ok ? r.json() : null; }).catch(function () { return null; });
  }
  function ready() {
    try { return typeof rpDueItems === 'function' && typeof rpActive === 'function' && typeof RC_STUDENTS !== 'undefined' && typeof SESS !== 'undefined' && typeof ATT !== 'undefined' && typeof TEACH !== 'undefined' && typeof acadKeys === 'function'; } catch (e) { return false; }
  }
  function latestSession() { try { var a = JSON.parse(localStorage.getItem('eacademics_sessions') || '[]'); return a.length ? a[a.length - 1].id : SESS; } catch (e) { return SESS; } }
  var norm = function (s) { return String(s || '').toUpperCase().replace(/[^A-Z0-9]/g, ''); };
  function secId(cls, sec) { return norm(cls) + (norm(sec) ? '-' + norm(sec) : ''); }
  function subjKey(name) { var k = String(name || '').toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, ''); return !k ? 'subject' : /^[0-9]/.test(k) ? 's_' + k : k; }
  function ymd(d) { return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }

  function attendance(today) {
    var start = (typeof FEEPLAN !== 'undefined' && FEEPLAN && FEEPLAN.sessStart) || (String(SESS).slice(0, 4) + '-04-01');
    var d30 = new Date(today + 'T00:00:00'); d30.setDate(d30.getDate() - 29); var from30 = ymd(d30), mon = today.slice(0, 7), out = {};
    Object.keys(ATT).forEach(function (k) {
      var d = k.split('|')[0]; if (!d || d < start || d > today) return;
      var marks = ATT[k] || {};
      Object.keys(marks).forEach(function (adm) {
        var v = marks[adm]; if (v !== 'P' && v !== 'A' && v !== 'L') return;
        var o = out[adm] = out[adm] || { s: { P: 0, A: 0, L: 0 }, m: { P: 0, A: 0, L: 0 }, mon: mon, d: {} };
        o.s[v]++; if (d.slice(0, 7) === mon) o.m[v]++; if (d >= from30) o.d[d] = v;
      });
    });
    return out;
  }

  function fees(adm, today) {
    var f = { due: 0, months: 0, period: '', paid: 0, asOn: today, rc: [] };
    try { var x = rpDueItems(adm, today); f.due = Math.max(0, Math.round(x.total)); if (f.due > 0) { f.months = x.per.length; f.period = x.per.length ? rcPeriodText(new Set(x.per)) : ''; } } catch (e) {}
    try {
      var R = RC_RECEIPTS.filter(function (r) { return r.adm === adm && !r.cancelled; }).map(function (r) { return { no: String(r.rno), date: r.date, amt: Math.round(rpRecAmt(r)), mode: r.mode || '' }; });
      f.paid = R.reduce(function (t, r) { return t + r.amt; }, 0);
      f.rc = R.sort(function (a, b) { return String(b.date).localeCompare(String(a.date)) || (+b.no || 0) - (+a.no || 0); }).slice(0, 10);
    } catch (e) {}
    return f;
  }

  function teachers() {
    var users = typeof USERS !== 'undefined' ? USERS : [], out = [];
    TEACH.forEach(function (t) {
      if (!t || !t.name) return;
      var u = users.filter(function (x) { return x.id === t.userId; })[0];
      if (!u || u.active === false || !u.username) return;
      var secs = {}, subj = {}, ct = '', ctSubj = {};
      acadKeys().forEach(function (k) {
        var c = CLASSES.filter(function (x) { return x.name === k.cls; })[0] || {}, sections = (c.sections && c.sections.length) ? c.sections : ['A'];
        acadSubsOf(k.key).forEach(function (s) {
          if (s.teacher !== t.name) return;
          var key = subjKey(s.name); subj[key] = s.name;
          sections.forEach(function (sc) { var id = secId(k.cls, sc), a = secs[id] = secs[id] || []; if (a.indexOf(key) < 0) a.push(key); });
        });
      });
      if (typeof t.classTeacher === 'string' && t.classTeacher) {
        var p = t.classTeacher.split('||'); ct = secId(p[0], p[1]);
        acadKeys().forEach(function (k) { if (k.cls === p[0]) acadSubsOf(k.key).forEach(function (s) { ctSubj[subjKey(s.name)] = s.name; }); });
      }
      out.push({ user: String(u.username).toLowerCase(), name: t.name, mob: t.mobile || '', secs: secs, subj: subj, ct: ct, ctSubj: ctSubj });
    });
    return out;
  }

  function snapshot() {
    var today = rcToday(), active = rpActive(), att = attendance(today), stu = {};
    active.forEach(function (r) {
      if (!r.adm || /[\/\s]/.test(String(r.adm))) return;
      var st = RC_STUDENTS[r.adm] || {};
      stu[r.adm] = {
        name: admName(r) || st.name || '', cls: r.cls || st.cls || '', sec: r.sec || st.sec || '', secId: secId(r.cls || st.cls, r.sec || st.sec), roll: String(r.roll || ''),
        dob: r.dob || '', father: r.father || '', mother: r.mother || '', gender: r.gender || '', addr: [r.addr, r.city].filter(Boolean).join(', '), mob: r.mobile || '',
        fee: fees(r.adm, today), att: att[r.adm] || { s: { P: 0, A: 0, L: 0 }, m: { P: 0, A: 0, L: 0 }, mon: today.slice(0, 7), d: {} }
      };
    });
    return { session: SESS, today: today, school: (typeof SCHOOL !== 'undefined' && SCHOOL && SCHOOL.name) || '', students: stu, teachers: teachers() };
  }

  function send() {
    if (ON !== true || DENIED || !ready() || latestSession() !== SESS) return;            // the running session only
    if (!rpActive().length) return;                                                        // nothing loaded yet: never send an empty list
    var s; try { s = snapshot(); } catch (e) { console.log('parent app snapshot failed', e); return; }
    var sig = JSON.stringify(s);
    if (sig === LAST && Date.now() - LASTAT < 600000) return;
    api('POST', s).then(function (j) { if (j) { LAST = sig; LASTAT = Date.now(); ON = j.on; } });
  }
  window.__parentApp = { snapshot: snapshot, send: send, secId: secId, subjKey: subjKey };

  function start() {
    if (!TOKEN) return;
    api('GET').then(function (j) {
      if (!j || !j.on) return;                                                             // not set up (or no permission): nothing runs
      ON = true;
      var wait = setInterval(function () {
        if (!ready()) return; clearInterval(wait); send();
        var dt = null;
        window.addEventListener('erp-changed', function () { clearTimeout(dt); dt = setTimeout(send, 5000); });
        document.addEventListener('visibilitychange', function () { if (!document.hidden) send(); });
        setInterval(function () { if (!document.hidden) send(); }, 600000);                // safety net (and the new day's attendance)
      }, 1000);
    });
  }
  start();
})();
