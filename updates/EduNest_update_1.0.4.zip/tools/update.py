"""One-click update. Put the new school_erp zip into the  updates  folder and run ERP.bat (option 3).
Your data (data, backups, venv, updates folders) is never touched. A backup is made first."""
import shutil
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
OBSOLETE = ('start.bat', 'restart_server.bat', 'install_autostart.bat', 'remove_autostart.bat', 'backup.bat', 'update.bat', 'cloud_check.bat', 'export_data.bat', 'import_data.bat',
            'organize_media.bat', 'reset_password.bat', 'setup_https.bat', 'to_postgres.bat')
KEEP = {'data', 'backups', 'venv', 'runtime', 'updates', 'update_source.txt'}      # update_source.txt = this school's own update address


def run(args, cwd):
    print('  >', ' '.join(str(a) for a in args))
    r = subprocess.run([str(a) for a in args], cwd=str(cwd))
    if r.returncode:
        sys.exit(f'Step failed ({r.returncode}). Your data is safe (a backup was made first). Run ERP.bat (option 3) again; if it fails again, send a photo of this window.')


def uses_postgres():
    f = ROOT / 'data' / 'config.env'
    return f.exists() and any(l.strip().startswith('POSTGRES_DB') for l in f.read_text(encoding='utf-8-sig').splitlines())


def uses_https_domain():
    f = ROOT / 'data' / 'config.env'
    return f.exists() and any(l.strip().startswith('ERP_DOMAIN=') and l.strip() != 'ERP_DOMAIN=' for l in f.read_text(encoding='utf-8-sig').splitlines())


def version(root):
    f = root / 'VERSION'
    return f.read_text().strip() if f.exists() else 'unknown'


def main():
    upd = ROOT / 'updates'
    upd.mkdir(exist_ok=True)
    zips = sorted(upd.glob('*.zip'), key=lambda p: p.stat().st_mtime)
    args = [a for a in sys.argv[1:] if not a.startswith('--')]
    auto = '--auto' in sys.argv                           # started by tools/autoupdate.py
    z = Path(args[0]) if args else (zips[-1] if zips else None)
    if not z or not z.exists():
        sys.exit('No update found. Put the new zip file inside the "updates" folder and run ERP.bat (option 3) again.')
    print(f'Update file: {z.name}\nInstalled now: {version(ROOT)}')
    with zipfile.ZipFile(z) as zf:
        names = zf.namelist()
        if 'backend/manage.py' not in names:
            sys.exit('This zip does not look like a School ERP update.')
        if any(n.startswith('/') or '..' in Path(n).parts for n in names):
            sys.exit('The zip file is not safe.')
        tmp = Path(tempfile.mkdtemp(prefix='erp_update_'))
        zf.extractall(tmp)
    py, be = sys.executable, ROOT / 'backend'
    print('1/4 Backup ...')
    run([py, 'manage.py', 'backup_data'], be)
    print('2/4 Copying new files ...')
    for item in tmp.iterdir():
        if item.name in KEEP or (auto and item.suffix == '.bat'):      # an automatic update never replaces the .bat files that may be running
            continue
        dest = ROOT / item.name
        if item.is_dir():
            shutil.copytree(item, dest, dirs_exist_ok=True)
        else:
            shutil.copy2(item, dest)
    shutil.rmtree(tmp, ignore_errors=True)
    for n in names:                                         # a compiled update (x.pyc) replaces an older readable x.py, otherwise the old code would keep running
        if n.endswith('.pyc') and '__pycache__' not in n and n[:-1] not in names:
            try:
                (ROOT / n[:-1]).unlink()
            except OSError:
                pass
    for name in OBSOLETE:                                   # old launchers that ERP.bat replaced: remove them so nothing confusing is left
        try:
            (ROOT / name).unlink(missing_ok=True)
        except OSError:
            pass
    bundled = (ROOT / 'runtime' / 'python.exe').exists()          # installer build: Python and every package are already inside 'runtime'
    print('3/4 Installing parts ...' if not bundled else '3/4 Parts are bundled, nothing to install.')
    if not bundled:
        run([py, '-m', 'pip', 'install', '-q', '--no-compile', '-r', 'requirements.txt'], be)
    if uses_postgres() and not bundled:
        if subprocess.run([py, '-m', 'pip', 'install', '-q', '--no-compile', '-r', 'requirements-postgres.txt'], cwd=str(be)).returncode:
            run([py, '-m', 'pip', 'install', '-q', '--no-compile', 'psycopg'], be)
    if uses_https_domain() and not bundled:
        subprocess.run([py, '-m', 'pip', 'install', '-q', '--no-compile', '-r', 'requirements-https.txt'], cwd=str(be))
    if not bundled:
        subprocess.run([py, str(ROOT / 'tools' / 'slim_venv.py')], cwd=str(ROOT))      # keeps the number of installed files small
    print('4/4 Preparing ...')
    run([py, 'manage.py', 'migrate', '-v', '0'], be)
    run([py, 'manage.py', 'normalize_data'], be)
    run([py, 'build_frontend.py'], be)
    run([py, 'manage.py', 'collectstatic', '--noinput', '-v', '0'], be)
    run([py, 'manage.py', 'make_cert'], be)
    subprocess.run([py, 'manage.py', 'get_cert'], cwd=str(be))      # trusted https (does nothing unless configured; failures never stop an update)
    done = upd / 'applied'
    done.mkdir(exist_ok=True)
    shutil.move(str(z), str(done / z.name)) if z.parent == upd else None
    print(f'\nUpdate finished. Now running: {version(ROOT)}')


if __name__ == '__main__':
    main()
