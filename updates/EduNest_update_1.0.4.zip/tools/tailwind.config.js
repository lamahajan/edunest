// Used only when UI.html / static JS gets NEW Tailwind classes: run tools\build_css.bat (needs Node.js) to regenerate backend/static/vendor/app.css
const cfg = require('./tailwind.theme.json');
module.exports = { darkMode: 'class', theme: { extend: cfg }, content: ['./backend/templates/*.html', './backend/static/*.js'],
  safelist: [{ pattern: /^col-span-(1|2|3|4|5|6|7|8|9|10|11|12)$/, variants: ['sm', 'md', 'lg'] }] };
