"""Makes the installed Python parts take far fewer files (a plain install is about 10,000 files, mostly translations nobody uses and compiled copies).

  - Django, its contrib apps and the REST framework ship translations for ~100 languages; the ERP is English: keep only English.
  - Compiled copies (__pycache__) are removed; the program no longer writes them (PYTHONDONTWRITEBYTECODE, pip --no-compile).
Nothing the program uses is removed. Safe to run any time:  python tools/slim_venv.py [--dry-run]"""
import re
import shutil
import sys
import sysconfig
from pathlib import Path

KEEP_LANG = {'en', 'en_GB', 'en_AU'}


LANG_NAME = re.compile(r'^[a-z]{2,3}([_@-][A-Za-z0-9]+)*$')          # ca, fr, zh_Hans, sr_Latn, ca@valencia


def locale_dirs(site):
    """Translation folders that can go: <package>/locale/<language> for every language except English."""
    out = []
    for loc in (list(site.glob('django/conf/locale')) + list(site.glob('django/contrib/*/locale')) + list(site.glob('rest_framework/locale')) + list(site.glob('corsheaders/locale'))):
        out += [d for d in loc.iterdir() if d.is_dir() and d.name not in KEEP_LANG and LANG_NAME.match(d.name)]
    return out


def slim(roots, dry_run=False):
    """roots: folders to clean (site-packages first). Returns (files removed, folders removed)."""
    files = dirs = 0
    for root in roots:
        root = Path(root)
        if not root.is_dir():
            continue
        targets = locale_dirs(root) + [p for p in root.rglob('__pycache__') if p.is_dir()]
        for d in targets:
            if not d.exists():
                continue
            n = sum(1 for f in d.rglob('*') if f.is_file())
            files += n; dirs += 1
            if not dry_run:
                shutil.rmtree(d, ignore_errors=True)
    return files, dirs


def main(argv):
    dry = '--dry-run' in argv
    root = Path(__file__).resolve().parent.parent
    files, dirs = slim([sysconfig.get_paths()['purelib'], root / 'backend', root / 'tools'], dry)
    print(f'{"Would remove" if dry else "Removed"} {files} unused files ({dirs} folders: other languages and compiled copies).')
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
