"""Runs the school server and starts it again whenever it asks for that (exit code 75: ERP.bat > Restart). Used by run_server.bat.
This loop is in Python, not in the .bat file, on purpose: an update replaces the .bat files while the server runs, and Windows reads a running .bat
file piece by piece, so a changed file would make the running window do strange things. Python files are read once per start, which is safe."""
import os
import subprocess
import sys
import time
from pathlib import Path

RESTART_CODE = 75
ROOT = Path(__file__).resolve().parent.parent


def supervise(cmd, cwd, env=None, delay=2.0, max_restarts=None, sleep=time.sleep, say=print, before=None):
    """Runs cmd until it ends with a code other than RESTART_CODE; returns that code. before() runs ahead of every start."""
    n = 0
    while True:
        if before:
            try:
                before()
            except Exception as e:                    # an update check must never stop the school from working
                say(f' (update check skipped: {type(e).__name__})')
        try:
            code = subprocess.run(cmd, cwd=cwd, env=env).returncode
        except KeyboardInterrupt:
            return 0
        if code != RESTART_CODE or (max_restarts is not None and n >= max_restarts):
            return code
        n += 1
        say('\n School ERP is restarting ...')
        sleep(delay)


def main(argv):
    show = bool(argv and argv[0] == 'show')
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', DJANGO_DEBUG=os.environ.get('DJANGO_DEBUG', '0'))
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    import autoupdate
    code = supervise([sys.executable, 'serve.py'], ROOT / 'backend', env, before=autoupdate.check)
    if code:
        print(f'\n The server stopped with an error (code {code}). Look at data\\server.log; send a photo of it.')
    if show:
        input('\n Press Enter to close this window ... ')
    return code


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
