/* Licence: a small status pill (trial / expiring / expired = read-only), the Setup > School Setup > Licence card, and a clear message when a save is refused. */
(function () {
  'use strict';
  var token = function () { return localStorage.getItem('erp_token'); };
  var last = null, shown402 = 0;
  function api(method, body) {
    return fetch('/api/sync/license/', { method: method, headers: { 'Authorization': 'Token ' + token(), 'Content-Type': 'application/json' }, body: body ? JSON.stringify(body) : undefined })
      .then(function (r) { return r.json().then(function (j) { return { ok: r.ok, j: j }; }); });
  }
  function pill(st) {
    var b = document.getElementById('erpLicPill');
    var show = st && (st.state === 'expired' || st.state === 'trial' || (st.state === 'licensed' && st.message));
    if (!show) { if (b) b.remove(); return; }
    if (!b) { b = document.createElement('div'); b.id = 'erpLicPill'; document.body.appendChild(b); b.addEventListener('click', function () { try { openModal('setupConfig'); setTimeout(function () { try { setupPick('school'); } catch (e) {} }, 200); } catch (e) { alert('Open Setup > School Setup > Licence'); } }); }
    var red = st.state === 'expired', amber = st.state === 'licensed';
    b.style.cssText = 'position:fixed;left:12px;bottom:46px;z-index:9980;cursor:pointer;border-radius:999px;padding:6px 14px;font:600 12px system-ui;box-shadow:0 4px 14px rgba(0,0,0,.25);' +
      (red ? 'background:#b3261e;color:#fff' : amber ? 'background:#f9ab00;color:#1f1f1f' : 'background:#0b57d0;color:#fff');
    b.textContent = (red ? '\u26D4 ' : '') + st.message;
    b.title = 'Click to open the Licence settings';
  }
  function check() {
    if (!token()) return;
    api('GET').then(function (r) { if (r.ok) { last = r.j; pill(r.j); } }).catch(function () {});
  }
  window.licFill = function () {
    var s = document.getElementById('licStatus'), h = document.getElementById('licHw');
    api('GET').then(function (r) {
      if (!r.ok) return; var st = r.j; last = st; pill(st);
      if (h) h.value = st.machine_id || '';
      if (!s) return;
      var t = st.state === 'licensed' ? 'Licensed to ' + (st.school || '') + (st.edition ? ' (' + st.edition + ')' : '') + (st.expires ? ', valid until ' + st.expires : ', never expires') + (st.max_students ? ', up to ' + st.max_students + ' students' : '') + '.'
        : st.state === 'trial' ? 'Trial version: ' + st.days_left + ' days left. Everything works; after the trial it becomes read-only until a key is entered.'
        : 'Read-only: ' + (st.message || 'licence needed') + ' You can still view, print, export and back up.';
      if (st.key_error) t += ' (' + st.key_error + ')';
      s.textContent = t; s.style.color = st.state === 'expired' ? '#b3261e' : '';
    }).catch(function () {});
  };
  window.licActivate = function () {
    var k = (document.getElementById('licKey') || {}).value || '';
    if (!k.trim()) { alert('Paste the licence key first.'); return; }
    api('POST', { key: k.trim() }).then(function (r) {
      if (!r.ok) { alert(r.j.error || 'The key was not accepted.'); return; }
      document.getElementById('licKey').value = '';
      if (window.showToast) showToast('Licence activated');
      window.licFill(); check();
    }).catch(function () { alert('Could not reach the server.'); });
  };
  var of = window.fetch;                                   // a refused save (read-only / student limit): say why, once in a while
  window.fetch = function () {
    return of.apply(this, arguments).then(function (r) {
      if (r.status === 402 && Date.now() - shown402 > 15000) {
        shown402 = Date.now();
        r.clone().json().then(function (j) { if (j && j.license) alert(j.error); }).catch(function () {});
        check();
      }
      return r;
    });
  };
  check();
  setInterval(check, 6 * 3600 * 1000);
})();
