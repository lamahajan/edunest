/* Live attendance: biometric scans (eSSL AiFace -> cloud -> server) mark students Present in the ERP all morning.
   erp-sync.js announces each change as 'erp-att'. This script keeps the page's own copy of the attendance equal to the server's (so a later
   Save on this screen can never undo a scan) and, if the Attendance screen is open on "Mark", shows the new Present marks at once.
   It only ever fills an empty mark or turns Absent into Present; whatever the teacher chose otherwise (Leave, an unsaved Present) stays. */
(function () {
  'use strict';
  window.addEventListener('erp-att', function () {
    try {
      ATT = JSON.parse(localStorage.getItem('eacademics_att') || '{}') || {};
      var pg = document.getElementById('pageAttendance');
      if (typeof att === 'undefined' || !pg || pg.offsetParent === null || att.tab !== 'mark') return;
      var srv = ATT[attKey()] || {}, changed = false;
      Object.keys(srv).forEach(function (a) { if (srv[a] === 'P' && (!att.marks[a] || att.marks[a] === 'A')) { att.marks[a] = 'P'; changed = true; } });
      if (changed) attRender();
    } catch (e) { /* the page is not ready: nothing to refresh */ }
  });
})();
