/* First-run wizard: shown once to the Administrator while the default password (admin123) is still in use.
   Asks for the school's details and a new password, saves them like the Setup screens do, and the red warning goes away. */
(function () {
  'use strict';
  var token = function () { return localStorage.getItem('erp_token'); };
  var shown = false;
  function css() {
    if (document.getElementById('erpWizCss')) return;
    var s = document.createElement('style'); s.id = 'erpWizCss';
    s.textContent = '#erpWiz{position:fixed;inset:0;z-index:9999;background:rgba(15,23,42,.55);backdrop-filter:blur(4px);display:flex;align-items:center;justify-content:center;padding:16px;overflow:auto}' +
      '#erpWiz .box{background:#fff;color:#1f1f1f;border-radius:24px;width:100%;max-width:640px;padding:26px 28px;box-shadow:0 24px 60px rgba(0,0,0,.35);max-height:96vh;overflow:auto}' +
      'html.dark #erpWiz .box{background:#1e1f20;color:#e3e3e3}' +
      '#erpWiz h2{margin:0 0 2px;font:600 22px system-ui}#erpWiz p.s{margin:0 0 14px;color:#5f6368;font-size:13px}html.dark #erpWiz p.s{color:#9aa0a6}' +
      '#erpWiz .g{display:grid;grid-template-columns:1fr 1fr;gap:16px 12px;margin-top:6px}#erpWiz .g .w{grid-column:1/3}' +
      '#erpWiz h3{margin:20px 0 0;font:700 11px system-ui;letter-spacing:.09em;text-transform:uppercase;color:#0b57d0}html.dark #erpWiz h3{color:#a8c7fa}' +
      '#erpWiz .err{color:#b3261e;font-size:13px;min-height:18px;margin-top:10px}' +
      '#erpWiz button{border:0;border-radius:999px;padding:11px 26px;font:600 14px system-ui;cursor:pointer;background:#0b57d0;color:#fff}#erpWiz button:disabled{opacity:.6}' +
      '@media(max-width:560px){#erpWiz .g{grid-template-columns:1fr}#erpWiz .g .w{grid-column:1}}';
    document.head.appendChild(s);
  }
  function f(id, label, w, ph, type) { return '<div class="mf' + (w ? ' w' : '') + '"><label>' + label + '</label><input id="wz' + id + '" type="' + (type || 'text') + '" autocomplete="off" placeholder="' + (ph || '') + '"></div>'; }
  function v(id) { return (document.getElementById('wz' + id).value || '').trim(); }
  function build() {
    if (shown) return; shown = true; css();
    var o = document.createElement('div'); o.id = 'erpWiz';
    o.innerHTML = '<div class="box"><h2>Welcome to EduNest</h2><p class="s">Two minutes to set up your school. You can change everything later in Setup.</p>' +
      '<h3>Your school</h3><div class="g">' + f('Name', 'School name *', 1, 'e.g. ABC Public School') + f('Addr', 'Address', 1, '') + f('Dist', 'District') + f('State', 'State') + f('Pin', 'PIN code') + f('Phone', 'Phone (comma separated)') +
      f('Email', 'School email') + f('Aff', 'Affiliation board / no.', 0, 'e.g. CBSE 1234567') + '</div>' +
      '<h3>Administrator</h3><div class="g">' + f('Me', 'Your name *', 1, 'e.g. Mrs. Sharma') + f('Pw', 'New password * (min 8 characters)', 0, '', 'password') + f('Pw2', 'Repeat password *', 0, '', 'password') + '</div>' +
      '<p class="s" style="margin-top:10px">You will sign in with username <b>admin</b> and this password. Write it down and keep it safe.</p>' +
      '<div class="err" id="wzErr"></div><div style="text-align:right;margin-top:6px"><button id="wzGo">Save and start</button></div></div>';
    document.body.appendChild(o);
    document.getElementById('wzGo').onclick = save;
  }
  function err(m) { document.getElementById('wzErr').textContent = m; }
  function save() {
    var btn = document.getElementById('wzGo'), pw = document.getElementById('wzPw').value, pw2 = document.getElementById('wzPw2').value;
    if (!v('Name')) return err('Please enter the school name.');
    if (!v('Me')) return err('Please enter your name.');
    if (pw.length < 8) return err('The password needs at least 8 characters.');
    if (pw === 'admin123' || pw.toLowerCase() === 'password') return err('Please choose a password that is not easy to guess.');
    if (pw !== pw2) return err('The two passwords are not the same.');
    err(''); btn.disabled = true; btn.textContent = 'Saving ...';
    var aff = v('Aff').split(/\s+/), board = aff.length > 1 ? aff[0] : v('Aff'), affNo = aff.length > 1 ? aff.slice(1).join(' ') : '';
    try {
      Object.assign(SCHOOL, { name: v('Name'), address: v('Addr'), district: v('Dist'), state: v('State'), pin: v('Pin'), phone: v('Phone'), email: v('Email'), affTo: board, affNo: affNo });
      localStorage.setItem('eacademics_school', JSON.stringify(SCHOOL));
      var u = USERS.find(function (x) { return x.role === 'Administrator' && x.username === 'admin'; }) || USERS.find(function (x) { return x.role === 'Administrator'; });
      usrHash(pw).then(function (h) {
        u.name = v('Me'); u.pass = h; usrSave();
        setTimeout(function () { location.reload(); }, 1800);                  // give the server time to take the new data first
      });
    } catch (e) { btn.disabled = false; btn.textContent = 'Save and start'; err('Something went wrong. Please reload the page and try again.'); }
  }
  function check() {
    if (!token() || shown) return;
    fetch('/api/sync/security-notice/', { headers: { 'Authorization': 'Token ' + token() } })
      .then(function (r) { return r.ok ? r.json() : null; })                     // only the Administrator gets an answer
      .then(function (j) { if (j && j.defaultPassword) build(); })
      .catch(function () {});
  }
  setTimeout(check, 1200);
})();
