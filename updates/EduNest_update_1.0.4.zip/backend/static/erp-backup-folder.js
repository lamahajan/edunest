/* Setup > School Setup > "Backup folder": where the school server keeps its backups (administrator only). The card itself is part of the ERP
   page (build_frontend.py); this file fills it in and handles Test / Save / Backup now. */
(function () {
  'use strict';
  var $ = function (id) { return document.getElementById(id); };
  function api(method, url, body) {
    return fetch('/api/sync/' + url, { method: method, headers: { 'Authorization': 'Token ' + localStorage.getItem('erp_token'), 'Content-Type': 'application/json' }, body: body === undefined ? undefined : JSON.stringify(body) })
      .then(function (r) { return { status: r.status, headers: r.headers, json: function () { return r.json().catch(function () { return {}; }); } }; });
  }
  function msg(text, bad) { var n = $('bkDirInfo'); if (n) { n.textContent = text; n.className = 'text-xs mt-2 ' + (bad ? 'text-red-600' : 'text-gray-600 dark:text-gray-300'); } }
  function size(b) { return b == null ? '?' : b >= 1073741824 ? (b / 1073741824).toFixed(1) + ' GB' : (b / 1048576).toFixed(0) + ' MB'; }
  function show(info) {
    $('bkDir').value = info.custom ? info.folder : '';
    msg('Backups go to: ' + info.folder + (info.custom ? '' : ' (the program\'s own folder)') + '. ' + info.count + ' backup' + (info.count === 1 ? '' : 's') + ' there' +
        (info.last ? ', the latest ' + info.last.name + ' (' + info.last.time + ', ' + size(info.last.size) + ')' : '') + '. Free space: ' + size(info.free_bytes) + '.' +
        (info.reachable ? '' : ' This folder cannot be reached right now (drive not plugged in?): backups will go to the program\'s own folder until it is back.'), !info.reachable);
  }
  window.bkFolderFill = function () {
    if (!$('bkDir')) return;
    if (!localStorage.getItem('erp_token')) return msg('Please log in to the ERP first.', true);
    api('GET', 'backup-folder/').then(function (r) {
      if (r.status === 403) { msg('Only an administrator can see or change the backup folder.', true); return; }
      return r.json().then(function (j) { if (j.info) show(j.info); else msg('Could not read the backup folder (HTTP ' + r.status + ').', true); });
    });
  };
  window.bkFolderAct = function (act) {
    var path = $('bkDir').value.trim();
    if (act === 'now') {
      msg('Making the backup ... (this can take a minute)');
      return api('POST', 'backup/').then(function (r) {
        if (r.status === 403) return msg('Only an administrator can take a backup.', true);
        if (r.status !== 200) return r.json().then(function (j) { msg('Backup failed: ' + (j.error || 'the server said ' + r.status), true); });
        var warn = r.headers.get('X-Backup-Warning');
        msg('Backup saved: ' + r.headers.get('X-Backup-Saved') + (warn ? '. ' + warn : ''), !!warn);
      });
    }
    msg(act === 'test' ? 'Testing ...' : 'Saving ...');
    api('POST', 'backup-folder/', { path: path, test: act === 'test' }).then(function (r) {
      r.json().then(function (j) {
        if (r.status === 403) return msg('Only an administrator can change the backup folder.', true);
        if (!j.ok) return msg(j.error || 'The folder was not accepted.', true);
        if (act === 'test') return msg('This folder works: it can be created and written to.');
        show(j.info); var n = $('bkDirInfo'); n.textContent = 'Saved. ' + n.textContent;
      });
    });
  };
})();
