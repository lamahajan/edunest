/* A red notice for the administrator while the well-known default password (admin123) is still in use. It goes away by itself once the password is changed. */
(function () {
  'use strict';
  var token = function () { return localStorage.getItem('erp_token'); };
  var timer = null;
  function bar() { return document.getElementById('erpSecurityNotice'); }
  function remove() { var b = bar(); if (b) b.remove(); }
  function show() {
    if (bar() || sessionStorage.getItem('erp_notice_later') === '1') return;
    var b = document.createElement('div'); b.id = 'erpSecurityNotice';
    b.style.cssText = 'position:fixed;left:0;right:0;top:0;z-index:9990;background:#b3261e;color:#fff;padding:8px 14px;font:600 13px system-ui;display:flex;gap:10px;align-items:center;flex-wrap:wrap;justify-content:center;box-shadow:0 2px 8px rgba(0,0,0,.3)';
    b.innerHTML = '<span>\u26A0 The Administrator password is still the default (<b>admin123</b>). Anyone on the school network can sign in as Administrator. Change it now: profile menu \u2192 User Management.</span>' +
      '<button data-a="open" style="border:0;border-radius:8px;padding:5px 12px;font:600 12px system-ui;cursor:pointer;background:#fff;color:#b3261e">Open User Management</button>' +
      '<button data-a="later" style="border:1px solid #fff;border-radius:8px;padding:5px 12px;font:600 12px system-ui;cursor:pointer;background:transparent;color:#fff">Remind me later</button>';
    b.addEventListener('click', function (e) {
      var a = e.target.getAttribute && e.target.getAttribute('data-a');
      if (a === 'later') { sessionStorage.setItem('erp_notice_later', '1'); remove(); }
      if (a === 'open') { try { openModal('adminZone'); } catch (x) { alert('Open the profile menu and choose User Management.'); } }
    });
    document.body.appendChild(b);
  }
  function check() {
    if (!token()) return;
    fetch('/api/sync/security-notice/', { headers: { 'Authorization': 'Token ' + token() } })
      .then(function (r) { return r.ok ? r.json() : null; })                       // not an administrator (403): no notice, no noise
      .then(function (j) { if (j && j.defaultPassword) show(); else remove(); })
      .catch(function () {});
  }
  check();
  window.addEventListener('erp-changed', function () { if (!bar()) return; clearTimeout(timer); timer = setTimeout(check, 3000); });   // the password was changed here or on another PC
})();
