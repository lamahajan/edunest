/* Mark Entry > "Bulk tools": fill one value for everybody, paste marks from Excel, clear marks. Works on the grid that is on screen (meSt) and, like typing,
   changes nothing until Save is pressed. The button and the Save fix are part of the ERP page (build_frontend.py); the logic is here so it can be tested. */
(function () {
  'use strict';
  var API = window.MarksBulk = {};

  // one cell value from what a person typed / pasted: '' (nothing), 'AB', a number with at most 2 decimals, or null (not a valid mark)
  API.norm = function (raw, max) {
    var v = String(raw == null ? '' : raw).trim();
    if (v === '') return '';
    if (/^(ab|abs|absent|a)$/i.test(v)) return 'AB';
    v = v.replace(/\s+/g, '').replace(/^(\d+),(\d{1,2})$/, '$1.$2');          // 45,5 (comma decimal) -> 45.5
    if (!/^\d+(\.\d+)?$/.test(v)) return null;
    var n = Math.round(Number(v) * 100) / 100;
    return n >= 0 && n <= max ? String(n) : null;
  };

  // Excel paste -> cells. Lines are rows, tabs (or ; ,) are columns.
  //  - a line whose first column is an admission number on screen is matched by admission number; otherwise lines go to the students in the order shown
  //  - the columns after that fill consecutive subjects starting at `col` (a single subject: just that one)
  API.parse = function (text, rows, subs, col) {
    var lines = String(text || '').replace(/\r/g, '').split('\n').filter(function (l) { return l.trim() !== ''; });
    var out = { sets: [], invalid: [], missing: [], mode: 'order', lines: lines.length };
    if (!lines.length) return out;
    var split = function (l) { return (l.indexOf('\t') >= 0 ? l.split('\t') : /[;]/.test(l) ? l.split(';') : [l]).map(function (x) { return x.trim(); }); };
    var byAdm = {}; rows.forEach(function (r, i) { byAdm[String(r.adm).trim()] = i; });
    var cells = lines.map(split);
    var hits = cells.filter(function (c) { return c.length > 1 && byAdm[c[0]] !== undefined; }).length;
    var admMode = hits > 0 && hits >= cells.filter(function (c) { return c.length > 1; }).length * 0.5 && hits >= cells.length * 0.5;
    out.mode = admMode ? 'admission' : 'order';
    cells.forEach(function (c, n) {
      var i, vals;
      if (admMode) { i = byAdm[c[0]]; vals = c.slice(1); if (i === undefined) { out.missing.push(c[0]); return; } }
      else { i = n; vals = c; if (i >= rows.length) { out.missing.push('line ' + (n + 1)); return; } }
      vals.forEach(function (raw, k) {
        var j = col + k; if (j >= subs.length) return;
        if (String(raw).trim() === '') return;                                    // an empty Excel cell leaves the mark as it is
        var v = API.norm(raw, subs[j].max);
        if (v === null) out.invalid.push(rows[i].name + ' / ' + subs[j].name + ': ' + raw + ' (0 to ' + subs[j].max + ' or AB)');
        else out.sets.push({ i: i, j: j, v: v });
      });
    });
    return out;
  };

  API.fill = function (S, value, col, overwrite) {
    var n = 0, bad = 0, js = col < 0 ? S.subs.map(function (x, j) { return j; }) : [col];
    js.forEach(function (j) {
      var v = API.norm(value, S.subs[j].max);
      if (v === null || v === '') { bad++; return; }
      S.rows.forEach(function (r) { if (overwrite || String(r.vals[j]).trim() === '') { if (r.vals[j] !== v) n++; r.vals[j] = v; } });
    });
    return { changed: n, badSubjects: bad };
  };

  API.clear = function (S, col) {
    var n = 0, js = col < 0 ? S.subs.map(function (x, j) { return j; }) : [col];
    js.forEach(function (j) { S.rows.forEach(function (r) { if (String(r.vals[j]).trim() !== '') { n++; r.vals[j] = ''; } }); });
    return n;
  };
  API.clearGrades = function (S) { var n = 0; S.rows.forEach(function (r) { if (r.vals[0]) { n++; r.vals[0] = ''; } }); return n; };

  // ---------------------------------------------------------------- the window
  var $ = function (id) { return document.getElementById(id); };
  var esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };
  var toast = function (m) { try { showToast(m); } catch (e) { alert(m); } };
  var ask = function (m) { try { return typeof rcConfirm === 'function' ? rcConfirm(m) : Promise.resolve(window.confirm(m)); } catch (e) { return Promise.resolve(false); } };
  function close() { var o = $('meBulkBox'); if (o) o.remove(); }
  function after(msg) { close(); meRender(); toast(msg + ' Press Save to keep it.'); }

  window.meBulkOpen = function () {
    var S = meSt; if (!S || !S.rows || !S.rows.length) return toast('Press View first.');
    close();
    var card = 'border:1px solid rgba(128,128,128,.35);border-radius:14px;padding:12px;margin-top:10px';
    var btn = 'border:0;border-radius:10px;padding:8px 14px;font:600 13px system-ui;cursor:pointer';
    var subSel = function (id, allText) { return '<select id="' + id + '" style="width:100%;padding:7px;border-radius:8px;border:1px solid rgba(128,128,128,.4);background:transparent;color:inherit">' + (allText ? '<option value="-1">' + allText + '</option>' : '') + S.subs.map(function (x, j) { return '<option value="' + j + '">' + esc(x.name) + ' (max ' + x.max + ')</option>'; }).join('') + '</select>'; };
    var o = document.createElement('div'); o.id = 'meBulkBox';
    o.style.cssText = 'position:fixed;inset:0;z-index:9999;background:rgba(0,0,0,.45);display:flex;align-items:center;justify-content:center;padding:12px';
    var sc = S.mode === 'S';
    o.innerHTML = '<div class="bg-white dark:bg-[#1e1f20] text-gray-900 dark:text-gray-100" style="border-radius:20px;max-width:640px;width:100%;max-height:90vh;overflow:auto;padding:18px;font:14px system-ui">' +
      '<div style="display:flex;justify-content:space-between;align-items:center"><b style="font-size:16px">Bulk tools</b><button data-a="close" style="border:0;background:none;font-size:20px;cursor:pointer;color:inherit">\u2715</button></div>' +
      '<p style="opacity:.7;font-size:12px;margin:4px 0 0">Applies to the ' + S.rows.length + ' students shown on screen. Nothing is saved until you press <b>Save</b>.</p>' +
      (sc ? '<div style="' + card + '"><b>Fill</b><div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:8px"><div><label style="font-size:12px;opacity:.7">Subject</label>' + subSel('mbFillSub', 'All subjects') + '</div>' +
        '<div><label style="font-size:12px;opacity:.7">Mark (number or AB)</label><input id="mbFillVal" style="width:100%;padding:7px;border-radius:8px;border:1px solid rgba(128,128,128,.4);background:transparent;color:inherit"></div></div>' +
        '<label style="display:block;margin-top:8px;font-size:13px"><input type="checkbox" id="mbFillAll"> also replace marks already entered (otherwise only empty boxes are filled)</label>' +
        '<button data-a="fill" class="rc-btn rc-btn-primary" style="' + btn + ';margin-top:8px">Fill</button></div>' +
        '<div style="' + card + '"><b>Paste from Excel</b><p style="opacity:.7;font-size:12px;margin:4px 0 8px">Copy cells in Excel and paste here. <b>One column</b> = one mark per line, in the order shown on screen. <b>Admission No + marks</b> = matched by admission number (any order). Several mark columns fill the next subjects.</p>' +
        '<label style="font-size:12px;opacity:.7">First subject to fill</label>' + subSel('mbPasteSub') + '<textarea id="mbPaste" rows="5" placeholder="Paste here" style="width:100%;margin-top:8px;padding:7px;border-radius:8px;border:1px solid rgba(128,128,128,.4);background:transparent;color:inherit;font-family:monospace"></textarea>' +
        '<div id="mbPasteInfo" style="font-size:12px;margin-top:6px;min-height:1em"></div><button data-a="paste" class="rc-btn rc-btn-primary" style="' + btn + ';margin-top:6px">Put into the list</button></div>' : '') +
      '<div style="' + card + '"><b style="color:#b3261e">Clear</b><p style="opacity:.7;font-size:12px;margin:4px 0 8px">' + (sc ? 'Empties the marks of the students shown, for one subject or all. After you press Save they are removed from the ERP, and from the result portal as well.' : 'Empties the grades of the students shown. After you press Save they are removed.') + '</p>' +
      (sc ? subSel('mbClearSub', 'All subjects') : '') + '<button data-a="clear" style="' + btn + ';margin-top:8px;background:#b3261e;color:#fff">Clear</button></div></div>';
    document.body.appendChild(o);
    var info = function () {
      var t = $('mbPaste').value, p = API.parse(t, S.rows, S.subs, Number($('mbPasteSub').value)), el = $('mbPasteInfo');
      if (!p.lines) { el.textContent = ''; return null; }
      el.innerHTML = (p.mode === 'admission' ? 'Matched by admission number. ' : 'In the order shown. ') + '<b>' + p.sets.length + '</b> marks ready' + (p.invalid.length ? ', <span style="color:#b3261e">' + p.invalid.length + ' not valid (skipped): ' + esc(p.invalid.slice(0, 3).join('; ')) + (p.invalid.length > 3 ? ' ...' : '') + '</span>' : '') + (p.missing.length ? ', <span style="color:#b3261e">' + p.missing.length + ' not found: ' + esc(p.missing.slice(0, 5).join(', ')) + '</span>' : '') + '.';
      return p;
    };
    o.addEventListener('input', function (e) { if (e.target.id === 'mbPaste') info(); });
    o.addEventListener('change', function (e) { if (e.target.id === 'mbPasteSub') info(); });
    o.addEventListener('click', function (e) {
      var a = e.target.getAttribute && e.target.getAttribute('data-a');
      if (e.target === o || a === 'close') return close();
      if (a === 'fill') {
        var col = Number($('mbFillSub').value);
        if ($('mbFillVal').value.trim() === '') return toast('Type the mark to fill.');
        var r = API.fill(S, $('mbFillVal').value, col, $('mbFillAll').checked);
        if (r.badSubjects && !r.changed) return toast('That is not a valid mark (0 to the maximum, or AB).');
        return after('Filled ' + r.changed + ' marks' + (r.badSubjects ? ' (' + r.badSubjects + ' subject(s) skipped: the mark is above their maximum)' : '') + '.');
      }
      if (a === 'paste') {
        var p = info(); if (!p || !p.sets.length) return toast('Nothing valid to paste.');
        p.sets.forEach(function (c) { S.rows[c.i].vals[c.j] = c.v; });
        return after('Put ' + p.sets.length + ' marks into the list' + (p.invalid.length ? ' (' + p.invalid.length + ' skipped)' : '') + '.');
      }
      if (a === 'clear') {
        var j = sc ? Number($('mbClearSub').value) : 0;
        var count = sc ? S.rows.reduce(function (n, r) { return n + (j < 0 ? S.subs.reduce(function (m, x, k) { return m + (String(r.vals[k]).trim() !== '' ? 1 : 0); }, 0) : (String(r.vals[j]).trim() !== '' ? 1 : 0)); }, 0) : S.rows.filter(function (r) { return r.vals[0]; }).length;
        if (!count) return toast('There is nothing to clear.');
        var what = sc ? (j < 0 ? 'ALL subjects' : S.subs[j].name) : 'the grades';
        ask('Clear ' + count + ' ' + (sc ? 'marks' : 'grades') + ' of ' + what + ' for the ' + S.rows.length + ' students shown?\n\nThey are removed only after you press Save.').then(function (yes) {
          if (yes) after('Cleared ' + (sc ? API.clear(S, j) : API.clearGrades(S)) + (sc ? ' marks.' : ' grades.'));
        });
      }
    });
  };
})();
