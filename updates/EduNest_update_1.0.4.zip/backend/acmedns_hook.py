"""Called by certbot while it proves the domain: publishes the challenge text through acme-dns. (Not meant to be run by hand.)"""
import json
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import acmedns_client  # noqa: E402

try:
    creds = json.load(open(os.environ['ACMEDNS_FILE'], encoding='utf-8'))
    acmedns_client.update(os.environ.get('ACMEDNS_URL', 'https://auth.acme-dns.io'), creds, os.environ['CERTBOT_VALIDATION'])
except Exception as e:
    print('acme-dns update failed:', e)
    sys.exit(1)
time.sleep(int(os.environ.get('ACMEDNS_WAIT', '5')))
