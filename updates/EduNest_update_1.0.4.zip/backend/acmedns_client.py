"""Tiny client for acme-dns (https://github.com/joohoi/acme-dns). It lets a domain that is NOT on an API-capable DNS host (for example a
domain bought at Wix) get a Let's Encrypt certificate: the owner adds ONE CNAME record once, and from then on certificates are renewed by
this program alone. No password of the domain account is ever needed."""
import json
import urllib.request


def _post(url, body, headers=None):
    req = urllib.request.Request(url, data=json.dumps(body).encode(), headers={'Content-Type': 'application/json', **(headers or {})}, method='POST')
    with urllib.request.urlopen(req, timeout=30) as r:
        return json.loads(r.read().decode() or '{}')


def register(base):
    """Returns {username, password, fulldomain, subdomain}."""
    return _post(base.rstrip('/') + '/register', {})


def update(base, creds, txt):
    return _post(base.rstrip('/') + '/update', {'subdomain': creds['subdomain'], 'txt': txt}, {'X-Api-User': creds['username'], 'X-Api-Key': creds['password']})


def cname_ok(name, target):
    """True / False if the CNAME is (not) in place, None when it cannot be checked.
    Asks public DNS (Google, Cloudflare) first, because a router/ISP may keep an old "no such record" answer for a long time."""
    try:
        import dns.resolver
    except ImportError:
        return None
    want = target.rstrip('.').lower()
    answered = False
    for servers in (['8.8.8.8', '8.8.4.4'], ['1.1.1.1', '1.0.0.1'], None):      # None = this PC's own DNS
        try:
            res = dns.resolver.Resolver(configure=servers is None)
            if servers:
                res.nameservers = servers
            res.lifetime = 8
            if any(str(r.target).rstrip('.').lower() == want for r in res.resolve(name, 'CNAME')):
                return True
            answered = True
        except (dns.resolver.NXDOMAIN, dns.resolver.NoAnswer):
            answered = True
        except Exception:
            continue
    return False if answered else None
