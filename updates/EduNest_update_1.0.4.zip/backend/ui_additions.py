"""JS injected into UI.html by build_frontend.py (kept separate so it stays readable)."""

FEE_INCREASE_JS = r'''
    // ---- fees of the new session (Manage Sessions > Promote Session) ----
    const PRI = { rules: {}, round: 10, over: {}, sover: {}, newHeads: [], open: {}, quick: { mode: 'pct', val: '' }, _for: '' }, PRI_T = '__transport';
    const PRI_MODES = [['none', 'No change'], ['pct', 'Increase by %'], ['amt', 'Increase by ₹'], ['set', 'Set to ₹']];
    function priSave() { try { localStorage.setItem('eacademics_priplan', JSON.stringify({ next: PRI._for, rules: PRI.rules, round: PRI.round, over: PRI.over, sover: PRI.sover, newHeads: PRI.newHeads })); } catch (e) {} }
    function priLoad(next) {       // the plan is kept on the server, so it can be prepared in advance and finished later
      if (PRI._for === next) return; PRI._for = next;
      try { const d = JSON.parse(localStorage.getItem('eacademics_priplan') || 'null'); if (d && d.next === next) { PRI.rules = d.rules || {}; PRI.round = d.round === undefined ? 10 : d.round; PRI.over = d.over || {}; PRI.sover = d.sover || {}; PRI.newHeads = d.newHeads || []; return; } } catch (e) {}
      PRI.rules = {}; PRI.round = 10; PRI.over = {}; PRI.sover = {}; PRI.newHeads = [];
    }
    function priRedraw() { const el = rcEl('priCard'); if (!el) return prRender(); el.outerHTML = prIncCard(prYears()); }   // only this card is redrawn, so the page keeps its place
    const priRound = x => { const n = +PRI.round || 0; return n > 0 ? Math.round(x / n) * n : Math.round(x); };
    const priCalc = (cur, key) => {
      const r = PRI.rules[key] || {}, v = parseFloat(r.val); cur = Number(cur) || 0;
      if (!r.mode || r.mode === 'none' || !(v >= 0)) return cur;
      return r.mode === 'pct' ? priRound(cur * (1 + v / 100)) : r.mode === 'amt' ? Math.round(cur + v) : Math.round(v);
    };
    const priHeads = () => FEESTRUCT.heads.filter(h => !h.route);
    const priNew = (cls, head) => { const o = PRI.over[cls + '|' + head]; return o !== undefined && o !== '' ? Math.round(+o) : priCalc((FEESTRUCT.amounts[cls] || {})[head], head); };
    const priStopNew = s => { const o = PRI.sover[s.id]; return o !== undefined && o !== '' ? Math.round(+o) : priCalc(s.fee, PRI_T); };
    function priSetRule(key, f, v) {
      const r = PRI.rules[key] = PRI.rules[key] || { mode: 'none', val: '' }; r[f] = v;
      if (key === PRI_T) PRI.sover = {}; else Object.keys(PRI.over).forEach(k => { if (k.split('|')[1] === key) delete PRI.over[k]; });
      priSave(); priRedraw();
    }
    function priSetOver(kind, id, v) { PRI[kind][id] = v; priSave(); priRedraw(); }
    function priSetRound(v) { PRI.round = +v; PRI.over = {}; PRI.sover = {}; priSave(); priRedraw(); }
    function priApplyAll() {
      const q = PRI.quick, v = parseFloat(q.val); if (!(v >= 0) || q.val === '') return showToast('Enter the value first');
      priHeads().map(h => h.name).concat([PRI_T]).forEach(k => { PRI.rules[k] = { mode: q.mode, val: String(q.val) }; });
      PRI.over = {}; PRI.sover = {}; priSave(); priRedraw(); showToast('Applied to every fee. Change any fee below if it needs to be different.');
    }
    function priReset() { PRI.rules = {}; PRI.over = {}; PRI.sover = {}; PRI.newHeads = []; PRI.quick = { mode: 'pct', val: '' }; priSave(); priRedraw(); }
    function priAddHead() {
      const n = (rcEl('priHN').value || '').trim(), a = Math.round(+rcEl('priHA').value), f = rcEl('priHF').value;
      if (!n) return showToast('Enter the fee name'); if (!(a >= 0) || rcEl('priHA').value === '') return showToast('Enter the amount');
      if (FEESTRUCT.heads.some(h => h.name.toLowerCase() === n.toLowerCase()) || PRI.newHeads.some(h => h.name.toLowerCase() === n.toLowerCase())) return showToast('A fee with this name already exists');
      PRI.newHeads.push({ name: n, freq: f, amt: a }); priSave(); priRedraw();
    }
    function priDelHead(i) { PRI.newHeads.splice(i, 1); priSave(); priRedraw(); }
    function prIncCard(Y) {
      priLoad(Y.next);
      const hs = priHeads(), cl = CLASSES.filter(c => hs.some(h => (FEESTRUCT.amounts[c.name] || {})[h.name] !== undefined));
      const ex = h => { const c = cl.find(c => (FEESTRUCT.amounts[c.name] || {})[h.name] !== undefined); if (!c) return '—'; const cur = FEESTRUCT.amounts[c.name][h.name], nw = priNew(c.name, h.name); return `<span class="mx-note">${esc2(c.name)}: ${rcNum(cur)} ${nw !== cur ? '&rarr; <b class="text-emerald-700 dark:text-emerald-400">' + rcNum(nw) + '</b>' : '(same)'}</span>`; };
      const inp = (key, r) => r.mode === 'none' ? '' : `<input class="tt-sel" style="width:5.5rem" type="number" min="0" step="any" value="${esc2(r.val)}" onchange="priSetRule('${feeQ(key)}','val',this.value)"> <span class="mx-note">${r.mode === 'pct' ? '%' : '₹'}</span>`;
      const row = (key, label, exCell) => { const r = PRI.rules[key] || { mode: 'none', val: '' };
        return `<tr><td style="text-align:left;font-weight:500">${esc2(label)}</td><td><select class="tt-sel" onchange="priSetRule('${feeQ(key)}','mode',this.value)">${mxOpts(PRI_MODES, r.mode)}</select></td><td style="white-space:nowrap">${inp(key, r)}</td><td style="text-align:left">${exCell}</td></tr>`; };
      const feeRows = hs.map(h => row(h.name, h.name + ' (' + h.freq + ')', ex(h))).join('') + row(PRI_T, 'Transport (per stoppage, monthly)', STOPS.length ? `<span class="mx-note">${esc2(STOPS[0].name)}: ${rcNum(STOPS[0].fee)} ${priStopNew(STOPS[0]) !== (Number(STOPS[0].fee) || 0) ? '&rarr; <b class="text-emerald-700 dark:text-emerald-400">' + rcNum(priStopNew(STOPS[0])) + '</b>' : '(same)'}</span>` : '—');
      const clsTbl = cl.length ? `<div class="overflow-x-auto mt-2"><table class="tt-tbl"><thead><tr><th style="text-align:left">Class</th>${hs.map(h => `<th>${esc2(h.name)}</th>`).join('')}</tr></thead><tbody>${cl.map(c => `<tr><td style="text-align:left">${esc2(c.name)}</td>${hs.map(h => { const cur = (FEESTRUCT.amounts[c.name] || {})[h.name]; return cur === undefined ? '<td>—</td>' : `<td style="white-space:nowrap"><span class="mx-note">${rcNum(cur)} &rarr;</span> <input class="tt-sel" style="width:5.25rem" type="number" min="0" value="${priNew(c.name, h.name)}" onchange="priSetOver('over','${feeQ(c.name + '|' + h.name)}',this.value)"></td>`; }).join('')}</tr>`).join('')}</tbody></table></div>` : '';
      const stopTbl = STOPS.length ? `<div class="overflow-x-auto mt-2"><table class="tt-tbl"><thead><tr><th style="text-align:left">Route &rsaquo; Stoppage</th><th>Now (₹/month)</th><th>New (₹/month)</th></tr></thead><tbody>${STOPS.map(s => { const rt = ROUTES.find(r => r.id === s.route); return `<tr><td style="text-align:left">${esc2((rt ? rt.name + ' › ' : '') + s.name)}</td><td>${rcNum(s.fee)}</td><td><input class="tt-sel" style="width:5.25rem" type="number" min="0" value="${priStopNew(s)}" onchange="priSetOver('sover','${feeQ(s.id)}',this.value)"></td></tr>`; }).join('')}</tbody></table></div>` : '';
      const det = (id, title, body) => body ? `<details class="mt-3" ${PRI.open[id] ? 'open' : ''} ontoggle="PRI.open['${id}']=this.open"><summary class="cursor-pointer text-[0.8125rem] font-semibold text-gray-800 dark:text-gray-200 py-1">${title}</summary>${body}</details>` : '';
      let n = 0; cl.forEach(c => hs.forEach(h => { const cur = (FEESTRUCT.amounts[c.name] || {})[h.name]; if (cur !== undefined && priNew(c.name, h.name) !== cur) n++; })); STOPS.forEach(s => { if (priStopNew(s) !== (Number(s.fee) || 0)) n++; }); n += PRI.newHeads.length;
      const newHeads = `<div class="mt-3 pt-3 border-t border-[#e0e3e7] dark:border-[#3c4043]"><div class="text-[0.8125rem] font-semibold text-gray-800 dark:text-gray-200 mb-2">New fee (charged only from ${esc2(Y.next)})</div>
        ${PRI.newHeads.map((h, i) => `<div class="flex items-center gap-2 text-[0.8125rem] mb-1"><span class="material-symbols-outlined text-base text-emerald-600">add_circle</span><b>${esc2(h.name)}</b> <span class="mx-note">${esc2(h.freq)} · ${rcInr(h.amt)} for every class</span><button type="button" class="rc-tb" title="Remove" onclick="priDelHead(${i})"><span class="material-symbols-outlined">close</span></button></div>`).join('')}
        <div class="flex flex-wrap items-center gap-2"><input id="priHN" class="tt-sel" style="width:11rem" placeholder="Fee name, e.g. Smart Class"><select id="priHF" class="tt-sel"><option>Monthly</option><option>Annual</option></select><input id="priHA" type="number" min="0" class="tt-sel" style="width:6.5rem" placeholder="Amount ₹"><button type="button" class="rc-btn rc-btn-sm" onclick="priAddHead()"><span class="material-symbols-outlined">add</span>Add</button></div></div>`;
      return `<div class="mx-card" id="priCard"><div class="flex items-center gap-2 mb-1"><span class="material-symbols-outlined text-amber-600">trending_up</span><div class="rc-card-title flex-1" style="margin:0">Fees for ${esc2(Y.next)}</div><button type="button" class="rc-tb" onclick="priReset()"><span class="material-symbols-outlined">restart_alt</span>Reset</button></div>
        <p class="mx-note mb-3">The old session keeps its fees. ${n ? '<b class="text-emerald-700 dark:text-emerald-400">' + n + ' amount' + (n === 1 ? '' : 's') + ' will change.</b>' : 'Nothing is changed yet.'} Your changes are saved automatically, so you can finish them later.</p>
        <div class="rounded-xl bg-[#f0f4f9] dark:bg-[#282a2c] p-3"><div class="text-[0.8125rem] font-semibold text-gray-800 dark:text-gray-200 mb-2">1 · Change every fee at once</div>
          <div class="flex flex-wrap items-center gap-2"><select class="tt-sel" onchange="PRI.quick.mode=this.value">${mxOpts(PRI_MODES.filter(m => m[0] !== 'none'), PRI.quick.mode)}</select><input class="tt-sel" style="width:5.5rem" type="number" min="0" step="any" placeholder="value" value="${esc2(PRI.quick.val)}" onchange="PRI.quick.val=this.value"><span class="mx-note">round to</span><select class="tt-sel" onchange="priSetRound(this.value)">${mxOpts([['0', '₹1'], ['5', '₹5'], ['10', '₹10'], ['50', '₹50'], ['100', '₹100']], String(PRI.round))}</select><button type="button" class="rc-btn rc-btn-sm" onclick="priApplyAll()"><span class="material-symbols-outlined">done_all</span>Apply to all fees</button></div></div>
        <div class="text-[0.8125rem] font-semibold text-gray-800 dark:text-gray-200 mt-4 mb-2">2 · Or change fee by fee</div>
        <div class="overflow-x-auto"><table class="tt-tbl"><thead><tr><th style="text-align:left">Fee</th><th>Change</th><th>Value</th><th style="text-align:left">Example</th></tr></thead><tbody>${feeRows}</tbody></table></div>
        ${det('cls', '3 · Check or edit amounts class-wise', clsTbl)}${det('stops', '4 · Check or edit each stoppage', stopTbl)}${newHeads}</div>`;
    }
    function prIncWrites() {
      const fs = JSON.parse(JSON.stringify(FEESTRUCT));
      Object.keys(fs.amounts).forEach(cls => Object.keys(fs.amounts[cls]).forEach(h => { const hd = fs.heads.find(x => x.name === h); if (hd && hd.route) return; fs.amounts[cls][h] = priNew(cls, h); }));
      PRI.newHeads.forEach(h => { if (!fs.heads.some(x => x.name === h.name)) fs.heads.push({ name: h.name, freq: h.freq, all: true }); CLASSES.forEach(c => { (fs.amounts[c.name] = fs.amounts[c.name] || {})[h.name] = h.amt; }); });
      return { feestruct: JSON.stringify(fs), stops: JSON.stringify(STOPS.map(s => Object.assign({}, s, { fee: priStopNew(s) }))) };
    }
    // ---- which session to create (default: the first year that does not exist yet) ----
    function prSetTarget(v) { PR.targetY = +v; PRI._for = prYears().next; priSave(); prRender(); }   // the plan you are preparing moves to the session you chose
    function prTargetSelect(Y) {
      return `<select class="tt-sel text-base font-bold" onchange="prSetTarget(this.value)">${[1, 2, 3, 4].map(k => { const y = Y.y + k, id = y + '-' + (y + 1), ex = SESSIONS.some(x => x.id === id); return `<option value="${y}" ${y === Y.ty ? 'selected' : ''} ${ex ? 'disabled' : ''}>${id}${ex ? ' (already exists)' : ''}</option>`; }).join('')}</select>`;
    }
'''

ROLL_JS = r'''
    // ---- Setup > Classes: rearrange roll numbers ----
    const CRL = { cls: '', order: 'name', perSec: true };
    function clsRollRender() {
      const box = document.getElementById('clsRollBox'); if (!box) return; try { mxCss(); } catch (e) {}
      box.innerHTML = `<div class="rc-card-title mb-2"><span class="material-symbols-outlined">format_list_numbered</span>Rearrange roll numbers</div>
        <div class="flex flex-wrap items-end gap-3">
          <label class="text-xs">Class<br><select class="tt-sel" onchange="CRL.cls=this.value">${mxOpts([['', 'All classes']].concat(CLASSES.map(c => [c.name, c.name])), CRL.cls)}</select></label>
          <label class="text-xs">Order by<br><select class="tt-sel" onchange="CRL.order=this.value">${mxOpts([['name', 'Student name (A–Z)'], ['adm', 'Admission ID'], ['roll', 'Present roll no. (close gaps)']], CRL.order)}</select></label>
          <label class="flex items-center gap-2 text-xs pb-2"><input type="checkbox" class="w-4 h-4 accent-[#0b57d0]" ${CRL.perSec ? 'checked' : ''} onchange="CRL.perSec=this.checked"> Start from 1 in every section</label>
          <button type="button" class="rc-btn rc-btn-sm" onclick="clsRollRun()"><span class="material-symbols-outlined">swap_vert</span>Rearrange now</button></div>
        <p class="mx-note mt-2">Only students currently in the school are renumbered; students who have left keep their old number. Saved student records change immediately.</p>`;
    }
    async function clsRollRun() {
      if (SESS_VIEWONLY) return showToast('Session ' + SESS + ' is locked');
      const L = ADM.filter(r => !r.left && (!CRL.cls || r.cls === CRL.cls)); if (!L.length) return showToast('No students to renumber');
      if (!(await rcConfirm('Renumber the roll numbers of ' + L.length + ' students ' + (CRL.cls ? 'of class ' + CRL.cls : 'of all classes') + (CRL.perSec ? ' (starting from 1 in each section)' : '') + '?'))) return;
      const g = {}; L.forEach(r => { const k = r.cls + (CRL.perSec ? '|' + r.sec : ''); (g[k] = g[k] || []).push(r); });
      const admCmp = (a, b) => String(a.adm).localeCompare(String(b.adm), undefined, { numeric: true }), nameCmp = (a, b) => admName(a).localeCompare(admName(b)) || admCmp(a, b);
      const cmp = CRL.order === 'adm' ? admCmp : CRL.order === 'roll' ? (a, b) => ((+a.roll || 1e9) - (+b.roll || 1e9)) || nameCmp(a, b) : nameCmp;
      Object.values(g).forEach(G => G.sort(cmp).forEach((r, i) => { r.roll = String(i + 1); admSync(r); }));
      admPersist(); try { if (typeof refreshReceipt === 'function') refreshReceipt(); } catch (e) {}
      showToast('Roll numbers rearranged for ' + L.length + ' students');
    }
'''
