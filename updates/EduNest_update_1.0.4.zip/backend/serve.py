"""Runs the school server: http on 8000 and (when a certificate exists) https on 8443. Started by run_server.bat (ERP.bat option 1, or the automatic start)."""
import logging
import logging.handlers
import os
import sys
import threading
import time

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')

from cheroot.ssl.builtin import BuiltinSSLAdapter  # noqa: E402
from cheroot.wsgi import Server  # noqa: E402
from django.conf import settings  # noqa: E402
from django.core.wsgi import get_wsgi_application  # noqa: E402


def pick_cert():
    """The trusted (Let's Encrypt) certificate when there is one, otherwise the school's own certificate."""
    d = settings.DATA_DIR / 'certs'
    for name in ('trusted', 'server'):
        if (d / f'{name}.crt').exists() and (d / f'{name}.key').exists():
            return d / f'{name}.crt', d / f'{name}.key', name
    return None


def maintenance(https, log):
    """Twice a day: keep the trusted name pointing at this PC, renew the certificate when it is about to expire, and start using a new one without a restart."""
    from django.core.management import call_command
    seen = None
    while True:
        try:
            if os.environ.get('ERP_DOMAIN'):
                call_command('get_cert')
            c = pick_cert()
            if c and https is not None:
                stamp = (c[2], c[0].stat().st_mtime)
                if seen is not None and stamp != seen:
                    https.ssl_adapter = BuiltinSSLAdapter(str(c[0]), str(c[1]))
                    log.info('https certificate reloaded (%s)', c[2])
                seen = stamp
        except Exception as e:
            log.warning('Certificate check failed: %s', e)
        time.sleep(12 * 3600)


def main():
    log = logging.getLogger('serve')
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s',
                        handlers=[logging.handlers.RotatingFileHandler(settings.DATA_DIR / 'server.log', maxBytes=2_000_000, backupCount=3, encoding='utf-8'),
                                  logging.StreamHandler(sys.stdout)])
    app = get_wsgi_application()
    from sync import control  # noqa: E402
    control.clear()
    from sync import perms  # noqa: E402
    if perms.ensure_default_admin():
        log.warning('No user existed: created the default Administrator (username admin, password admin123). Change the password after the first login.')
    servers = [('http', Server(('0.0.0.0', settings.ERP_HTTP_PORT), app, numthreads=int(os.environ.get("ERP_THREADS", "300")), timeout=60))]
    cert = pick_cert()
    https = None
    if cert:
        https = Server(('0.0.0.0', settings.ERP_HTTPS_PORT), app, numthreads=int(os.environ.get("ERP_THREADS", "300")), timeout=60)
        https.ssl_adapter = BuiltinSSLAdapter(str(cert[0]), str(cert[1]))
        servers.append(('https', https))
        log.info('https uses the %s certificate', 'TRUSTED (Let\'s Encrypt)' if cert[2] == 'trusted' else 'school')
    else:
        log.warning('No https certificate yet (run: python manage.py make_cert). Only http is available.')
    errors = []

    def run(name, srv):
        try:
            srv.start()
        except OSError as e:
            errors.append(name)
            log.error('Cannot start %s on port %s: %s. Is School ERP already running (another black window or the automatic service)?', name, srv.bind_addr[1], e)
        except Exception:
            errors.append(name)
            log.exception('%s server stopped', name)

    threads = [threading.Thread(target=run, args=(n, s), daemon=True) for n, s in servers]
    for t in threads:
        t.start()
    time.sleep(1.5)
    if errors:
        for _, s in servers:
            try:
                s.stop()
            except Exception:
                pass
        sys.exit(1)
    threading.Thread(target=maintenance, args=(https, log), daemon=True).start()
    from sync import control, runtime  # noqa: E402  (cloud apps <-> ERP, event driven; each group starts only when it is set up in config.env / Setup > Cloud Connections)
    runtime.start_all()
    log.info('School ERP is running: http port %s%s', settings.ERP_HTTP_PORT, f', https port {settings.ERP_HTTPS_PORT}' if len(servers) > 1 else '')
    exit_code = 0
    try:
        while any(t.is_alive() for t in threads):
            want = control.pending()                  # a Restart / Stop asked for in the ERP or by ERP.bat
            if want:
                log.info('School ERP is %s as asked', 'restarting' if want == 'restart' else 'stopping')
                exit_code = control.RESTART_CODE if want == 'restart' else 0
                break
            time.sleep(1)
    except KeyboardInterrupt:
        pass
    finally:
        runtime.stop_all()
        for _, s in servers:
            try:
                s.stop()
            except Exception:
                pass
        control.clear()
    if exit_code:
        sys.exit(exit_code)               # run_server.bat starts it again when it sees this code


if __name__ == '__main__':
    main()
