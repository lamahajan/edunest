@echo off
title EduNest - first time setup
cd /d "%~dp0"
if exist runtime\python.exe goto :bundled
rem Installed with the EduNest installer: Python and every part are already in the 'runtime' folder.
set PYTHONDONTWRITEBYTECODE=1
set DJANGO_DEBUG=0
cd backend
..\runtime\python.exe manage.py migrate
if errorlevel 1 (
  echo.
  echo  The database could not be prepared. If you use PostgreSQL, check data\config.env and that PostgreSQL is running.
  pause
  exit /b 1
)
..\runtime\python.exe build_frontend.py
..\runtime\python.exe manage.py collectstatic --noinput -v 0
..\runtime\python.exe manage.py make_cert
echo.
echo  ---- Creating the first login ----
..\runtime\python.exe manage.py setup_school
echo.
echo  First login:  username  admin   password  admin123   ^(change the password after you sign in: profile menu, User Management^)
echo  Setup finished. Now double-click  EduNest ^(or ERP.bat^): option 1 starts the server, option 6 starts it by itself whenever the computer starts.
if /i not "%~1"=="/silent" pause
