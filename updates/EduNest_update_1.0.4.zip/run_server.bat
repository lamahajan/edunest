@echo off
rem School ERP server. Used by ERP.bat (option 1) and by the automatic start - you do not need to open this yourself.
rem The restart loop lives in tools\supervise.py (an update may replace this file while the server runs).
cd /d "%~dp0"
set "PY=%~dp0venv\Scripts\python.exe"
if exist "%~dp0runtime\python.exe" set "PY=%~dp0runtime\python.exe"
if not exist "%~dp0runtime\python.exe" call venv\Scripts\activate
set PYTHONDONTWRITEBYTECODE=1
set DJANGO_DEBUG=0
cd backend
"%PY%" manage.py make_cert
"%PY%" manage.py get_cert
if /i "%~1"=="show" call :banner
"%PY%" ..\tools\supervise.py %1 & exit /b

:banner
title EduNest server - keep this window open
echo.
echo  EduNest is starting. Keep this black window OPEN while the school works.
echo  (Not needed when the automatic start is on: ERP.bat, option 6.)
echo.
echo  On THIS computer open:   https://localhost:8443     (or http://localhost:8000)
echo  On OTHER computers open one of these (https is needed for the camera):
for /f "tokens=2 delims=:" %%a in ('ipconfig ^| findstr /c:"IPv4"') do for /f "tokens=* delims= " %%b in ("%%a") do echo        https://%%b:8443     or     http://%%b:8000
echo.
exit /b 0
