"""Runs the school server: http on 8000 and (when a certificate exists) https on 8443. Started by run_server.bat (ERP.bat option 1, or the automatic start)."""
import logging
import logging.handlers
import os
import sys
import threading
import time

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')

from cheroot.ssl.builtin import BuiltinSSLAdapter  # noqa: E402
from cheroot.wsgi import Server  # noqa: E402
from django.conf import settings  # noqa: E402
from django.core.wsgi import get_wsgi_application  # noqa: E402


def pick_cert():
    """The trusted (Let's Encrypt) certificate when there is one, otherwise the school's own certificate."""
    d = settings.DATA_DIR / 'certs'
    for name in ('trusted', 'server'):
        if (d / f'{name}.crt').exists() and (d / f'{name}.key').exists():
            return d / f'{name}.crt', d / f'{name}.key', name
    return None


def maintenance(https, log):
    """Twice a day: keep the trusted name pointing at this PC, renew the certificate when it is about to expire, and start using a new one without a restart."""
    from django.core.management import call_command
    seen = None
    while True:
        try:
            if os.environ.get('ERP_DOMAIN'):
                call_command('get_cert')
            c = pick_cert()
            if c and https is not None:
                stamp = (c[2], c[0].stat().st_mtime)
                if seen is not None and stamp != seen:
                    https.ssl_adapter = BuiltinSSLAdapter(str(c[0]), str(c[1]))
                    log.info('https certificate reloaded (%s)', c[2])
                seen = stamp
        except Exception as e:
            log.warning('Certificate check failed: %s', e)
        time.sleep(12 * 3600)


def https_redirect(app, domain, port, log):
    """Typing http://<domain>:8000 sends the browser on to https://<domain> (GET / HEAD only, temporary redirect). Opening the PC by its IP address over http
    is NOT redirected, so a device that cannot resolve the domain name can still open http://<ip>:8000."""
    from urllib.parse import quote

    def wrapped(environ, start_response):
        host = (environ.get('HTTP_HOST') or '').split(':')[0].strip().lower()
        if host == domain and environ.get('REQUEST_METHOD') in ('GET', 'HEAD'):
            path = quote(environ.get('SCRIPT_NAME', '') + environ.get('PATH_INFO', ''), safe='/%:@!$&\'()*+,;=-._~') or '/'
            qs = environ.get('QUERY_STRING', '')
            loc = 'https://' + domain + ('' if port == 443 else f':{port}') + path + (('?' + qs) if qs else '')
            start_response('302 Found', [('Location', loc), ('Content-Length', '0'), ('Cache-Control', 'no-store')])
            return [b'']
        return app(environ, start_response)
    log.info('http://%s is sent on to https automatically', domain)
    return wrapped


def dns_watch(log):
    """Every 20 minutes: does the domain name point at THIS PC? A wrong / old address is the usual reason why one device opens the school and another shows
    "site can't be reached" (the A record at Wix is typed by hand and does not follow the PC when the router gives it a new address). Only changes are logged."""
    import socket
    domain = os.environ.get('ERP_DOMAIN', '').strip().lower()
    if not domain:
        return
    last = None
    while True:
        try:
            from sync.management.commands.get_cert import primary_ip
            ip = primary_ip()
            try:
                got = socket.gethostbyname(domain)
            except OSError:
                got = None
            if got is None:
                state = ('warn', f'This PC cannot find the address of {domain}. Add the A record at your domain host (Host: {domain.split(".")[0]}, Value: {ip}), or the router / DNS on this PC blocks it.')
            elif got != ip:
                state = ('warn', f'{domain} points to {got} but this PC is {ip}. Devices will show "site can\'t be reached". Change the A record (Host: {domain.split(".")[0]}) to {ip}, and give this PC a fixed address in the router (DHCP reservation) so it never changes again.')
            else:
                state = ('info', f'{domain} correctly points to this PC ({ip}).')
            if state != last:
                (log.warning if state[0] == 'warn' else log.info)('DNS check: %s', state[1])
                last = state
        except Exception as e:
            log.info('DNS check skipped: %s', e)
        time.sleep(20 * 60)


def ensure_static(log):
    """Files copied over an older install (or an update that stopped half-way) can leave the screens without their CSS / fonts / icons, so the app looks
    broken. At every start: when the prepared static files do not match this version, prepare them again (a few seconds, only when needed)."""
    import django
    from pathlib import Path
    django.setup()
    root = Path(settings.STATIC_ROOT)
    marker = root / '.edunest_version'
    vf = Path(settings.BASE_DIR).parent / 'VERSION'
    ver = vf.read_text().strip() if vf.exists() else '0'
    ok = (root / 'vendor' / 'app.css').exists() and marker.exists() and marker.read_text().strip() == ver
    if ok:
        return
    log.info('Preparing the screens (CSS, fonts, icons) for version %s ...', ver)
    try:
        from django.core.management import call_command
        call_command('collectstatic', interactive=False, verbosity=0)
        marker.write_text(ver)
    except Exception as e:                                   # never stop the school from starting
        log.warning('Could not prepare the screens: %s', e)


def port_owner(port):
    """Windows: who holds this port (shown in the log when the server cannot start)."""
    if os.name != 'nt':
        return ''
    try:
        import subprocess
        out = subprocess.run(['netstat', '-ano', '-p', 'tcp'], capture_output=True, text=True, timeout=10).stdout
        pids = sorted({c[4] for c in (l.split() for l in out.splitlines()) if len(c) >= 5 and c[1].rsplit(':', 1)[-1] == str(port) and c[0].upper() == 'TCP'})
        names = []
        for pid in pids[:4]:
            t = subprocess.run(['tasklist', '/FI', f'PID eq {pid}', '/FO', 'CSV', '/NH'], capture_output=True, text=True, timeout=10).stdout.strip().split(',')[0].strip('"')
            names.append(f'{t} (PID {pid})')
        return ', '.join(names)
    except Exception:
        return ''


def port_free(port):
    import socket
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        if os.name != 'nt':
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind(('0.0.0.0', port))
        return True
    except OSError:
        return False
    finally:
        s.close()


def wait_ports(ports, log, secs=90):
    """After a restart / stop the old server may still be letting go of its ports for a few seconds. Wait for them instead of giving up (before, one busy port
    ended the server for good and it stayed OFF until somebody started it by hand)."""
    end = time.time() + secs
    told = False
    while True:
        busy = [p for p in ports if not port_free(p)]
        if not busy:
            return True
        if not told:
            log.warning('Port %s is still in use%s. Waiting up to %s s for it to be released ...', ', '.join(map(str, busy)),
                        (' by ' + port_owner(busy[0])) if port_owner(busy[0]) else '', secs)
            told = True
        if time.time() > end:
            log.error('Port %s is still in use%s. Giving up.', ', '.join(map(str, busy)), (' by ' + port_owner(busy[0])) if port_owner(busy[0]) else '')
            return False
        time.sleep(1)


def main():
    log = logging.getLogger('serve')
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s',
                        handlers=[logging.handlers.RotatingFileHandler(settings.DATA_DIR / 'server.log', maxBytes=2_000_000, backupCount=3, encoding='utf-8'),
                                  logging.StreamHandler(sys.stdout)])
    ensure_static(log)
    app = get_wsgi_application()
    from sync import control  # noqa: E402
    control.clear()
    from sync import perms  # noqa: E402
    if perms.ensure_default_admin():
        log.warning('No user existed: created the default Administrator (username admin, password admin123). Change the password after the first login.')
    cert = pick_cert()
    wait_ports([settings.ERP_HTTP_PORT] + ([settings.ERP_HTTPS_PORT] if cert else []), log)
    domain = os.environ.get('ERP_DOMAIN', '').strip().lower()
    http_app = https_redirect(app, domain, settings.ERP_HTTPS_PORT, log) if (cert and cert[2] == 'trusted' and domain) else app
    servers = [('http', Server(('0.0.0.0', settings.ERP_HTTP_PORT), http_app, numthreads=int(os.environ.get("ERP_THREADS", "300")), timeout=60))]
    https = None
    if cert:
        https = Server(('0.0.0.0', settings.ERP_HTTPS_PORT), app, numthreads=int(os.environ.get("ERP_THREADS", "300")), timeout=60)
        https.ssl_adapter = BuiltinSSLAdapter(str(cert[0]), str(cert[1]))
        servers.append(('https', https))
        log.info('https uses the %s certificate', 'TRUSTED (Let\'s Encrypt)' if cert[2] == 'trusted' else 'school')
    else:
        log.warning('No https certificate yet (run: python manage.py make_cert). Only http is available.')
    errors = []

    def run(name, srv):
        try:
            srv.start()
        except OSError as e:
            errors.append(name)
            log.error('Cannot start %s on port %s: %s. Is School ERP already running (another black window or the automatic service)?', name, srv.bind_addr[1], e)
        except Exception:
            errors.append(name)
            log.exception('%s server stopped', name)

    threads = [threading.Thread(target=run, args=(n, s), daemon=True) for n, s in servers]
    for t in threads:
        t.start()
    time.sleep(1.5)
    if errors:
        for _, s in servers:
            try:
                s.stop()
            except Exception:
                pass
        sys.exit(1)
    threading.Thread(target=maintenance, args=(https, log), daemon=True).start()
    threading.Thread(target=dns_watch, args=(log,), daemon=True).start()

    def heal_media():                                        # photos whose link points to an upload that was renamed meanwhile (broken-picture sign) get the right link
        try:
            from sync import medianame
            n, sc = medianame.rename_all()
            if n or sc:
                log.info('Photo / document links checked: %s student record(s) and %s school setting(s) corrected', n, sc)
        except Exception as e:
            log.warning('Photo link check skipped: %s', e)
    threading.Thread(target=heal_media, daemon=True).start()
    from sync import control, runtime  # noqa: E402  (cloud apps <-> ERP, event driven; each group starts only when it is set up in config.env / Setup > Cloud Connections)
    runtime.start_all()
    log.info('School ERP is running: http port %s%s', settings.ERP_HTTP_PORT, f', https port {settings.ERP_HTTPS_PORT}' if len(servers) > 1 else '')
    try:                                                      # tell the school, in plain words, what to type on the other devices
        from sync.management.commands.get_cert import primary_ip
        ip = primary_ip()
        if domain and cert and cert[2] == 'trusted':
            log.info('OPEN ON EVERY DEVICE:  http://%s:%s   (it moves to https by itself)', domain, settings.ERP_HTTP_PORT)
            log.info('If a device says "site can\'t be reached" / DNS error, it cannot find that name. On that device use:  http://%s:%s', ip, settings.ERP_HTTP_PORT)
        else:
            log.info('OPEN ON OTHER DEVICES:  http://%s:%s%s', ip, settings.ERP_HTTP_PORT, f'   or   https://{ip}:{settings.ERP_HTTPS_PORT}' if len(servers) > 1 else '')
    except Exception as e:
        log.info('Address hint skipped: %s', e)
    exit_code = 0
    try:
        while any(t.is_alive() for t in threads):
            want = control.pending()                  # a Restart / Stop asked for in the ERP or by ERP.bat
            if want:
                log.info('School ERP is %s as asked', 'restarting' if want == 'restart' else 'stopping')
                exit_code = control.RESTART_CODE if want == 'restart' else 0
                break
            time.sleep(1)
    except KeyboardInterrupt:
        pass
    finally:
        try:
            from sync import views as _views
            _views.begin_shutdown()                           # held long-poll requests answer at once
        except Exception:
            pass
        runtime.stop_all()
        stoppers = []
        for _, s in servers:                                  # stop both servers at the same time; never wait for ever
            t = threading.Thread(target=lambda srv=s: srv.stop(), daemon=True)
            t.start()
            stoppers.append(t)
        end = time.time() + 8
        for t in stoppers:
            t.join(max(0.1, end - time.time()))
        control.clear()
    logging.shutdown()
    os._exit(exit_code)                   # leave at once even if a request is still open: a slow exit kept the ports busy (exit code 75 = start again)


if __name__ == '__main__':
    main()
