/* Setup > School Setup > "Cloud Sync" tab (administrators only): connect the cloud apps (eGateSys, Result portal, online fee, attendance) to this ERP.
   Fill a card, press Test, then Save: it is saved on the school server (data/config.env) and starts working at once (no restart).
   Disconnect stops that app's sync at once and forgets its address / secrets. A secret is never shown again.
   The tab and its panel are part of the ERP page (see build_frontend.py); this file fills the panel in. */
(function () {
  'use strict';
  var G = [], TOKEN = function () { return localStorage.getItem('erp_token'); };
  var $ = function (id) { return document.getElementById(id); };
  var esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };
  function api(method, url, body) {
    return fetch('/api/sync/' + url, { method: method, headers: { 'Authorization': 'Token ' + TOKEN(), 'Content-Type': 'application/json' }, body: body === undefined ? undefined : JSON.stringify(body) })
      .then(function (r) { return r.json().catch(function () { return {}; }).then(function (j) { j.status = r.status; return j; }); });
  }
  function admin() { try { return typeof usrCan === 'function' && usrCan('adminZone', 'edit'); } catch (e) { return false; } }
  function note(text, bad) { var n = $('cloudSetupNote'); if (n) { n.textContent = text || ''; n.className = 'text-xs min-h-[1rem] ' + (bad ? 'text-red-600' : 'text-green-700'); } }

  function draw() {
    $('cloudSetupBody').innerHTML = G.map(function (g) {
      var f = g.fields.map(function (x) {
        var ph = x.kind === 'secret' ? (x.set ? '\u25CF\u25CF\u25CF\u25CF saved (leave empty to keep)' : '') : (x.default || '');
        return '<div class="mf"><label>' + esc(x.label) + (x.kind === 'secret' && x.set ? ' <span class="font-normal text-gray-500"><input type="checkbox" data-clear="' + x.key + '"> remove the saved one</span>' : '') + '</label>' +
          '<input ' + (x.kind === 'secret' ? 'type="password" autocomplete="new-password"' : 'type="text" autocomplete="off"') + ' data-key="' + x.key + '" value="' + esc(x.value) + '" placeholder="' + esc(ph) + '">' +
          (x.help ? '<div class="text-[11px] text-gray-500 dark:text-gray-400 mt-0.5">' + esc(x.help) + '</div>' : '') + '</div>';
      }).join('');
      return '<div class="rounded-2xl border border-[#e0e3e7] dark:border-[#3c4043] p-4 flex flex-col gap-3" data-cs-group="' + g.id + '">' +
        '<div class="flex items-center justify-between gap-2"><div><div class="rc-card-title"><span class="material-symbols-outlined">cloud_sync</span>' + esc(g.title) + '</div><p class="text-xs text-gray-500 dark:text-gray-400">' + esc(g.sub) + '</p></div>' +
        badge(g) + '</div>' + f +
        '<div class="flex flex-wrap gap-2"><button type="button" class="rc-btn" data-act="test" data-g="' + g.id + '">Test</button><button type="button" class="rc-btn rc-btn-primary" data-act="save" data-g="' + g.id + '">Save</button>' +
        (g.on ? '<button type="button" class="rc-btn" data-act="fetch" data-g="' + g.id + '" title="Brings in everything the cloud has (also what came while this was not connected). Nothing in the cloud is deleted."><span class="material-symbols-outlined">cloud_download</span>Fetch all data now</button>' : '') +
        (g.on ? '<button type="button" class="rc-btn ml-auto text-red-600" data-act="disconnect" data-g="' + g.id + '" data-t="' + esc(g.title) + '">Disconnect</button>' : '') + '</div>' +
        '<div class="text-xs" data-cs-res="' + g.id + '"></div></div>';
    }).join('');
  }
  function badge(g) {
    var st = g.running ? ['RUNNING', 'border-green-600 text-green-700'] : g.on ? ['SET UP, NOT RUNNING', 'border-amber-500 text-amber-700'] : ['OFF', 'border-gray-300 text-gray-500'];
    return '<span class="px-2 py-0.5 rounded-full text-[11px] font-bold border ' + st[1] + '">' + st[0] + '</span>';
  }
  function collect(gid) {
    var card = document.querySelector('[data-cs-group="' + gid + '"]'), values = {}, clear = [];
    card.querySelectorAll('input[data-key]').forEach(function (i) { values[i.getAttribute('data-key')] = i.value; });
    card.querySelectorAll('input[data-clear]').forEach(function (c) { if (c.checked) clear.push(c.getAttribute('data-clear')); });
    return { values: values, clear: clear };
  }
  function show(gid, lines) {
    document.querySelector('[data-cs-res="' + gid + '"]').innerHTML = lines.map(function (l) { return '<div class="' + (l.ok ? 'text-green-700' : 'text-red-600') + '">' + (l.ok ? '\u2713 ' : '\u2717 ') + esc(l.message) + '</div>'; }).join('');
  }
  function fail(text) { $('cloudSetupBody').innerHTML = '<p class="text-sm text-red-600">' + esc(text) + '</p>'; }

  function load() {
    note('');
    if (!TOKEN()) return fail('Please log in to the ERP first.');
    $('cloudSetupBody').innerHTML = '<p class="text-sm text-gray-500">Loading ...</p>';
    api('GET', 'cloud-setup/').then(function (j) {
      if (j.status === 403) return fail('Only an administrator can change the cloud connections. Log in as the administrator.');
      if (!j.groups) return fail('Could not load the settings (HTTP ' + j.status + ').');
      G = j.groups; draw();
    });
  }
  document.addEventListener('click', function (e) {
    var b = e.target.closest && e.target.closest('#cloudSetupBody button[data-act]'); if (!b) return;
    var gid = b.getAttribute('data-g'), act = b.getAttribute('data-act');
    if (act === 'disconnect') {
      if (!window.confirm('Disconnect ' + b.getAttribute('data-t') + '?\n\nSyncing with this app stops now and its saved address and secrets are removed from this server. Nothing in the cloud app itself is deleted. You can connect again any time.')) return;
      b.disabled = true;
      return api('POST', 'cloud-setup/disconnect/', { group: gid }).then(function (j) {
        b.disabled = false;
        if (!j.groups) return show(gid, [{ ok: false, message: 'Could not disconnect (HTTP ' + j.status + ').' }]);
        G = j.groups; draw(); note('Disconnected. Syncing with ' + b.getAttribute('data-t') + ' has stopped.');
      });
    }
    if (act === 'fetch') {
      if (!window.confirm('Fetch all data from the cloud now?\n\nEverything the cloud has is brought into this ERP, also what came while this app was not connected. Nothing in the cloud is deleted; what the ERP already has is not duplicated.')) return;
      b.disabled = true; show(gid, [{ ok: true, message: 'Fetching ... (this can take a minute)' }]);
      return api('POST', 'cloud-setup/fetch/', { group: gid }).then(function (j) {
        if (!j.ok) { b.disabled = false; return show(gid, [{ ok: false, message: j.error || ('Could not start (HTTP ' + j.status + ').') }]); }
        var tries = 0;
        (function poll() {
          api('GET', 'cloud-setup/fetch/').then(function (r) {
            var f = (r.fetch || {})[gid] || {};
            if (f.state === 'running' && tries++ < 300) return setTimeout(poll, 2000);
            b.disabled = false;
            show(gid, [{ ok: f.state === 'done', message: f.state === 'done' ? 'Done. ' + f.text : f.state === 'error' ? 'Failed: ' + f.text : 'Still running in the background. Press again later to see the result.' }]);
          });
        })();
      });
    }
    var c = collect(gid); b.disabled = true;
    if (act === 'test') {
      show(gid, [{ ok: true, message: 'Testing ...' }]);
      api('POST', 'cloud-setup/test/', { group: gid, values: c.values }).then(function (j) { b.disabled = false; show(gid, j.results || [{ ok: false, message: 'The test could not run (HTTP ' + j.status + ').' }]); });
    } else {
      api('POST', 'cloud-setup/', { values: c.values, clear: c.clear }).then(function (j) {
        b.disabled = false;
        if (j.status === 400 && j.errors) return show(gid, Object.keys(j.errors).map(function (k) { return { ok: false, message: k + ': ' + j.errors[k] }; }));
        if (!j.groups) return show(gid, [{ ok: false, message: 'Could not save (HTTP ' + j.status + ').' }]);
        G = j.groups; draw();
        var g = G.filter(function (x) { return x.id === gid; })[0] || {};
        show(gid, [{ ok: true, message: 'Saved.' }]);
        note(g.running ? 'Saved. Connected and running now.' : 'Saved. It starts as soon as every required box is filled in.');
      });
    }
  });

  window.cloudFill = load;                       // called by masterTab('cloud') every time the tab is opened
})();
