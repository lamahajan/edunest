/* Server-only storage for UI.html. The browser keeps NOTHING of the school's data: `localStorage` is replaced by an
   in-memory copy that is filled from the server before the app starts, every write goes to the server (versioned, so
   two PCs cannot silently overwrite each other) and other PCs' changes are applied live. Only the sign-in token stays
   in the browser. Photos / PDFs are stored as files on the server. */
(function () {
  'use strict';
  var TOKEN = localStorage.getItem('erp_token');
  if (!TOKEN) { location.replace('/login/'); throw new Error('not signed in'); }
  var realLS = window.localStorage, SP = Storage.prototype;
  var oGet = SP.getItem, oSet = SP.setItem, oRem = SP.removeItem, oKey = SP.key, oClear = SP.clear;
  var oLen = Object.getOwnPropertyDescriptor(SP, 'length');
  var BASE = '2026-2027';
  var PERUSER = { eacademics_lastuser: 1, eacademics_rcopts: 1, eacademics_rcdesign: 1, eacademics_activesess: 1 };  // stored per login user, on the server
  var SRV = {}, APPBASE = {};   // SRV: last value known on the server; APPBASE: what the app itself last loaded/wrote, per settings key
  var MEM = {}, ERP = window.ERP = { boot: null, last: 0, ver: {}, admSnap: {}, admVer: {}, stale: false, user: '' };

  // what an older, browser-only version of the app left behind (imported once if the server is still empty)
  var legacy = {};
  for (var i = 0, n = oLen.get.call(realLS); i < n; i++) { var lk = oKey.call(realLS, i); if (/^eacademics_/.test(lk)) legacy[lk] = oGet.call(realLS, lk); }

  function xhrGet(url) { var x = new XMLHttpRequest(); x.open('GET', url, false); x.setRequestHeader('Authorization', 'Token ' + TOKEN); x.send(); return x; }
  function api(method, url, body) {
    return fetch('/api/sync/' + url, { method: method, headers: { 'Authorization': 'Token ' + TOKEN, 'Content-Type': 'application/json' }, body: body === undefined ? undefined : JSON.stringify(body) })
      .then(function (r) { if (r.status === 401) { oRem.call(realLS, 'erp_token'); location.replace('/login/'); } return r.json().catch(function () { return {}; }).then(function (j) { return { status: r.status, ok: r.ok, body: j }; }); });
  }
  function toast(m) { try { showToast(m); } catch (e) { console.log(m); } }
  var admKey = function (s) { return s === BASE ? 'eacademics_adm' : 'eacademics_s' + s + '_adm'; };
  var admSess = function (k) { var m = /^eacademics_(?:s(.+)_)?adm$/.exec(k); return m ? (m[1] || BASE) : null; };
  var srvKey = function (k) { return PERUSER[k] ? 'u/' + ERP.user + '/' + k : k; };
  var curSess = function () { try { return SESS; } catch (e) { return MEM.eacademics_activesess || BASE; } };

  // ---- 1. synchronous bootstrap (runs before the app reads its data)
  var HINT = ''; try { HINT = oGet.call(realLS, 'eacademics_activesess') || ''; } catch (e) {}
  var bx; try { bx = xhrGet('/api/sync/bootstrap/' + (HINT ? '?sess=' + encodeURIComponent(HINT) : '')); } catch (e) { document.write('<p style="font-family:sans-serif;padding:2rem">Cannot reach the server.</p>'); throw e; }
  if (bx.status === 401) { oRem.call(realLS, 'erp_token'); location.replace('/login/'); throw new Error('unauthorised'); }
  if (bx.status === 403) { oRem.call(realLS, 'erp_token'); location.replace('/login/'); throw new Error('account not active'); }
  if (bx.status !== 200) { document.write('<p style="font-family:sans-serif;padding:2rem">Server error ' + bx.status + '</p>'); throw new Error('bootstrap failed'); }
  var B = ERP.boot = JSON.parse(bx.responseText);
  (function () {   // the page opens another session than the one the server sent (changed on another PC)? fetch everything once, as before
    try {
      if (B.adm_session && B.adm_session !== 'all') {
        var v = (B.kv['u/' + B.user + '/eacademics_activesess'] || {}).v, want = v ? String(v).replace(/^"|"$/g, '') : '', ss = JSON.parse((B.kv.eacademics_sessions || {}).v || 'null');
        if (!want && ss && ss.length) want = ss[ss.length - 1].id;
        if (want && want !== B.adm_session) { var b2 = xhrGet('/api/sync/bootstrap/?sess=all'); if (b2.status === 200) B = ERP.boot = JSON.parse(b2.responseText); }
      }
    } catch (e) {}
  })();
  ERP.last = B.last; ERP.user = B.user;
  var mine = 'u/' + B.user + '/';
  Object.keys(B.kv).forEach(function (k) {
    var local = k.indexOf(mine) === 0 ? k.slice(mine.length) : k;
    MEM[local] = SRV[local] = APPBASE[local] = B.kv[k].v; ERP.ver[local] = B.kv[k].ver;
  });
  var bySess = {};
  B.adm.forEach(function (d) { var s = d.key.split('|')[0]; (bySess[s] = bySess[s] || []).push(d.data); ERP.admSnap[d.key] = JSON.stringify(d.data); ERP.admVer[d.key] = d.version; });
  Object.keys(bySess).forEach(function (s) { MEM[admKey(s)] = JSON.stringify(bySess[s]); });
  if (!B.seeded) { Object.keys(legacy).forEach(function (k) { MEM[k] = legacy[k]; }); }     // first run: bring the old browser data along
  Object.keys(PERUSER).forEach(function (pk) {
    if (!MEM[pk]) { try { var lv = oGet.call(realLS, pk); if (lv) MEM[pk] = lv; } catch (e) {} }
  });
  if (!MEM.eacademics_activesess) {                                                           // new user: open the latest session
    try { var ss = JSON.parse(MEM.eacademics_sessions || 'null'); if (ss && ss.length) MEM.eacademics_activesess = ss[ss.length - 1].id; } catch (e) {}
  }

  // ---- 2. photos / PDFs (data URLs) become files on the server; records keep only a short URL
  var DATA_RE = /data:(image\/(?:jpeg|png|webp|gif)|application\/pdf);base64,[A-Za-z0-9+\/=]{1500,}/g;
  var EXT = { 'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp', 'image/gif': 'gif', 'application/pdf': 'pdf' };
  var PENDING = {}, DONE = {};
  function h53(s, seed) {
    var h1 = 0xdeadbeef ^ seed, h2 = 0x41c6ce57 ^ seed;
    for (var i = 0, c; i < s.length; i++) { c = s.charCodeAt(i); h1 = Math.imul(h1 ^ c, 2654435761); h2 = Math.imul(h2 ^ c, 1597334677); }
    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
    return (h2 >>> 0).toString(16).padStart(8, '0') + (h1 >>> 0).toString(16).padStart(8, '0');
  }
  function upload(name) {
    api('POST', 'files/', { name: name, data: PENDING[name] }).then(function (r) {
      if (r.ok) { delete PENDING[name]; DONE[name] = 1; }
      else if (r.status >= 500) setTimeout(function () { upload(name); }, 5000);
      else { delete PENDING[name]; toast('A photo/file could not be saved on the server: ' + (r.body.error || r.status)); }
    }, function () { setTimeout(function () { upload(name); }, 5000); });
  }
  function offload(v) {
    if (v.indexOf('data:') < 0) return v;
    return v.replace(DATA_RE, function (m, mime) {
      var name = h53(m, 0) + h53(m, 1) + m.length.toString(36);
      if (!PENDING[name] && !DONE[name]) { PENDING[name] = m; upload(name); }
      return '/media/' + name + '.' + EXT[mime];
    });
  }
  ERP.pendingFiles = function () { return Object.keys(PENDING).length; };

  // ---- merge: put this user's changes on top of whatever other users saved in the meantime (nothing is overwritten)
  var jeq = function (a, b) { return JSON.stringify(a) === JSON.stringify(b); };
  var isObj = function (x) { return x && typeof x === 'object' && !Array.isArray(x); };
  var has = function (x) { return x !== undefined; };
  var ID_KEYS = ['id', 'adm', 'sid', 'key', 'v'];
  function idKeyOf(arrs) {
    for (var i = 0; i < ID_KEYS.length; i++) {
      var ok = true, any = false;
      for (var a = 0; a < arrs.length && ok; a++) for (var j = 0; j < arrs[a].length; j++) { any = true; var it = arrs[a][j]; if (!isObj(it) || it[ID_KEYS[i]] === undefined) { ok = false; break; } }
      if (ok && any) return ID_KEYS[i];
    }
    return null;
  }
  function merge3(b, l, r) {
    if (jeq(l, b)) return r;                       // I changed nothing
    if (jeq(r, b) || jeq(l, r)) return l;          // nobody else changed anything / same result
    if (isObj(l) && isObj(r)) {
      var bb = isObj(b) ? b : {}, out = {}, keys = {};
      Object.keys(r).concat(Object.keys(l)).forEach(function (k) { keys[k] = 1; });
      Object.keys(keys).forEach(function (k) {
        var lv = l[k], rv = r[k], bv = bb[k];
        if (!has(lv)) { if (has(bv) && has(rv) && jeq(rv, bv)) return; if (has(rv)) out[k] = rv; }     // I deleted it: delete, unless someone else changed it
        else if (!has(rv)) { if (has(bv) && jeq(lv, bv)) return; out[k] = lv; }                          // someone deleted it: delete, unless I changed it
        else out[k] = merge3(bv, lv, rv);
      });
      return out;
    }
    if (Array.isArray(l) && Array.isArray(r)) {
      var ba = Array.isArray(b) ? b : [], idk = idKeyOf([l, r, ba]);
      if (idk) {
        var bm = {}, lm = {}, rm = {}, res = [];
        ba.forEach(function (x) { bm[x[idk]] = x; }); l.forEach(function (x) { lm[x[idk]] = x; }); r.forEach(function (x) { rm[x[idk]] = x; });
        r.forEach(function (x) { var id = x[idk]; if (id in lm) res.push(merge3(bm[id], lm[id], x)); else if (!(id in bm) || !jeq(bm[id], x)) res.push(x); });
        l.forEach(function (x) { var id = x[idk]; if (!(id in rm) && (!(id in bm) || !jeq(bm[id], x))) res.push(x); });
        return res;
      }
      var pre = function (p, a) { if (a.length < p.length) return false; for (var i = 0; i < p.length; i++) if (!jeq(p[i], a[i])) return false; return true; };
      if (pre(ba, l) && pre(ba, r)) return r.concat(l.slice(ba.length));    // log-style lists: keep everybody's new lines
      return l;
    }
    return l;                                      // both changed the same single value: mine wins
  }
  function mergeStr(b, l, r) {
    try { return JSON.stringify(merge3(b === undefined ? undefined : JSON.parse(b), JSON.parse(l), JSON.parse(r))); } catch (e) { return l; }
  }
  ERP.merge = mergeStr;
  var LIVE = { eacademics_concreq: 1, eacademics_gp: 1, eacademics_gp_tg: 1, eacademics_refreg: 1 };   // screens that refresh themselves when told another PC changed the data
  var LIVEFN = {}; ERP.liveFn = LIVEFN;   // erp-live-all.js registers, per setting, a function that loads another PC's change into the page's own data in place (no reload)
  function applyLive(k) { var f = LIVEFN[k]; if (!f) return false; try { return f(MEM[k]) !== false; } catch (e) { console.warn(e); return false; } }   // false = could not apply: the old "refresh when safe" path runs
  var QUIET = { eacademics_actlog: 1, eacademics_msglog: 1 };      // busy logs: updated silently, no "data changed" banner
  var SYNCKV = function (k) { return /^eacademics_/.test(k) && !PERUSER[k] && !admSess(k); };

  // ---- 3. write-through (retried until the server has it; nothing is dropped silently)
  var timers = {}, pending = {}, flying = [];
  function track(p) { flying.push(p); var done = function () { var i = flying.indexOf(p); if (i >= 0) flying.splice(i, 1); try { window.dispatchEvent(new Event('erp-changed')); } catch (e) {} }; p.then(done, done); return p; }   // 'erp-changed': my own save reached the server
  function send(method, url, body, tries) {
    tries = tries || 0;
    return api(method, url, body).then(function (r) {
      if (r.status < 500 || tries >= 10) return r;
      return new Promise(function (res) { setTimeout(res, 1500 * (tries + 1)); }).then(function () { return send(method, url, body, tries + 1); });
    }, function () {
      if (tries >= 10) return { ok: false, status: 0, body: {} };
      return new Promise(function (res) { setTimeout(res, 1500 * (tries + 1)); }).then(function () { return send(method, url, body, tries + 1); });
    });
  }
  function schedule(key, fn, delay) {
    clearTimeout(timers[key]); pending[key] = fn;
    timers[key] = setTimeout(function () { var f = pending[key]; delete pending[key]; if (f) track(f()); }, delay);
  }
  function flush() {
    Object.keys(pending).forEach(function (key) { clearTimeout(timers[key]); var f = pending[key]; delete pending[key]; track(f()); });
    return Promise.all(flying.slice());
  }
  ERP.flush = flush;
  ERP.api = api; ERP.send = send;
  ERP.signOut = function () { flush().then(function () { oRem.call(realLS, 'erp_token'); location.replace('/login/'); }); };
  ERP.reload = function () { flush().then(function () { location.reload(); }); };
  ERP.unsaved = function () { return Object.keys(pending).length + flying.length + Object.keys(PENDING).length; };
  window.addEventListener('beforeunload', function (e) { if (ERP.unsaved()) { e.preventDefault(); e.returnValue = ''; } });
  window.addEventListener('pagehide', function () { Object.keys(pending).forEach(function (key) { try { var f = pending[key]; delete pending[key]; f(); } catch (x) {} }); });
  function pushKv(k, tries) {
    tries = tries || 0;
    if (!(k in MEM)) return Promise.resolve();
    var sent = MEM[k];
    return send('PUT', 'kv/' + (PERUSER[k] ? 'u/' + encodeURIComponent(ERP.user) + '/' + encodeURIComponent(k) : encodeURIComponent(k)) + '/', { data: sent, base_version: ERP.ver[k] || null }).then(function (r) {
      if (r.ok) { ERP.ver[k] = r.body.version; SRV[k] = sent; }
      else if (r.status === 409 && tries < 6) {          // someone saved at the same moment: re-apply our change on top of theirs
        MEM[k] = mergeStr(SRV[k], MEM[k], r.body.data); SRV[k] = r.body.data; ERP.ver[k] = r.body.version;
        if (!QUIET[k] && !PERUSER[k]) stale('Another user saved at the same time; both changes were kept');
        return MEM[k] === SRV[k] ? undefined : pushKv(k, tries + 1);
      }
      else if (r.status === 403) { toast('You do not have permission to change “' + k.replace('eacademics_', '') + '”'); stale('That change was not saved', true); }
      else toast('Could not save “' + k.replace('eacademics_', '') + '” on the server');
    });
  }
  function delKv(k) { delete ERP.ver[k]; return track(send('DELETE', 'kv/' + encodeURIComponent(srvKey(k)) + '/')); }
  function pushAdm(sess) {
    var arr; try { arr = JSON.parse(MEM[admKey(sess)] || '[]'); } catch (e) { return Promise.resolve(); }
    var seen = {}, pre = sess + '|', jobs = [];
    arr.forEach(function (a) {
      var key = pre + a.adm; seen[key] = 1; var s = JSON.stringify(a); if (ERP.admSnap[key] === s) return;
      ERP.admSnap[key] = s;
      jobs.push(send('PUT', 'adm/' + encodeURIComponent(key) + '/', { data: a, base_version: ERP.admVer[key] || null }).then(function (r) {
        if (r.ok) ERP.admVer[key] = r.body.version;
        else if (r.status === 409) { ERP.admVer[key] = r.body.version; ERP.admSnap[key] = JSON.stringify(r.body.data); stale('Admission ' + a.adm + ' was changed by another user', true); }
        else if (r.status === 403) { toast('You do not have permission to change student records'); stale('That change was not saved', true); }
        else toast('Could not save admission ' + a.adm + ' on the server');
      }));
    });
    Object.keys(ERP.admSnap).forEach(function (key) {
      if (key.indexOf(pre) !== 0 || seen[key]) return; delete ERP.admSnap[key]; delete ERP.admVer[key];
      jobs.push(send('DELETE', 'adm/' + encodeURIComponent(key) + '/'));
    });
    return Promise.all(jobs);
  }
  function onWrite(k) {
    if (!B.seeded) return;                            // first run: everything is uploaded together after the seed
    var s = admSess(k);
    if (s) schedule('a' + s, function () { return pushAdm(s); }, 300);
    else schedule(k, function () { return pushKv(k); }, 400);
  }

  // ---- 4. `localStorage` lives in memory (the real browser storage is never touched, except for the sign-in token)
  var isApp = function (t, k) { return t === realLS && k !== 'erp_token'; };
  SP.getItem = function (k) { return isApp(this, k) ? (Object.prototype.hasOwnProperty.call(MEM, k) ? MEM[k] : null) : oGet.call(this, k); };
  SP.setItem = function (k, v) {
    if (!isApp(this, k)) return oSet.call(this, k, v);
    k = String(k); v = String(v); if (/^eacademics_/.test(k)) v = offload(v);
    if (B.seeded && SYNCKV(k)) {
      var own = v, cur = MEM[k];
      if (cur !== undefined && cur !== v && APPBASE[k] !== cur) v = mergeStr(APPBASE[k], v, cur);   // others changed it since this page loaded/wrote it
      APPBASE[k] = own;
    }
    MEM[k] = v; if (PERUSER[k]) { try { oSet.call(realLS, k, v); } catch (e) {} } onWrite(k);
  };
  SP.removeItem = function (k) {
    if (!isApp(this, k)) return oRem.call(this, k);
    if (!(k in MEM)) return; delete MEM[k];
    if (!B.seeded) return;
    var s = admSess(k); if (s) onWrite(k); else delKv(k);
  };
  SP.key = function (i) { return this === realLS ? (Object.keys(MEM)[i] || null) : oKey.call(this, i); };
  SP.clear = function () { if (this !== realLS) return oClear.call(this); Object.keys(MEM).forEach(function (k) { SP.removeItem.call(realLS, k); }); };
  Object.defineProperty(SP, 'length', { configurable: true, get: function () { return this === realLS ? Object.keys(MEM).length : oLen.get.call(this); } });

  // ---- 5. receipts (called from the patched rcSave / rcDelete)
  function clean(rec) { var o = {}; Object.keys(rec).forEach(function (k) { if (k[0] !== '_') o[k] = rec[k]; }); return o; }
  ERP.pushReceipt = function (rec, isNew) {
    var req = track(isNew ? send('POST', 'receipts/', { session: curSess(), data: clean(rec) })
                    : send('PUT', 'receipts/' + rec._sid + '/', { session: curSess(), data: clean(rec), base_version: rec._ver }));
    req.then(function (r) {
      if (r.ok) { rec._sid = r.body.id; rec._ver = r.body.version; return; }
      var i = RC_RECEIPTS.indexOf(rec);   // server said no: undo locally
      if (isNew) { if (i >= 0) RC_RECEIPTS.splice(i, 1); }
      else if (i >= 0 && rec._prev) RC_RECEIPTS[i] = rec._prev;
      toast(r.body.detail || (r.status === 409 ? 'Receipt was changed by another user — reloaded' : 'Could not save the receipt'));
      poll(true);
    });
  };
  ERP.removeReceipt = function (rec) {
    if (rec._sid) track(send('DELETE', 'receipts/' + rec._sid + '/')).then(function (r) { if (!r.ok && r.status !== 404) toast('Could not delete on the server'); });
  };

  // ---- 6. live updates from other PCs
  // Auto-refresh: when another PC changed something this screen cannot show by itself, the page reloads on its own - but only when that is
  // safe (nothing unsaved, nobody typing in a field, no key/click for a few seconds). Otherwise the blue "click to refresh" bar stays.
  var lastAct = Date.now(), armed = false;
  ['keydown', 'input', 'mousedown', 'touchstart'].forEach(function (ev) { document.addEventListener(ev, function () { lastAct = Date.now(); }, true); });
  function editing() { var a = document.activeElement; return !!a && (/^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName) || a.isContentEditable); }
  function modalOpen() { try { return !!document.querySelector('.modal-card:not(.hidden), #rcDlgOverlay, [role=dialog]'); } catch (e) { return false; } }   // a Setup / dialog window is open: never reload under it (unsaved edits would be lost)
  function midReceipt() { try { return typeof rc !== 'undefined' && rc.mode === 'new' && !!rc.adm; } catch (e) { return false; } }   // cashier has a student open in a new, not yet saved receipt: never wipe it
  function refreshNow() {
    try { var ss = JSON.parse(MEM.eacademics_sessions || '[]'), last = ss[ss.length - 1].id, prev = (ss[ss.length - 2] || {}).id;   // a new session was started on another PC: move this user to it
      if (last && (!MEM.eacademics_activesess || MEM.eacademics_activesess === prev)) { MEM.eacademics_activesess = last; pushKv('eacademics_activesess'); } } catch (e) {}
    ERP.flush().then(function () { setTimeout(function () { location.reload(); }, 200); });
  }
  function arm() {                                     // true when an automatic refresh is (now) waiting for a quiet moment
    if (armed) return true;
    var hist = []; try { hist = JSON.parse(sessionStorage.getItem('erp_autoref') || '[]').filter(function (t) { return Date.now() - t < 60000; }); } catch (e) {}
    if (hist.length >= 6) return false;               // more than 6 automatic refreshes in a minute = something is looping: stop and leave the click bar
    armed = true;
    setInterval(function () {
      if (ERP.unsaved() || editing() || modalOpen() || midReceipt() || Date.now() - lastAct < 600) return;
      hist.push(Date.now()); try { sessionStorage.setItem('erp_autoref', JSON.stringify(hist)); } catch (e) {}
      refreshNow();
    }, 250);
    return true;
  }
  var BAR = null;
  function stale(msg, manual) {                        // normal case: NO notice at all - the page re-reads the data by itself as soon as it is safe.
    if (!manual && arm()) return;                      // manual = my own change was NOT saved / was overwritten: the person must see that, so the blue bar stays for it
    ERP.stale = true;
    var txt = msg + ' — click to refresh';
    if (!BAR) {
      BAR = document.createElement('div');
      BAR.style.cssText = 'position:fixed;left:50%;bottom:16px;transform:translateX(-50%);z-index:99999;background:#042449;color:#fff;padding:10px 18px;border-radius:999px;font:500 13px Roboto,Arial;cursor:pointer;box-shadow:0 4px 12px rgba(0,0,0,.3)';
      BAR.onclick = refreshNow;
      document.body.appendChild(BAR);
    }
    BAR.textContent = txt;
  }
  function applyReceipts(items) {
    var ses = curSess(), cur = rc.idx >= 0 && RC_RECEIPTS[rc.idx] ? RC_RECEIPTS[rc.idx]._sid : null, changed = false;
    items.forEach(function (it) {
      var i = RC_RECEIPTS.findIndex(function (r) { return r._sid === it.id; });
      if (it.deleted) { if (i >= 0) { RC_RECEIPTS.splice(i, 1); changed = true; } return; }
      if (it.session !== ses) { if (i >= 0) { RC_RECEIPTS.splice(i, 1); changed = true; } return; }
      if (i >= 0 && RC_RECEIPTS[i]._ver === it.version) return;
      var rec = Object.assign({}, it.data, { _sid: it.id, _ver: it.version });
      if (i >= 0) RC_RECEIPTS[i] = rec; else RC_RECEIPTS.push(rec);
      changed = true;
    });
    if (!changed) return;
    RC_RECEIPTS.sort(function (a, b) { return a.v - b.v; });
    try {
      if (rc.mode === 'view') { var ni = RC_RECEIPTS.findIndex(function (r) { return r._sid === cur; }); if (RC_RECEIPTS.length) rcLoad(ni >= 0 ? ni : Math.min(Math.max(rc.idx, 0), RC_RECEIPTS.length - 1)); else rcNew(); }
      else { if (rc.idx >= 0) rc.idx = RC_RECEIPTS.findIndex(function (r) { return r._sid === cur; }); rcRender(); }
    } catch (e) { console.warn(e); }
  }
  function applyAdm(items) {
    var ses = curSess(), live = false;
    items.forEach(function (it) {
      var sess = it.key.split('|')[0], adm = it.key.slice(sess.length + 1), mk = admKey(sess), arr;
      if (sess !== ses && B.adm_session !== 'all' && !(mk in MEM)) return;   // another session that this page did not load
      try { arr = JSON.parse(MEM[mk] || '[]'); } catch (e) { arr = []; }
      var j = arr.findIndex(function (r) { return r.adm === adm; });
      if (it.deleted) { delete ERP.admSnap[it.key]; delete ERP.admVer[it.key]; if (j >= 0) arr.splice(j, 1); }
      else { if (ERP.admVer[it.key] === it.version) return; ERP.admVer[it.key] = it.version; ERP.admSnap[it.key] = JSON.stringify(it.data); if (j >= 0) arr[j] = it.data; else arr.push(it.data); }
      MEM[mk] = JSON.stringify(arr);
      if (sess !== ses) return;
      live = true;
      var k = ADM.findIndex(function (r) { return r.adm === adm; });
      if (it.deleted) { if (k >= 0) ADM.splice(k, 1); delete RC_STUDENTS[adm]; return; }
      var rec = admNorm(it.data); if (k >= 0) ADM[k] = rec; else ADM.push(rec); admSync(rec);
    });
    if (!live) return;
    try { admAutoCat(); admLinkSibs(); MEM[admKey(ses)] = JSON.stringify(ADM); if (rc.mode === 'view') refreshReceipt(); else rcRender(); } catch (e) { console.warn(e); }
    try { window.dispatchEvent(new CustomEvent('erp-adm')); } catch (e) {}   // erp-adm-live.js redraws the Admission / Attendance screen
  }
  var polling = false, gen = 0;
  function poll(force) {
    if (polling && !force) return; polling = true;
    var my = ++gen, t0 = Date.now();      // the server holds this request until something changes (long-poll), so changes arrive within a fraction of a second
    api('GET', 'delta/?since=' + ERP.last + '&wait=25').then(function (r) {
      if (my !== gen) return;             // a newer request replaced this one
      polling = false; if (!r.ok) return;
      var d = r.body; ERP.last = d.last;
      d.kv.forEach(function (it) {
        var k = it.key.indexOf(mine) === 0 ? it.key.slice(mine.length) : it.key;
        if (ERP.ver[k] === it.version) return;
        if (it.deleted) { delete MEM[k]; delete SRV[k]; delete ERP.ver[k]; }
        else {
          MEM[k] = (pending[k] !== undefined && k in MEM) ? mergeStr(SRV[k], MEM[k], it.data) : it.data;   // keep my unsent change
          SRV[k] = it.data; ERP.ver[k] = it.version;
        }
        if (LIVE[k] && !it.deleted) {   // tell the screen (it re-reads the list); it now holds exactly this value
          APPBASE[k] = MEM[k];
          try { window.dispatchEvent(new StorageEvent('storage', { key: k, newValue: MEM[k], storageArea: realLS })); } catch (e) {}
        } else if (!it.deleted && applyLive(k)) { APPBASE[k] = MEM[k]; } else if (!PERUSER[k] && !QUIET[k] && !/_att$/.test(k)) stale('Settings were changed by another user (' + k.replace('eacademics_', '') + ')');
        if (/_att$/.test(k) && !it.deleted) { try { window.dispatchEvent(new CustomEvent('erp-att', { detail: k })); } catch (e) {} }   // attendance (biometric scans arrive all morning): no banner, no reload; erp-att-live.js refreshes the open screen
      });
      applyAdm(d.adm); applyReceipts(d.receipts);
      var changed = d.kv.length || d.adm.length || d.receipts.length;
      try { if (d.events && d.events.length) window.dispatchEvent(new CustomEvent('erp-events', { detail: d.events })); if (changed) window.dispatchEvent(new Event('erp-changed')); } catch (e) {}   // other scripts (online fee sync) react to these instead of polling
      if (changed) { try { if (typeof curPage !== 'undefined' && curPage === 'dashboard' && typeof dashRefresh === 'function') dashRefresh(); } catch (e) {} }   // dashboard numbers follow every change live
      if (!document.hidden && (changed || Date.now() - t0 > 2000)) setTimeout(function () { poll(); }, 0);   // ask again straight away (an old server answers at once with nothing: then the 3 s timer is used)
    }, function () { if (my === gen) polling = false; });
  }

  // ---- 6b. https: use the trusted address automatically when it works, otherwise tell people how to get the camera
  window.addEventListener('load', function () {
    if (location.protocol !== 'http:' || /^(localhost|127\.)/.test(location.hostname) || !B.https_port) return;
    var bar = function (html) {
      var b = document.createElement('div');
      b.style.cssText = 'position:fixed;top:0;left:0;right:0;z-index:99998;background:#fff4cc;color:#4a3b00;padding:6px 12px;font:13px Roboto,Arial;text-align:center;border-bottom:1px solid #e6cf7a';
      b.innerHTML = html + ' <span style="cursor:pointer;margin-left:10px" onclick="this.parentNode.remove()">✕</span>'; document.body.appendChild(b);
    };
    if (B.trusted_domain) {
      var url = 'https://' + B.trusted_domain + (B.https_port === 443 ? '' : ':' + B.https_port) + '/';
      var ctl = window.AbortController ? new AbortController() : null, t = setTimeout(function () { if (ctl) ctl.abort(); }, 3000);
      fetch(url + 'login/', { mode: 'no-cors', signal: ctl ? ctl.signal : undefined }).then(function () { clearTimeout(t); ERP.flush().then(function () { location.replace(url); }); },
        function () { clearTimeout(t); bar('Secure address (needed for the camera): <a style="font-weight:600" href="' + url + '">' + url + '</a>'); });
      return;
    }
    bar('For the camera, use the secure address <a style="font-weight:600" href="https://' + location.hostname + ':' + B.https_port + '/">https://' + location.hostname + ':' + B.https_port + '</a> &middot; first time on this PC: <a href="/ca.crt">install the certificate</a>');
  });

  // ---- 6c. certificates that an older version saved inside THIS browser (IndexedDB) are moved to the server once, then removed here
  function migrateLocalDocs() {
    if (!window.indexedDB || !indexedDB.databases) return;
    indexedDB.databases().then(function (list) {
      if (!list.some(function (d) { return d.name === 'eacademics_docs'; })) return;
      var q = indexedDB.open('eacademics_docs');
      q.onsuccess = function () {
        var db = q.result;
        var rd = function (st) { return new Promise(function (res) { if (!db.objectStoreNames.contains(st)) return res([]); var r = db.transaction(st, 'readonly').objectStore(st).getAll(); r.onsuccess = function () { res(r.result || []); }; r.onerror = function () { res([]); }; }); };
        Promise.all([rd('docs'), rd('assets')]).then(function (a) {
          var jobs = a[1].map(function (x) { return send('PUT', 'assets/' + encodeURIComponent(x.k) + '/', x); }).concat(a[0].map(function (x) { return send('PUT', 'docs/' + encodeURIComponent(x.id) + '/', x); }));
          Promise.all(jobs).then(function (rs) {
            if (!rs.every(function (r) { return r.ok; })) return toast('Some saved certificates could not be moved to the server yet; they stay in this browser and will be tried again.');
            db.close(); indexedDB.deleteDatabase('eacademics_docs');
            if (jobs.length) toast(a[0].length + ' saved certificate(s) moved from this browser to the server');
          });
        });
      };
    }, function () {});
  }

  // ---- 7. first run: store the school data on the server (old browser data if any, otherwise the demo school)
  window.addEventListener('load', function () {
    if (!B.seeded) {
      var hasLegacy = false; try { hasLegacy = JSON.parse(legacy.eacademics_adm || '[]').length > 0; } catch (e) {}
      api('POST', 'seed/', { session: curSess(), adm: ADM, receipts: hasLegacy ? [] : RC_RECEIPTS.map(clean) }).then(function (r) {
        if (!r.ok && r.status !== 409) return toast('Could not store the school data on the server');
        var jobs = [];
        if (r.ok) Object.keys(MEM).forEach(function (k) {
          var s = admSess(k); if (s) { if (s !== curSess()) pushAdm(s); return; }
          jobs.push(api('PUT', 'kv/' + encodeURIComponent(srvKey(k)) + '/', { data: MEM[k], base_version: null }));
        });
        Promise.all(jobs).then(function () { Object.keys(legacy).forEach(function (k) { oRem.call(realLS, k); }); setTimeout(function () { location.reload(); }, 600); });
      });
      return;
    }
    migrateLocalDocs();
    setInterval(poll, 3000);
    document.addEventListener('visibilitychange', function () { if (!document.hidden) poll(true); });
  });
})();

// extra scripts (online fee payments, live attendance) - separate files, loaded once the app has started
window.addEventListener('load', function () { ['erp-fee-sync.js', 'erp-att-live.js', 'erp-cloud-setup.js', 'erp-backup-folder.js', 'erp-marks-bulk.js', 'erp-security-notice.js', 'erp-wizard.js', 'erp-adm-live.js', 'erp-live-all.js', 'erp-cls-rename.js'].forEach(function (f) { var s = document.createElement('script'); s.src = '/static/' + f + (window.ERP_VER ? '?v=' + window.ERP_VER : ''); document.head.appendChild(s); }); });
