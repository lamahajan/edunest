"""Runs the school server and starts it again whenever it asks for that (exit code 75: ERP.bat > Restart). Used by run_server.bat.
This loop is in Python, not in the .bat file, on purpose: an update replaces the .bat files while the server runs, and Windows reads a running .bat
file piece by piece, so a changed file would make the running window do strange things. Python files are read once per start, which is safe."""
import os
import subprocess
import sys
import time
from pathlib import Path

RESTART_CODE = 75
ROOT = Path(__file__).resolve().parent.parent


def supervise(cmd, cwd, env=None, delay=2.0, max_restarts=None, sleep=time.sleep, say=print, before=None, retry_errors=False):
    """Runs cmd until it ends with a code other than RESTART_CODE; returns that code. before() runs ahead of every start.
    retry_errors=True: a crash / start failure (any code except 0 = asked to stop) is tried again after a pause that grows from 5 s to 60 s."""
    n = 0
    fails = 0
    while True:
        if before:
            try:
                before()
            except Exception as e:                    # an update check must never stop the school from working
                say(f' (update check skipped: {type(e).__name__})')
        try:
            code = subprocess.run(cmd, cwd=cwd, env=env).returncode
        except KeyboardInterrupt:
            return 0
        if code == 0 or (max_restarts is not None and n >= max_restarts):
            return code
        if code == RESTART_CODE:
            fails = 0
            pause = delay
            say('\n School ERP is restarting ...')
        elif retry_errors:
            fails += 1
            pause = min(60, 5 * fails)
            say(f'\n The server stopped with an error (code {code}). Trying again in {pause} s ...')
        else:
            return code
        n += 1
        sleep(pause)


_lock_handle = None


def single_instance():
    """Only ONE supervisor per installation (a lock on data/supervisor.lock, released by Windows when the process ends). Two of them (a black window and the
    automatic start) used to fight over the ports and then restart the server after somebody had stopped it."""
    global _lock_handle
    try:
        d = ROOT / 'data'
        d.mkdir(exist_ok=True)
        fh = open(d / 'supervisor.lock', 'a+')
    except OSError:
        return True                                           # cannot check (rights): carry on as before
    try:
        if os.name == 'nt':
            import msvcrt
            fh.seek(0)
            msvcrt.locking(fh.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(fh, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        fh.close()
        return False
    _lock_handle = fh
    return True


def main(argv):
    show = bool(argv and argv[0] == 'show')
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', DJANGO_DEBUG=os.environ.get('DJANGO_DEBUG', '0'))
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    import autoupdate
    if not single_instance():
        print('\n School ERP is already running (another window or the automatic start). Nothing to do.')
        if show:
            input('\n Press Enter to close this window ... ')
        return 0
    code = supervise([sys.executable, 'serve.py'], ROOT / 'backend', env, before=autoupdate.check, retry_errors=True)
    if code:
        print(f'\n The server stopped with an error (code {code}). Look at data\\server.log; send a photo of it.')
    if show:
        input('\n Press Enter to close this window ... ')
    return code


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
