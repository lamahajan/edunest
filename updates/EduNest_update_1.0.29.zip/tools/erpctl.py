"""School ERP control tool, used by ERP.bat (the menu). Everything that used to be a separate .bat file lives here, as plain, testable Python.

  status                  is the server running, how to open it, is the automatic start installed
  restart | stop          ask the running server to restart / stop itself (no killing of processes, no administrator needed)
  start                   open the server in its own window
  autostart-on | -off     start the server by itself when the computer starts (asks for administrator permission)
  backup | update | import-data | ...   the other jobs of the menu
"""
import ctypes
import os
import re
import shutil
import socket
import subprocess
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
BACKEND = ROOT / 'backend'
IS_WIN = os.name == 'nt'
TASK = 'SchoolERP'
RULE = 'School ERP'
_RT = ROOT / 'runtime' / 'python.exe'                      # the installer ships its own Python in 'runtime'; a manual install uses 'venv'
PY = (str(_RT) if _RT.exists() else str(ROOT / 'venv' / 'Scripts' / 'python.exe')) if IS_WIN else sys.executable


def data_dir():
    return Path(os.environ.get('ERP_DATA_DIR') or ROOT / 'data')


def env_value(key, default=''):
    f = data_dir() / 'config.env'
    if f.exists():
        for line in f.read_text(encoding='utf-8-sig').splitlines():
            line = line.strip()
            if line.startswith(key + '='):
                return line.split('=', 1)[1].strip().strip('"\'')
    return os.environ.get(key, default)


def port(kind='HTTP'):
    try:
        return int(env_value(f'ERP_{kind}_PORT', '8000' if kind == 'HTTP' else '8443'))
    except ValueError:
        return 8000 if kind == 'HTTP' else 8443


def running(p=None):
    try:
        socket.create_connection(('127.0.0.1', p or port()), timeout=0.5).close()
        return True
    except OSError:
        return False


def any_up():
    """http OR https port answers (the old check looked at http only, so a server still holding https looked 'stopped')."""
    return running() or running(port('HTTPS'))


def wait(cond, secs, step=0.3):
    t = time.time()
    while time.time() - t < secs:
        if cond():
            return True
        time.sleep(step)
    return False


def say(*a):
    print(*a, flush=True)


def manage(*args, check=False):
    """python manage.py <args> in the backend folder (with the program's own Python)."""
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
    r = subprocess.run([PY, 'manage.py', *args], cwd=BACKEND, env=env)
    return r.returncode


def addresses():
    out = []
    try:
        for line in subprocess.run(['ipconfig'], capture_output=True, text=True).stdout.splitlines() if IS_WIN else []:
            m = re.search(r'IPv4.*?:\s*([\d.]+)', line)
            if m:
                out.append(m.group(1))
    except OSError:
        pass
    return out


# ---------------------------------------------------------------- start / stop / restart
def start_window():
    """Open the server in its own window (the menu stays usable)."""
    if IS_WIN:
        subprocess.Popen(f'start "School ERP server" "{ROOT / "run_server.bat"}" show', shell=True, cwd=ROOT)
    else:
        subprocess.Popen([PY, 'serve.py'], cwd=BACKEND)
    return True


def autostart_installed():
    if not IS_WIN:
        return False
    return subprocess.run(['schtasks', '/Query', '/TN', TASK], capture_output=True).returncode == 0


def listener_pids(p):
    """Process ids listening on a port (from `netstat -ano`)."""
    out = subprocess.run(['netstat', '-ano', '-p', 'tcp'], capture_output=True, text=True).stdout
    return parse_netstat(out, p)


def parse_netstat(text, p):
    pids = set()
    for line in text.splitlines():
        cols = line.split()
        if len(cols) >= 5 and cols[0].upper() == 'TCP' and cols[3].upper() == 'LISTENING' and cols[1].rsplit(':', 1)[-1] == str(p):
            pids.add(cols[4])
    return sorted(pids)


def kill_listener(p):
    """Last resort for a server that does not understand the restart request (an older version): end the process that holds the port."""
    done = False
    for pid in listener_pids(p) if IS_WIN else []:
        done |= subprocess.run(['taskkill', '/PID', pid, '/T', '/F'], capture_output=True).returncode == 0
    return done


def ask(kind, down=15):
    """Writes the request file the server looks for every second. Returns True when the server went down."""
    data_dir().mkdir(parents=True, exist_ok=True)
    (data_dir() / f'{kind}.request').write_text('1')
    return wait(lambda: not any_up(), down)


def stop(quiet=False):
    if not any_up():
        quiet or say('The server is not running.')
        return 0
    quiet or say('Stopping the server ...')
    if ask('stop') or (kill_listener(port()) and wait(lambda: not running(), 10)):
        quiet or say('The server has stopped.')
        return 0
    say('The server did not stop. Close its black window, or restart the computer.')
    return 1


def restart(down=20, back=120):
    if not running():
        say('The server is not running. Starting it ...')
        start_window()
        ok = wait(running, back)
        say('Done: the server is running.' if ok else 'The server did not start. Look at data\\server.log (send a photo of it).')
        return 0 if ok else 1
    say('Restarting the server ...')
    went = ask('restart', down)
    if not went:                                            # an older version does not know the request: end it the hard way
        try:
            (data_dir() / 'restart.request').unlink(missing_ok=True)
        except OSError:
            pass
        say('The server did not react to the request (older version). Ending it now ...')
        kill_listener(port())
        wait(lambda: not running(), 10)
    if wait(running, 90 if went else 0):                    # the black window / automatic start brings it back by itself (a slow PC needs a while)
        say('Done: the server is running again.')
        return 0
    if not running():
        say('Starting it again ...')
        if not (autostart_installed() and subprocess.run(['schtasks', '/Run', '/TN', TASK], capture_output=True).returncode == 0):
            start_window()
    ok = wait(running, back)
    say('Done: the server is running again.' if ok else 'The server did not come back. Look at data\\server.log (send a photo of it).')
    return 0 if ok else 1


def status():
    p = port()
    say('Server:            ' + ('RUNNING' if running() else 'not running'))
    say('Automatic start:   ' + ('installed' if autostart_installed() else 'not installed'))
    say(f'Open on this PC:    http://localhost:{p}   (https://localhost:{port("HTTPS")} when https is set up)')
    for a in addresses():
        say(f'Other computers:    http://{a}:{p}   or   https://{a}:{port("HTTPS")}')
    return 0


# ---------------------------------------------------------------- automatic start (Windows Task Scheduler)
def is_admin():
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


def elevate(args):
    """Run this tool again with administrator rights (Windows asks 'Do you want to allow ...': click Yes)."""
    say('Windows will ask for permission. Click YES in the window that appears.')
    try:
        r = ctypes.windll.shell32.ShellExecuteW(None, 'runas', PY, ' '.join(f'"{a}"' for a in [str(Path(__file__).resolve()), *args, '--elevated']), None, 1)
    except Exception:
        r = 0
    if r <= 32:
        say('Could not ask for administrator permission. Right-click ERP.bat and choose "Run as administrator", then try again.')
        return 1
    say('Continue in the new window that opened. When it says Done, come back here.')
    return 0


def powershell(script):
    return subprocess.run(['powershell', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', script], capture_output=True, text=True)


def task_script():
    """The scheduled task: no 3-day time limit (Windows' default would end the server every 3 days), keeps running on battery, and starts again after a failure."""
    run = str(ROOT / 'run_server.bat').replace("'", "''")
    return ("$a = New-ScheduledTaskAction -Execute 'cmd.exe' -Argument '/c \"\"" + run + "\"\"' -WorkingDirectory '" + str(ROOT).replace("'", "''") + "'; "
            "$t = New-ScheduledTaskTrigger -AtStartup; "
            "$s = New-ScheduledTaskSettingsSet -ExecutionTimeLimit ([TimeSpan]::Zero) -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable "
            "-RestartCount 999 -RestartInterval (New-TimeSpan -Minutes 1) -MultipleInstances IgnoreNew; "
            "$p = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest; "
            f"Register-ScheduledTask -TaskName '{TASK}' -Action $a -Trigger $t -Settings $s -Principal $p -Force | Out-Null")


def autostart_on(elevated=False):
    if not IS_WIN:
        say('Automatic start is for Windows only.')
        return 1
    if not is_admin():
        return 1 if elevated else elevate(['autostart-on'])
    if not ((ROOT / 'venv').exists() or _RT.exists()):
        say('Run setup.bat first.')
        return 1
    subprocess.run(['netsh', 'advfirewall', 'firewall', 'delete', 'rule', f'name={RULE}'], capture_output=True)
    subprocess.run(['netsh', 'advfirewall', 'firewall', 'add', 'rule', f'name={RULE}', 'dir=in', 'action=allow', 'protocol=TCP', f'localport={port()},{port("HTTPS")}', 'profile=any'], capture_output=True)
    r = powershell(task_script())
    if r.returncode != 0 or not autostart_installed():
        say('Could not set up the automatic start:\n' + (r.stderr or r.stdout or '').strip())
        return 1
    if running():
        stop(quiet=True)                                    # a server started by hand would block the port for the automatic one
    powershell(f"Start-ScheduledTask -TaskName '{TASK}'")
    ok = wait(running, 60)
    say('Done. The school server now starts by itself whenever this computer is switched on.' if ok else 'The automatic start is installed, but the server did not answer yet. Wait a minute and run "Status".')
    say(f'You do NOT need to start it by hand any more. Open: https://localhost:{port("HTTPS")}   Messages and errors: data\\server.log')
    return 0 if ok else 1


def autostart_off(elevated=False):
    if not IS_WIN:
        return 1
    if not is_admin():
        return 1 if elevated else elevate(['autostart-off'])
    powershell(f"Stop-ScheduledTask -TaskName '{TASK}' -ErrorAction SilentlyContinue; Unregister-ScheduledTask -TaskName '{TASK}' -Confirm:$false -ErrorAction SilentlyContinue")
    subprocess.run(['netsh', 'advfirewall', 'firewall', 'delete', 'rule', f'name={RULE}'], capture_output=True)
    if running():
        stop(quiet=True)
    say('Automatic start removed. Start the server from ERP.bat (option 1) when you need it.')
    return 0


# ---------------------------------------------------------------- the other jobs
# ---------------------------------------------------------------- removing the program
def removal_script(root):
    """A small .cmd (kept OUTSIDE the folder) that takes ownership of every file and deletes the folder, trying again for a minute while windows close.
    Windows says 'Folder Access Denied ... you need permission from <user>' when files belong to another account (for example created by the automatic
    start, which runs as SYSTEM, or by another Windows user); taking ownership first is what makes the delete possible."""
    r = str(root)
    return (f'@echo off\r\ntitle Removing School ERP\r\ncd /d "%TEMP%"\r\nping -n 4 127.0.0.1 >nul\r\n'
            f'takeown /f "{r}" /r /d y >nul 2>&1\r\nicacls "{r}" /grant Administrators:F /t /c /q >nul 2>&1\r\nset n=0\r\n'
            f':try\r\nrmdir /s /q "{r}" >nul 2>&1\r\nif not exist "{r}" goto done\r\nset /a n+=1\r\nif %n% GEQ 30 goto fail\r\nping -n 3 127.0.0.1 >nul\r\ngoto try\r\n'
            f':done\r\necho.\r\necho  School ERP has been removed from this computer.\r\ntimeout /t 5 >nul\r\n(goto) 2>nul & del "%~f0"\r\n'
            f':fail\r\necho.\r\necho  Some files could not be removed. Restart the computer and delete the folder "{r}" again.\r\npause\r\n(goto) 2>nul & del "%~f0"\r\n')


def has_data():
    return (data_dir() / 'db.sqlite3').exists() or bool(env_value('POSTGRES_DB'))


def final_backup():
    """A last backup for the person to keep (in Documents). Returns the file, '' when there is no data, or None when the backup could not be made."""
    if not has_data():
        return ''
    if manage('backup_data') != 0:
        return None
    folders = [Path(env_value('ERP_BACKUP_DIR')) if env_value('ERP_BACKUP_DIR') else None, ROOT / 'backups']
    found = [f for d in folders if d and d.is_dir() for f in d.glob('school_backup_*.zip')]
    if not found:
        return None
    newest = max(found, key=lambda f: f.stat().st_mtime)
    dest = Path(os.environ.get('USERPROFILE') or Path.home()) / 'Documents'
    dest.mkdir(parents=True, exist_ok=True)
    out = dest / f'school_erp_final_backup_{time.strftime("%Y-%m-%d_%H%M")}.zip'
    shutil.copy2(newest, out)
    return out


def uninstall(elevated=False):
    if not IS_WIN:
        say('Removing the program from the menu is for Windows. Just delete the folder.')
        return 1
    if not is_admin():
        return 1 if elevated else elevate(['uninstall'])
    say(f'This REMOVES the School ERP from this computer: the program AND its data (students, fees, photos) in\n  {ROOT}\n')
    say('A last backup file is saved in your Documents folder first, so nothing is lost.')
    if input('Type DELETE (capital letters) and press Enter to continue, or just press Enter to cancel: ').strip() != 'DELETE':
        say('Cancelled. Nothing was removed.')
        return 0
    saved = final_backup()
    if saved is None:
        say('The safety backup could not be made, so NOTHING was removed. Look at data\\server.log (send a photo of this window).')
        return 1
    if saved:
        say(f'Safety backup saved: {saved}\nKeep it (copy it to a pen drive). It restores everything on a new installation.')
    autostart_off(elevated=True)
    stop(quiet=True)
    script = Path(tempfile.gettempdir()) / 'school_erp_remove.cmd'
    script.write_text(removal_script(ROOT), encoding='ascii', errors='replace')
    subprocess.Popen(f'start "Removing School ERP" /min cmd /c "{script}"', shell=True, cwd=tempfile.gettempdir())
    say('\nThe program is being removed in the background. You can close this window.')
    return 0


def update():
    rc = subprocess.run([PY, str(ROOT / 'tools' / 'autoupdate.py'), '--force'], cwd=ROOT).returncode      # 1) the internet
    if rc == 0:
        say('Updated from the internet.')
        return restart()
    if not list((ROOT / 'updates').glob('*.zip')):                                                        # 2) a zip in the updates folder
        return 0 if rc in (10, 11) else rc
    rc = subprocess.run([PY, str(ROOT / 'tools' / 'update.py')], cwd=ROOT).returncode
    if rc:
        say('The update did not finish. Your data is safe. Send a photo of this window.')
        return rc
    return restart()


def import_data():
    (ROOT / 'imports').mkdir(exist_ok=True)
    say('1. Put the data file (school_data_....zip) inside the "imports" folder.')
    say('2. This REPLACES all data on this PC. You will see a comparison first and a safety backup is made.')
    input('Press Enter to continue (close this window to cancel) ... ')
    was = running()
    if was and stop() != 0:
        return 1
    rc = manage('import_data')
    if was:
        say('Starting the server again ...')
        if not (autostart_installed() and subprocess.run(['schtasks', '/Run', '/TN', TASK], capture_output=True).returncode == 0):
            start_window()
    return rc


def pip_install(*req):
    return subprocess.run([PY, '-m', 'pip', 'install', '--no-compile', *req], cwd=BACKEND).returncode


def to_postgres():
    if pip_install('-r', 'requirements-postgres.txt') != 0:
        pip_install('psycopg')
    return manage('move_to_postgres')


def setup_https():
    if pip_install('-r', 'requirements-https.txt') != 0:
        say('The parts for https could not be installed. Check the internet connection and try again.')
        return 1
    rc = manage('get_cert', '--force')
    say('If it says "Done", choose Restart now. Otherwise send a photo of this window.')
    return rc


COMMANDS = {
    'status': lambda a: status(), 'restart': lambda a: restart(), 'stop': lambda a: stop(), 'start': lambda a: (start_window(), 0)[1],
    'autostart-on': lambda a: autostart_on('--elevated' in a), 'autostart-off': lambda a: autostart_off('--elevated' in a),
    'update': lambda a: update(), 'import-data': lambda a: import_data(), 'uninstall': lambda a: uninstall('--elevated' in a),
    'backup': lambda a: manage('backup_data'), 'export-data': lambda a: manage('export_data'), 'reset-password': lambda a: manage('reset_password'),
    'organize-media': lambda a: manage('organize_media'), 'cloud-check': lambda a: manage('cloud_check'),
    'setup-https': lambda a: setup_https(),
    'to-postgres': lambda a: to_postgres(),
}


def main(argv):
    if not argv or argv[0] not in COMMANDS:
        say('Commands: ' + ', '.join(COMMANDS))
        return 2
    return COMMANDS[argv[0]](argv[1:]) or 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
