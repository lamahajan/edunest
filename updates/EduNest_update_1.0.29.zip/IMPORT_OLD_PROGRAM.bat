@echo off
title EduNest - import students from the old program
cd /d "%~dp0"
set "PYEXE=%~dp0venv\Scripts\python.exe"
if exist "%~dp0runtime\python.exe" set "PYEXE=%~dp0runtime\python.exe"
if not exist "%PYEXE%" (
  echo.
  echo  The program is not installed yet. Double-click setup.bat first.
  echo.
  pause
  exit /b 1
)
set PYTHONDONTWRITEBYTECODE=1
echo.
echo  Students of the OLD FoxPro program  -^>  one academic session.
echo  It only ADDS students. Students that already exist are never changed.
echo.
set "FOLDER="
set /p FOLDER= Folder that contains A.DBF (you can drag the folder here): 
set "FOLDER=%FOLDER:"=%"
set "SESS="
set /p SESS= Academic session, for example 2009-2010: 
cd backend
"%PYEXE%" manage.py import_foxpro "%FOLDER%" --session %SESS%
if errorlevel 1 goto end
echo.
set "OK="
set /p OK= Type YES (capital letters) to SAVE these students, anything else cancels: 
if not "%OK%"=="YES" (
  echo  Cancelled. Nothing was saved.
  goto end
)
"%PYEXE%" manage.py import_foxpro "%FOLDER%" --session %SESS% --apply
:end
echo.
pause
