import gzip
import hashlib
import re
from pathlib import Path
from django.conf import settings
from django.http import FileResponse, HttpResponse, HttpResponseNotModified
from django.views.static import serve

BASE = Path(__file__).resolve().parent.parent


_PAGES = {}
_ASSET = re.compile(r'(/static/[A-Za-z0-9_./-]+\.(?:css|js))(?=["\'])')


def _version():
    f = BASE.parent / 'VERSION'
    return re.sub(r'[^0-9A-Za-z.-]', '', f.read_text().strip()) if f.exists() else '0'


def _page(request, name):
    """index.html / login.html: the app's own address list gets ?v=<version> (so the browser may keep the files for a year and an update still shows at once),
    the page is sent gzip-compressed and answers 304 when nothing changed - a big saving on a weak WiFi."""
    f = BASE / 'templates' / name
    if not f.exists():
        return HttpResponse('Run: python build_frontend.py', status=500)
    ver, key = _version(), (f.stat().st_mtime_ns, _version())
    ent = _PAGES.get(name)
    if not ent or ent['key'] != key:
        html = _ASSET.sub(lambda m: m.group(1) + '?v=' + ver, f.read_text(encoding='utf-8'))
        html = html.replace('<head>', '<head>\n  <script>window.ERP_VER = "' + ver + '";</script>', 1)
        raw = html.encode('utf-8')
        ent = _PAGES[name] = {'key': key, 'raw': raw, 'gz': gzip.compress(raw, 6), 'etag': '"' + hashlib.md5(raw).hexdigest() + '"'}
    if request.headers.get('If-None-Match') == ent['etag']:
        r = HttpResponseNotModified()
    else:
        gz = 'gzip' in request.headers.get('Accept-Encoding', '')
        r = HttpResponse(ent['gz'] if gz else ent['raw'], content_type='text/html; charset=utf-8')
        if gz:
            r['Content-Encoding'] = 'gzip'
    r['ETag'] = ent['etag']
    r['Cache-Control'] = 'no-cache'
    r['Vary'] = 'Accept-Encoding'
    return r


def index(request):
    return _page(request, 'index.html')


def login_page(request):
    return _page(request, 'login.html')


def media(request, path):
    root = Path(settings.MEDIA_ROOT)
    if not (root / path).is_file():                      # old links /media/f/<file> and files not yet moved out of media/f
        alt = path[2:] if path.startswith('f/') else 'f/' + path
        if (root / alt).is_file():
            path = alt
        else:                                            # renamed upload (hash name -> 22012_student.jpg): old links keep working
            from sync import medianame
            new = medianame.alias_of(path)
            if new:
                path = new
    r = serve(request, path, document_root=root)
    r['Cache-Control'] = 'no-cache'                      # named files (22012_student.jpg) can be replaced: always re-check, 304 when unchanged
    return r


def ca_cert(request):
    """The school's own certificate authority (public part). Install it once on each PC so the browser trusts https://."""
    f = settings.DATA_DIR / 'certs' / 'ca.crt'
    if not f.exists():
        return HttpResponse('No certificate yet. Start the server first (ERP.bat, option 1).', status=404)
    r = FileResponse(open(f, 'rb'), content_type='application/x-x509-ca-cert')
    r['Content-Disposition'] = 'attachment; filename="school-erp-ca.crt"'
    return r
