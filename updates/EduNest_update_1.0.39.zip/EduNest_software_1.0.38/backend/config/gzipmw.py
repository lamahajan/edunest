"""Small gzip middleware: makes the answers of the server (JSON, HTML, CSS, JS) 5-10 times smaller on a slow WiFi. Never touches live streams (text/event-stream)."""
import gzip


class GzipLite:
    TYPES = ('application/json', 'text/', 'application/javascript')

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        r = self.get_response(request)
        if (r.streaming or r.has_header('Content-Encoding') or r.status_code != 200 or 'gzip' not in request.headers.get('Accept-Encoding', '')
                or not r.get('Content-Type', '').startswith(self.TYPES) or r.get('Content-Type', '').startswith('text/event-stream') or len(r.content) < 1024):
            return r
        r.content = gzip.compress(r.content, 5)
        r['Content-Encoding'] = 'gzip'
        r['Content-Length'] = str(len(r.content))
        r['Vary'] = 'Accept-Encoding'
        if r.has_header('ETag'):
            r['ETag'] = r['ETag'].replace('"', '-gz"', 1) if r['ETag'].startswith('"') else r['ETag']
        return r
