"""
URL configuration for config project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/6.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path, re_path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from . import views
from django.urls import include, path, re_path
from sync import views as sync_views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/login/', sync_views.login),
    path('api/login-info/', sync_views.login_info),
    path('api/sync/', include('sync.urls')),
    re_path(r'^media/(?P<path>.*)$', views.media),
    path('login/', views.login_page),
    path('ca.crt', views.ca_cert),
    path('', views.index),
]
