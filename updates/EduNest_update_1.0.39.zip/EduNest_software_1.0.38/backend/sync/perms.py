"""Server-side users and permissions. Users live in the app's own user list (the "Users" screen, kv key
eacademics_users); the server checks passwords and rights against that list, so rules cannot be bypassed from the browser."""
import hashlib
import json
import os
import re
import secrets

from rest_framework.permissions import BasePermission

from .models import Change, Doc

USERS_KEY = 'eacademics_users'


# ---- password hashes (same two formats the browser code produces)
def hash_h1(pw):
    return 'h1:' + hashlib.sha256(('lotus|' + pw).encode('utf-8')).hexdigest()


def hash_h0(pw):
    """Fallback hash the browser uses when crypto.subtle is unavailable (plain http on a LAN address)."""
    M = 0xFFFFFFFF
    imul = lambda x, y: (x * y) & M
    a, b = 0xDEADBEEF, 0x41C6CE57
    for ch in 'lotus|' + pw:
        o = ord(ch)
        c = o if o < 0x10000 else 0xD800 + ((o - 0x10000) >> 10)       # JS charCodeAt(0) of an astral character
        a, b = imul(a ^ c, 2654435761), imul(b ^ c, 1597334677)
    a = imul(a ^ (a >> 16), 2246822507) ^ imul(b ^ (b >> 13), 3266489909)
    b = imul(b ^ (b >> 16), 2246822507) ^ imul(a ^ (a >> 13), 3266489909)
    return 'h0:' + format(4294967296 * (2097151 & b) + (a & M), 'x')


def password_ok(stored, pw):
    return bool(stored) and stored in (hash_h1(pw), hash_h0(pw))


# ---- the user list
def load_users():
    d = Doc.objects.filter(coll='kv', key=USERS_KEY).first()
    try:
        v = json.loads(d.data) if d else []
        return v if isinstance(v, list) else []
    except (TypeError, ValueError):
        return []


DEFAULT_ADMIN = {'name': 'Administrator', 'username': 'admin', 'password': 'admin123'}


def ensure_default_admin():
    """A fresh install has nobody who can sign in: create Administrator / admin / admin123 so the first person can get in at once (they are told to change it).
    Does nothing when any user exists, or when ERP_DEFAULT_ADMIN=0 (the school wants to choose its own first login). Returns True when it created the user."""
    if os.environ.get('ERP_DEFAULT_ADMIN', '1').strip() == '0' or load_users():
        return False
    user = {'id': 'U' + secrets.token_hex(4), 'name': DEFAULT_ADMIN['name'], 'username': DEFAULT_ADMIN['username'], 'pass': hash_h1(DEFAULT_ADMIN['password']),
            'role': 'Administrator', 'active': True, 'perm': {}, 'created': '', 'lastLogin': ''}
    Doc.objects.update_or_create(coll='kv', key=USERS_KEY, defaults={'data': json.dumps([user]), 'version': 1})
    Change.objects.create(coll='kv', key=USERS_KEY, action='put')
    return True


def uses_default_password():
    """True while an active Administrator can still sign in with the well-known default password."""
    return any(is_active(u) and u.get('role') == 'Administrator' and password_ok(u.get('pass'), DEFAULT_ADMIN['password']) for u in load_users())


def ui_user(username):
    u = str(username or '').strip().lower()
    return next((x for x in load_users() if str(x.get('username', '')).lower() == u), None)


def is_active(rec):
    return bool(rec) and rec.get('active', True) is not False


def public_users(text):
    """Password hashes never leave the server."""
    try:
        arr = json.loads(text)
        for x in arr:
            x['pass'] = ''
        return json.dumps(arr)
    except (TypeError, ValueError):
        return text


# ---- rights
def can_any(user, pairs):
    if user.is_superuser:
        return True
    rec = ui_user(user.username)
    if not is_active(rec):
        return False
    if rec.get('role') == 'Administrator':
        return True
    perm = rec.get('perm') or {}
    return any(a in (perm.get(m) or []) for m, a in pairs)


def _any(mod, *acts):
    return [(mod, a) for a in acts]


PROMO = [('promotion', 'add'), ('promotion', 'x_close')]
CRUD = ('add', 'edit', 'delete')
SETUP = _any('setupConfig', 'edit') + _any('masterData', 'edit') + PROMO
KV_RULES = {
    'users': _any('adminZone', 'edit'),
    'priplan': _any('setupConfig', 'edit') + PROMO,
    'sessions': PROMO + _any('promotion', 'x_delsess', 'delete'),
    'feeplan': SETUP, 'feestruct': SETUP, 'stops': SETUP, 'routes': SETUP, 'tcfg': SETUP, 'classes': SETUP,
    'school': _any('setupConfig', 'edit'), 'msg': _any('setupConfig', 'edit'),
    'feeimp': _any('feeImposition', *CRUD) + PROMO,
    'concreq': _any('concession', *CRUD, 'approve') + PROMO, 'conc2': _any('concession', *CRUD, 'approve') + PROMO,
    'gp': _any('frontDesk', *CRUD, 'approve'), 'gp_tg': _any('frontDesk', *CRUD, 'approve'),
    'gp_cfg': _any('frontDesk', *CRUD, 'approve') + SETUP, 'gp_sig': _any('frontDesk', *CRUD, 'approve'),
    'att': _any('attendanceDesk', 'add', 'edit') + PROMO,
    'tt': _any('timetable', 'add', 'edit') + SETUP, 'teachers': _any('timetable', 'add', 'edit') + SETUP,
    'exam': _any('examSchedule', 'add', 'edit') + _any('markEntry', 'add', 'edit') + SETUP,
    'acad': _any('examSchedule', 'add', 'edit') + _any('markEntry', 'add', 'edit') + SETUP,
    'rp_openbal': _any('feeImposition', *CRUD) + _any('feeReceipt', 'edit') + PROMO,
    'tc_book': _any('admission', 'edit', 'print', 'x_tc') + _any('certPrint', 'print'),
    'cashclose': _any('feeReceipt', 'add', 'edit') + PROMO,                  # daily cash closure (Cash Closure button in the header)
    'enq': _any('admission', 'add', 'edit', 'x_enq'),                     # admission enquiries: anybody who can add an admission may enter one, an approver decides them
}
DOC_WRITE = _any('certPrint', 'add', 'edit', 'print', 'delete') + _any('admission', 'edit', 'print', 'x_tc') + PROMO
ADM_WRITE = _any('admission', 'add', 'edit', 'delete') + _any('setupConfig', 'edit') + PROMO
ADM_DELETE = _any('admission', 'delete') + PROMO
KEY_RE = re.compile(r'^eacademics_(?:s(\d{4}-\d{4})_)?(.+)$')


def kv_pairs(key):
    """Rights needed to change a settings key (None = any signed-in user, e.g. activity log)."""
    m = KEY_RE.match(key)
    if not m:
        return None
    base = KV_RULES.get(m.group(2))
    if base is None:
        return None
    return base + PROMO if m.group(1) else base      # session-scoped copies are also written when a session is closed


class UiAccess(BasePermission):
    """A valid token is not enough: the person must still exist in the user list and be active."""
    message = 'Your account is not active.'

    def has_permission(self, request, view):
        u = request.user
        return bool(u and u.is_authenticated and (u.is_superuser or is_active(ui_user(u.username))))
