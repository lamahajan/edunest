"""Biometric attendance (eSSL AiFace -> Attendance worker -> Firebase) -> ERP student attendance.

The Attendance worker files every student scan at  attendance/students/<date>/<pin>_<HHMMSS>  (date = India date, with `admissionNumber`).
While the server is on, this module listens to today's node (live stream) and marks every scanned student **Present** in the ERP's
Attendance (the same data the Attendance screen uses: class / section / date -> P / A / L).

Rules, chosen so a teacher's work is never undone and nobody is marked wrongly:
  - A scan only ever fills an empty mark or turns Absent into Present (the child did come). Leave ('L') and Present stay as they are.
  - Nobody is ever marked Absent automatically: students on a school bus do not scan in the morning (only in the evening), so "no scan"
    does not mean "absent". The teacher marks the rest on the Attendance screen as always, and sees the scanned students already Present.
  - Staff scans are not touched (the ERP has no staff attendance).

Nothing runs unless CLOUD_ATT_URL is set in data/config.env (CLOUD_ATT_PATH only if the worker has a code).
"""
import json
import logging
import re
import os
import threading
import time
from datetime import datetime, timedelta

from django.db import transaction

from . import cloud_gp, livesync, store, views
from .models import Doc, Student

log = logging.getLogger('cloud_att')
WAKE = livesync.Waker()


def config():
    url, code = os.environ.get('CLOUD_ATT_URL', '').strip().rstrip('/'), os.environ.get('CLOUD_ATT_PATH', '').strip().strip('/')
    if not url:
        return None                                 # the code (path) is optional: empty = the database root, like in the workers
    return {'url': url, 'code': code, 'auth': os.environ.get('CLOUD_ATT_AUTH', '').strip(), 'session': os.environ.get('ERP_CLOUD_SESSION', '').strip(),
            'safety': max(60, int(os.environ.get('CLOUD_ATT_SAFETY_SECS', '300')))}


def today():
    return datetime.now(cloud_gp.IST).strftime('%Y-%m-%d')


def adm_of(rec):
    """Admission number of a scan record (None for staff / unknown people)."""
    if not isinstance(rec, dict) or rec.get('personType') not in (None, 'student'):
        return None
    a = rec.get('admissionNumber') if rec.get('admissionNumber') not in (None, '') else rec.get('personId')
    return str(a).strip() if a not in (None, '') else None


class Collector:
    """Gathers admission numbers of scans announced by the live stream, per date, until the worker takes them."""

    def __init__(self):
        self.lock, self.pending = threading.Lock(), {}

    def callback(self, date):
        def on_data(path, data):
            if path == '/':
                recs = data.values() if isinstance(data, dict) else []
            elif path.count('/') == 1:                      # '/<pin>_<HHMMSS>': one whole scan record
                recs = [data]
            else:                                           # a single field of a record: nothing new
                return
            found = {a for a in (adm_of(r) for r in recs) if a}
            if found:
                with self.lock:
                    self.pending.setdefault(date, set()).update(found)
        return on_data

    def drain(self):
        with self.lock:
            out, self.pending = self.pending, {}
        return out


def update_doc(key, mutate):
    """Change a document the way a browser save does (tables + version + 'changed' note for open screens)."""
    with transaction.atomic():
        views.lock(f'kv:{key}')
        d = Doc.objects.select_for_update().filter(coll='kv', key=key).first()
        obj = json.loads(store.load(key, d.data)) if d else {}
        if mutate(obj) is False:
            return False
        text = json.dumps(obj, ensure_ascii=False, separators=(',', ':'))
        if d is None:
            Doc.objects.create(coll='kv', key=key, data=store.store(key, text))
        else:
            d.data, d.version = store.store(key, text), d.version + 1
            d.save()
        views.note('kv', key)
    return True


class Bridge:
    def __init__(self, cfg, fb=None):
        self.cfg, self.fb, self.collector = cfg, fb or cloud_gp.Firebase(cfg), Collector()
        self.last_full = 0

    def apply(self, date, adms):
        """Mark these admission numbers Present for `date`. Returns {'marked': n, 'unknown': [adm, ...]}."""
        session = cloud_gp.session_for_date(self.cfg, date)
        studs = {s.adm_no: s for s in Student.objects.filter(session=session, left=False)}
        nozero = {k.lstrip('0'): v for k, v in studs.items() if k.lstrip('0')}
        groups, unknown = {}, []
        for a in sorted(adms):
            s = studs.get(a) or nozero.get(a.lstrip('0'))
            if s:
                groups.setdefault((s.cls, s.sec or ''), []).append(s.adm_no)
            else:
                unknown.append(a)
        key = 'eacademics_att' if session == store.BASE else f'eacademics_s{session}_att'
        count, marked = [0], []

        def mutate(obj):
            for (cls, sec), lst in groups.items():
                k = f'{date}|{cls}|{sec}'
                day = obj.get(k) or {}
                for adm in lst:
                    if day.get(adm) in (None, '', 'A'):
                        day[adm] = 'P'; count[0] += 1; marked.append(adm)
                if day:
                    obj[k] = day
            if marked:
                from . import cloud_roll                     # in the same save: these Present marks came from a scan, not from a roll call
                cloud_roll.note_biometric(date, marked)
            return count[0] > 0 or False
        if groups:
            update_doc(key, mutate)
        return {'marked': count[0], 'unknown': unknown}

    def run_once(self, dates=None):
        """Apply what the stream announced; `dates` (a full re-read of those days) also catches scans a delayed device uploaded late."""
        pending = self.collector.drain()
        for d in dates or []:
            node = self.fb.get(f'attendance/students/{d}') or {}
            pending.setdefault(d, set()).update(a for a in (adm_of(r) for r in (node.values() if isinstance(node, dict) else [])) if a)
        out = {'marked': 0, 'unknown': []}
        for d, adms in sorted(pending.items()):
            r = self.apply(d, adms)
            out['marked'] += r['marked']; out['unknown'] += r['unknown']
        return out


def date_stream(bridge, stop=None):
    """Listen to today's node; at midnight (India) move on to the next day's."""
    while not (stop and stop.is_set()):
        d = today()
        livesync.stream(bridge.fb._url(f'attendance/students/{d}'), WAKE, stop, on_data=bridge.collector.callback(d), until=lambda d=d: today() != d)


def loop(stop=None):
    cfg = config()
    if not cfg:
        return
    b = Bridge(cfg)
    threading.Thread(target=date_stream, args=(b, stop), name='stream-attendance', daemon=True).start()
    log.info('Biometric attendance sync ON (live)')

    def work():
        full = time.time() - b.last_full > cfg['safety'] * 0.9
        days = [today(), (datetime.now(cloud_gp.IST) - timedelta(days=1)).strftime('%Y-%m-%d')] if full else None
        st = b.run_once(days)
        if full:
            b.last_full = time.time()
        if st['marked']:
            log.info('attendance: %s student(s) marked Present', st['marked'])
        if st['unknown']:
            log.warning('attendance: scans of admission numbers not in the ERP: %s', ', '.join(st['unknown'][:10]))
    livesync.run_loop('biometric attendance sync', WAKE, work, cfg['safety'], stop)


def fetch_all():
    """FORCE FETCH: every day in the cloud's attendance (not only today and yesterday): every scanned student is marked Present in the ERP."""
    cfg = config()
    if not cfg:
        raise RuntimeError('Biometric attendance is not set up')
    b = Bridge(cfg)
    days = [d for d in b.fb.keys('attendance/students') if re.match(r'^\d{4}-\d{2}-\d{2}$', d) and d <= today()]
    out = b.run_once(days)
    return {'days in the cloud': len(days), 'marked Present': out['marked'], 'admission numbers not in the ERP': len(set(out['unknown']))}


def start_background():
    if not config():
        return None
    t = threading.Thread(target=loop, name='cloud-att', daemon=True)
    t.start()
    return t
