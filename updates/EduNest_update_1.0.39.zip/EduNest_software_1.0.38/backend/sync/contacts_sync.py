"""One-way sync  ERP -> Google Contacts (students' parents + teachers).

The ERP sends the numbers to the school's own Google Apps Script web app (google_contacts/EduNest_Contacts.gs), which creates / updates / removes the
contacts in the school's Google account (label "EduNest"). Nothing is ever read back: the ERP stays the only master copy.
Settings: Setup > Cloud Sync > Google Contacts (saved in data/config.env):  CONTACTS_SCRIPT_URL, CONTACTS_SCRIPT_TOKEN  (+ optional CONTACTS_COUNTRY=+91, CONTACTS_PREFIX=, CONTACTS_SESSION=, CONTACTS_REMOVE=1)
Only the changes since the last run are sent (data/contacts_sync.json remembers what Google already has)."""
import hashlib
import json
import logging
import os
import re
import time
import urllib.error
import urllib.request

from django.conf import settings
from django.db import connection

from . import cloud_gp, person
from .models import Doc, Person, Student

log = logging.getLogger('contacts')
INTERVAL = 600                                # seconds between two checks
CHUNK = 120                                   # contacts per request (the Google side handles a few hundred, but a small request answers fast)
MIN_KEEP = 0.5                                # a list that suddenly shrinks below this share of the last one is NOT used to delete contacts (safety)


def settings_now():
    from . import cloud_setup                     # imported here: cloud_setup <-> runtime <-> this module would otherwise import each other
    e = dict(os.environ)
    e.update(cloud_setup.read_env())
    return {'url': e.get('CONTACTS_SCRIPT_URL', '').strip(), 'token': e.get('CONTACTS_SCRIPT_TOKEN', '').strip(),
            'cc': (e.get('CONTACTS_COUNTRY', '+91').strip() or '+91'), 'prefix': e.get('CONTACTS_PREFIX', '').strip(),
            'session': e.get('CONTACTS_SESSION', '').strip(), 'remove': e.get('CONTACTS_REMOVE', '1').strip() != '0'}


def norm(num, cc='+91'):
    """'98765 43210' / '098765-43210' / '+91 98765 43210' -> '+919876543210'; '' when it is not a full number."""
    d = re.sub(r'\D', '', str(num or ''))
    code = re.sub(r'\D', '', cc)
    if len(d) == 10:
        return '+' + code + d
    if len(d) == 11 and d[0] == '0':
        return '+' + code + d[1:]
    if len(d) == len(code) + 10 and d.startswith(code):
        return '+' + d
    return ''


def collect(cfg):
    """{key: (name, phone)} of everybody who should be in Google Contacts."""
    out = {}
    cc, pre = cfg['cc'], (cfg['prefix'] + ' ' if cfg['prefix'] else '')
    session = cloud_gp.current_session({'session': cfg['session']})
    rows = list(Student.objects.filter(session=session, left=False))
    pers = dict(Person.objects.filter(adm_no__in=[s.adm_no for s in rows]).values_list('adm_no', 'data'))
    for s in rows:
        rec = person.merge(pers.get(s.adm_no) or {}, s.sdata or {})
        nm = ' '.join(x for x in (s.first_name, s.middle_name, s.last_name) if x).strip() or s.adm_no
        cl = '-'.join(x for x in (s.cls, s.sec) if x)
        base = f'{pre}{nm}' + (f' ({cl})' if cl else '')
        fam = rec.get('family') if isinstance(rec.get('family'), dict) else {}
        seen = set()

        def add(key, role, num):
            ph = norm(num, cc)
            if ph and ph not in seen:                          # the same number twice for one child (e.g. SMS number = father's) is one contact
                seen.add(ph)
                out[f's:{s.adm_no}:{key}'] = (f'{base} {role}', ph)
        for k, role in (('father', 'Father'), ('mother', 'Mother'), ('guardian', 'Guardian')):
            add(k, role, (fam.get(k) or {}).get('mobile'))
        add('sms', 'Parent', rec.get('mobile') or s.mobile)
        for i, m in enumerate(rec.get('mobiles') or []):
            add(f'm{i}', f'Parent {i + 2}', m)
    d = Doc.objects.filter(coll='kv', key='eacademics_teachers').first()
    try:
        teachers = json.loads(d.data) if d and isinstance(d.data, str) else (d.data if d else [])
    except ValueError:
        teachers = []
    for t in teachers or []:
        ph = norm(t.get('mobile'), cc)
        if ph and t.get('name'):
            out[f't:{t.get("id") or t["name"]}'] = (f'{pre}{t["name"]} (Teacher)', ph)
    return out


def _h(v):
    return hashlib.sha1(json.dumps(v, ensure_ascii=False).encode('utf-8')).hexdigest()[:16]


def _call(cfg, payload):
    body = json.dumps(dict(payload, token=cfg['token'])).encode('utf-8')
    req = urllib.request.Request(cfg['url'], data=body, headers={'Content-Type': 'text/plain;charset=utf-8', 'User-Agent': 'EduNest/1.0'})
    with urllib.request.urlopen(req, timeout=180) as r:        # Apps Script answers a POST with a redirect to the result: urllib follows it
        text = r.read().decode('utf-8', 'replace')
    try:
        return json.loads(text)
    except ValueError:
        raise RuntimeError('The Google script did not answer properly (is the web app deployed for "Anyone"? Is the URL the /exec one?)')


def state_path():
    return settings.DATA_DIR / 'contacts_sync.json'


def load_state():
    try:
        return json.loads(state_path().read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return {}


def save_state(st):
    state_path().write_text(json.dumps(st), encoding='utf-8')


def test(values=None):
    """Ping the Google script with the saved settings (or the values typed on the Cloud Sync page). Returns (ok, message)."""
    cfg = settings_now()
    for k, name in (('url', 'CONTACTS_SCRIPT_URL'), ('token', 'CONTACTS_SCRIPT_TOKEN')):
        if (values or {}).get(name):
            cfg[k] = values[name].strip()
    if not cfg['url'] or not cfg['token']:
        return False, 'Fill in the script URL and the token first.'
    try:
        r = _call(cfg, {'action': 'ping'})
    except Exception as e:
        return False, f'Cannot reach the Google script: {e}'
    return bool(r.get('ok')), 'Google script: ' + str(r.get('message') or r.get('error') or r)


def run(full=False, say=print):
    """Send the changes. Returns (ok, text). Safe to call as often as you like."""
    cfg = settings_now()
    if not cfg['url'] or not cfg['token']:
        return False, 'not set up'
    want = collect(cfg)
    old = load_state().get('items', {})
    new_hash = {k: _h(v) for k, v in want.items()}
    up = list(want) if full else [k for k in want if old.get(k) != new_hash[k]]
    gone = [k for k in old if k not in want]
    if gone and (not cfg['remove'] or (old and len(want) < MIN_KEEP * len(old))):
        if cfg['remove']:
            log.warning('Contacts: %s contacts vanished from the ERP list at once; NOT deleting them from Google (looks like a data problem). Run sync_contacts --full to force.', len(gone))
        gone = []
        keep_gone = {k: old[k] for k in old if k not in want}
    else:
        keep_gone = {}
    if not up and not gone:
        return True, f'nothing to change ({len(want)} contacts)'
    done = dict(old)
    done.update(keep_gone)
    created = updated = deleted = 0
    for i in range(0, len(up), CHUNK):
        part = up[i:i + CHUNK]
        r = _call(cfg, {'action': 'upsert', 'items': [{'key': k, 'name': want[k][0], 'phone': want[k][1]} for k in part]})
        if not r.get('ok'):
            save_state({'items': done, 'at': int(time.time())})
            return False, r.get('error') or str(r)
        created += r.get('created', 0)
        updated += r.get('updated', 0)
        for k in part:
            done[k] = new_hash[k]
        save_state({'items': done, 'at': int(time.time())})
    for i in range(0, len(gone), 400):
        part = gone[i:i + 400]
        r = _call(cfg, {'action': 'delete', 'keys': part})
        if not r.get('ok'):
            return False, r.get('error') or str(r)
        deleted += r.get('deleted', 0)
        for k in part:
            done.pop(k, None)
        save_state({'items': done, 'at': int(time.time())})
    return True, f'{created} added, {updated} updated, {deleted} removed ({len(want)} contacts in total)'


def config():
    """The settings when the connection is filled in (else None): same contract as the other cloud workers."""
    c = settings_now()
    return c if c['url'] and c['token'] else None


def loop(ev):
    """Worker thread (started / stopped by sync/runtime.py like the other cloud apps): first check 20 s after the start, then every INTERVAL seconds."""
    if ev.wait(20):
        return
    while not ev.is_set():
        try:
            if config():
                ok, msg = run()
                if not ok:
                    log.warning('Google Contacts sync: %s', msg)
                elif not msg.startswith('nothing'):
                    log.info('Google Contacts sync: %s', msg)
        except Exception as e:
            log.warning('Google Contacts sync failed: %s', e)
        finally:
            connection.close()
        ev.wait(INTERVAL)


def fetch_all():
    """'Send all contacts now' button of the Cloud Sync page: sends everything again (removes what is gone from the ERP)."""
    ok, msg = run(full=True)
    if not ok:
        raise RuntimeError(msg)
    return {'Google Contacts': msg}
