"""Helpers shared by backup / export / import."""
import glob
import json
import logging
import os
import tempfile
import zipfile
from datetime import date, datetime, timedelta
from pathlib import Path
import shutil
import sqlite3
import subprocess

from django.conf import settings
from django.core.management.base import CommandError
from django.db.migrations.loader import MigrationLoader
from django.db.migrations.recorder import MigrationRecorder
from django.db.models import Max
from django.utils import timezone

from . import models as m

log = logging.getLogger('dbtools')


def engine():
    return 'sqlite' if 'sqlite' in settings.DATABASES['default']['ENGINE'] else 'postgresql'


def find_tool(name):
    exe = shutil.which(name)
    if exe:
        return exe
    for pat in (rf'C:\Program Files\PostgreSQL\*\bin\{name}.exe', f'/usr/lib/postgresql/*/bin/{name}'):
        hits = sorted(glob.glob(pat))
        if hits:
            return hits[-1]
    raise CommandError(f'{name} was not found. Install PostgreSQL (it includes it) or add its "bin" folder to PATH.')


def _pg(db):
    return ['-h', str(db['HOST']), '-p', str(db['PORT']), '-U', str(db['USER'])], dict(os.environ, PGPASSWORD=str(db.get('PASSWORD') or ''))


def snapshot_db(dest_dir):
    """Consistent copy of the database into dest_dir; returns the file name."""
    db = settings.DATABASES['default']
    if engine() == 'sqlite':
        src, out = sqlite3.connect(str(db['NAME'])), sqlite3.connect(str(dest_dir / 'db.sqlite3'))
        with out:
            src.backup(out)
        src.close(); out.close()
        return 'db.sqlite3'
    args, env = _pg(db)
    r = subprocess.run([find_tool('pg_dump'), *args, '-Fc', '-f', str(dest_dir / 'db.dump'), str(db['NAME'])], env=env, capture_output=True, text=True)
    if r.returncode:
        raise CommandError('pg_dump failed: ' + r.stderr.strip()[:300])
    return 'db.dump'


def restore_db(path):
    db = settings.DATABASES['default']
    if engine() == 'sqlite':
        src, dst = sqlite3.connect(str(path)), sqlite3.connect(str(db['NAME']), timeout=30)
        try:
            with dst:
                src.backup(dst)
        except sqlite3.Error as e:
            raise CommandError(f'The database is in use ({e}). Stop the school server first, then try again.')
        finally:
            src.close(); dst.close()
        return
    args, env = _pg(db)
    r = subprocess.run([find_tool('pg_restore'), *args, '--clean', '--if-exists', '--no-owner', '--no-privileges', '-d', str(db['NAME']), str(path)], env=env, capture_output=True, text=True)
    if r.returncode:
        raise CommandError('pg_restore failed: ' + r.stderr.strip()[-400:] + '\nStop the school server and try again.')


def summary():
    last = m.Change.objects.aggregate(t=Max('at'))['t']
    return {'students': m.Student.objects.count(), 'receipts': m.ReceiptDoc.objects.count(), 'attendance': m.AttendanceMark.objects.count(),
            'marks': m.Mark.objects.count(), 'gate_passes': m.GatePass.objects.count(), 'reference_entries': m.RefEntry.objects.count(),
            'last_activity': timezone.localtime(last).strftime('%Y-%m-%d %H:%M') if last else ''}


def applied_migrations():
    return sorted(f'{a}.{n}' for a, n in MigrationRecorder.Migration.objects.values_list('app', 'name'))


def known_migrations():
    return {f'{a}.{n}' for a, n in MigrationLoader(None, ignore_no_migrations=True).graph.nodes}


def write_export_zip(out, media=True):
    """One zip = database snapshot + photos + meta.json (media=False: database only, no photos / documents). The same file is what export_data, backup_data and the Backup menu produce, and what import_data restores."""
    out = Path(out)
    out.parent.mkdir(parents=True, exist_ok=True)
    ver = settings.DATA_DIR.parent / 'VERSION'
    with tempfile.TemporaryDirectory() as tmp:
        tmp = Path(tmp)
        name = snapshot_db(tmp)
        meta = {'format': 1, 'engine': engine(), 'db_file': name, 'created': datetime.now().strftime('%Y-%m-%d %H:%M'),
                'program_version': ver.read_text().strip() if ver.exists() else 'unknown', 'migrations': applied_migrations(), 'summary': summary(), 'media': bool(media)}
        cfg = settings.DATA_DIR / 'config.env'                  # the settings file (ports, domain, https, database password) travels with every backup
        meta['config'] = cfg.is_file()
        with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as z:
            z.write(tmp / name, name)
            z.writestr('meta.json', json.dumps(meta, indent=1))
            if cfg.is_file():
                z.write(cfg, 'config.env')
            mroot = Path(settings.MEDIA_ROOT)
            if media and mroot.exists():
                for f in mroot.rglob('*'):
                    if f.is_file() and not f.name.endswith('.part'):
                        z.write(f, 'media/' + f.relative_to(mroot).as_posix())
    return meta


def default_backup_dir():
    return settings.DATA_DIR.parent / 'backups'


def backup_dir():
    """The folder the backups go to: ERP_BACKUP_DIR (Setup > School Setup > Backup folder) or the program's own backups folder."""
    custom = os.environ.get('ERP_BACKUP_DIR', '').strip().strip('"')
    return Path(custom) if custom else default_backup_dir()


def check_folder(folder):
    """Makes sure a folder exists and can be written to. Returns '' when fine, else a plain-language reason."""
    folder = Path(folder)
    try:
        folder.mkdir(parents=True, exist_ok=True)
        probe = folder / f'.erp_write_test_{os.getpid()}'
        probe.write_bytes(b'ok')
        probe.unlink()
    except OSError as e:
        return f'cannot use this folder ({e.strerror or e})'
    return ''


def backup_info():
    folder = backup_dir()
    files = sorted(folder.glob('school_backup_*.zip'), key=lambda p: p.stat().st_mtime) if folder.is_dir() else []
    try:
        free = shutil.disk_usage(folder if folder.is_dir() else folder.anchor or str(default_backup_dir())).free
    except OSError:
        free = None
    last = files[-1] if files else None
    return {'folder': str(folder), 'default': str(default_backup_dir()), 'custom': folder != default_backup_dir(), 'reachable': folder.is_dir(), 'free_bytes': free,
            'count': len(files), 'last': {'name': last.name, 'size': last.stat().st_size, 'time': datetime.fromtimestamp(last.stat().st_mtime).strftime('%Y-%m-%d %H:%M')} if last else None}


# ---- what goes into a backup (Setup > School Setup > Backup): the database always; photos / documents ("media") every time, and / or on the last date of each month
def media_every():
    return os.environ.get('ERP_BACKUP_MEDIA', '1').strip() != '0'


def media_monthend():
    return os.environ.get('ERP_BACKUP_MEDIA_MONTHEND', '0').strip() == '1'


def is_month_end(d=None):
    d = d or date.today()
    return (d + timedelta(days=1)).month != d.month


def media_wanted(d=None):
    """Does the backup taken now include photos / documents?"""
    return media_every() or (media_monthend() and is_month_end(d))


def media_stats():
    root, n, size = Path(settings.MEDIA_ROOT), 0, 0
    if root.exists():
        for f in root.rglob('*'):
            try:
                if f.is_file() and not f.name.endswith('.part'):
                    n += 1
                    size += f.stat().st_size
            except OSError:
                pass
    return {'files': n, 'bytes': size}


def backup_options():
    return {'media_every': media_every(), 'media_monthend': media_monthend(), 'month_end_today': is_month_end(), 'media_now': media_wanted(), **{'media_' + k: v for k, v in media_stats().items()}}


def make_backup(media=None):
    """<backup folder>/school_backup_<date-time>.zip (school_backup_<date-time>_media.zip when photos / documents are inside); keeps the newest ERP_KEEP_BACKUPS (default 30) files. If the chosen folder cannot be used right now
    (a pen drive that is not plugged in, a network drive that is off ...) the backup is NOT lost: it goes to the program's own backups folder instead."""
    folder = backup_dir()
    why = check_folder(folder)
    if why:
        log.warning('backup folder %s: %s; using %s instead', folder, why, default_backup_dir())
        folder = default_backup_dir()
    inc = media_wanted() if media is None else bool(media)
    path = folder / f'school_backup_{datetime.now().strftime("%Y-%m-%d_%H%M%S")}{"_media" if inc else ""}.zip'
    n = 1
    while path.exists():                                             # two backups in the same second must never overwrite each other (a file being restored from could be replaced)
        n += 1
        path = folder / f'school_backup_{datetime.now().strftime("%Y-%m-%d_%H%M%S")}-{n}{"_media" if inc else ""}.zip'
    write_export_zip(path, media=inc)
    keep = max(3, int(os.environ.get('ERP_KEEP_BACKUPS', '30') or 30))
    keep_media = keep if media_every() else max(3, int(os.environ.get('ERP_KEEP_MEDIA_BACKUPS', '12') or 12))     # month-end backups with photos are kept longer than the daily database-only ones
    files = sorted(folder.glob('school_backup_*.zip'), key=lambda p: p.stat().st_mtime)
    for group, k in (([p for p in files if not p.stem.endswith('_media')], keep), ([p for p in files if p.stem.endswith('_media')], keep_media)):
        for p in group[:-k]:
            try:
                p.unlink()
            except OSError:
                pass
    return path
