"""Cloud Setup: read / write the cloud sync lines of data/config.env and test them, for the Cloud Setup page (static/cloud-setup.html).

The page never gets a secret back: for a secret field it only learns "set" or "not set". Leaving a secret empty keeps the saved one."""
import os
import re
import shutil
import time
import urllib.error
import urllib.request
from pathlib import Path

from django.conf import settings

from . import cloud_gp, runtime

URL_OK = re.compile(r'^https?://[^\s]+$', re.I)


def F(key, label, kind='text', default='', help=''):
    return {'key': key, 'label': label, 'kind': kind, 'default': default, 'help': help}


GROUPS = [
    {'id': 'gate', 'title': 'Gate Pass', 'sub': 'ERP <-> eGateSys / Reception Suite', 'need': ['CLOUD_FB_URL', 'CLOUD_FB_CODE'], 'fields': [
        F('CLOUD_FB_URL', 'Firebase URL', 'url', help='The same Firebase URL you typed in eGateSys settings'),
        F('CLOUD_FB_CODE', 'School code', help='The same School code as in eGateSys settings'),
        F('CLOUD_FB_AUTH', 'Database secret', 'secret', help='Only if the Firebase rules are locked')]},
    {'id': 'result', 'title': 'Result portal', 'sub': 'teachers enter marks online -> ERP', 'need': ['CLOUD_RESULT_URL', 'CLOUD_RESULT_SECRET'], 'fields': [
        F('CLOUD_RESULT_URL', 'Firebase URL', 'url'), F('CLOUD_RESULT_PATH', 'Path', default='Marks', help='Usually Marks'),
        F('CLOUD_RESULT_SECRET', 'Database secret', 'secret')]},
    {'id': 'fee', 'title': 'Online fee (UPI)', 'sub': 'parents pay online -> receipts in the ERP', 'need': ['CLOUD_FEE_DUE_URL', 'CLOUD_FEE_DUE_PATH'], 'fields': [
        F('CLOUD_FEE_DUE_URL', 'Due List Firebase URL', 'url', help='The ERP WRITES each student\'s pending fee here; the parents\' pay page reads it. So the ERP needs its address and secret.'), F('CLOUD_FEE_DUE_PATH', 'Due List code / path', help='The node the due list sits in (the pay-page worker uses DUELIST)'), F('CLOUD_FEE_DUE_SECRET', 'Due List secret', 'secret'),
        F('CLOUD_FEE_TXN_URL', 'Payments (TXN) Firebase URL', 'url', help='Leave EMPTY when payments are in the same Firebase as the Due List (usual)'), F('CLOUD_FEE_TXN_PATH', 'Payments path', default='TXN'), F('CLOUD_FEE_TXN_SECRET', 'Payments secret', 'secret', help='Leave empty to use the Due List secret'),
        F('CLOUD_FEE_WORKER_URL', 'Pay-page worker URL (optional)', 'url', help='Used to close old QR codes'), F('CLOUD_FEE_APP_TOKEN', 'Worker app token (optional)', 'secret')]},
    {'id': 'att', 'title': 'Biometric attendance', 'sub': 'eSSL AiFace scans -> ERP Present', 'need': ['CLOUD_ATT_URL'], 'fields': [
        F('CLOUD_ATT_URL', 'Raw / biometric Firebase URL', 'url', help='haazri worker: RAW_FIREBASE_URL'), F('CLOUD_ATT_PATH', 'Raw code (path)', help='RAW_FIREBASE_CODE. Leave EMPTY if the worker has no code'),
        F('CLOUD_ATT_AUTH', 'Database secret', 'secret')]},
    {'id': 'roll', 'title': 'Class roll call', 'sub': 'Reception app attendance <-> ERP', 'need': ['CLOUD_ROLL_URL'], 'fields': [
        F('CLOUD_ROLL_URL', 'Attendance Firebase URL', 'url', help='rollcall worker: ATTEND_FIREBASE_URL'), F('CLOUD_ROLL_PATH', 'Attendance code (path)', help='ATTEND_FIREBASE_CODE. Leave EMPTY if the worker has no code'),
        F('CLOUD_ROLL_AUTH', 'Database secret', 'secret'), F('CLOUD_ROLL_WORKER_URL', 'Rollcall worker URL (optional)', 'url', help='Optional. With it, attendance taken in the ERP goes through the worker like the Reception app (bus tally and the Google Sheet history are updated too). Empty: the ERP writes it straight into the Firebase.')]},
    {'id': 'contacts', 'title': 'Google Contacts', 'sub': 'parents\' and teachers\' numbers -> Google Contacts (one way, automatic every 10 minutes)', 'need': ['CONTACTS_SCRIPT_URL', 'CONTACTS_SCRIPT_TOKEN'], 'fields': [
        F('CONTACTS_SCRIPT_URL', 'Google script URL', 'url', help='The Web app URL (ends with /exec) of your Apps Script. Steps: google_contacts/SETUP.txt'),
        F('CONTACTS_SCRIPT_TOKEN', 'Token', 'secret', help='The same secret you saved in the script (Script Properties > TOKEN)'),
        F('CONTACTS_COUNTRY', 'Country code', default='+91', help='Put before 10-digit numbers'),
        F('CONTACTS_PREFIX', 'Name prefix (optional)', help='One word put in front of every contact name, e.g. LIS. Empty = nothing')]},
]
FIELDS = {f['key']: f for g in GROUPS for f in g['fields']}
HEADER = '# ---- Cloud sync (written by the Cloud Setup page) ----'


def env_path():
    return Path(settings.DATA_DIR) / 'config.env'


def read_env():
    """{KEY: value} of the active lines of config.env."""
    out = {}
    p = env_path()
    if p.exists():
        for line in p.read_text(encoding='utf-8-sig').splitlines():
            line = line.strip()
            if line and not line.startswith('#') and '=' in line:
                k, v = line.split('=', 1)
                out[k.strip()] = v.strip().strip('"').strip("'")
    return out


def view():
    """What the page shows: plain values, and only "set" for secrets."""
    cur = read_env()
    groups = []
    for g in GROUPS:
        fields = []
        for f in g['fields']:
            v = cur.get(f['key'], '')
            fields.append({**f, 'value': '' if f['kind'] == 'secret' else v, 'set': bool(v)})
        groups.append({'id': g['id'], 'title': g['title'], 'sub': g['sub'], 'on': all(cur.get(k) for k in g['need']), 'running': runtime.is_running(g['id']), 'fields': fields})
    return groups


def fix_urls(values):
    """A phone keyboard writes 'Https://...' (capital H): the web address part before :// is made lower case, the rest stays as typed."""
    out = dict(values or {})
    for k, v in out.items():
        if isinstance(v, str) and (FIELDS.get(k) or {}).get('kind') == 'url':
            out[k] = re.sub(r'^(https?)://', lambda m: m.group(1).lower() + '://', v.strip(), flags=re.I)
    return out


def validate(values):
    """Returns {key: message} for values that cannot be saved."""
    bad = {}
    for k, v in values.items():
        f = FIELDS.get(k)
        if not f:
            bad[k] = 'unknown setting'
        elif not isinstance(v, str) or re.search(r'[\r\n\x00]', v):
            bad[k] = 'not a valid value'
        elif v.strip() and f['kind'] == 'url' and not URL_OK.match(v.strip()):
            bad[k] = 'must start with https:// (or http://) and have no spaces'
        elif v.strip() and f['kind'] != 'url' and re.search(r'\s', v.strip()) and f['kind'] != 'secret':
            bad[k] = 'must not contain spaces'
    return bad


def write_env(new):
    """Put KEY=value lines into config.env ('' removes the key). Other lines and comments stay; the old file is kept as config.env.bak; the running server sees it too."""
    p = env_path()
    lines = p.read_text(encoding='utf-8-sig').splitlines() if p.exists() else []
    done, out = set(), []
    for line in lines:
        s = line.strip()
        k = s.split('=', 1)[0].strip() if s and not s.startswith('#') and '=' in s else None
        if k in new:
            if new[k] != '' and k not in done:
                out.append(f'{k}={new[k]}')
            done.add(k)
            continue
        out.append(line)
    add = [f'{k}={v}' for k, v in new.items() if k not in done and v != '']
    if add:
        if HEADER not in out:
            out += ['', HEADER]
        out += add
    if p.exists():
        shutil.copy2(p, p.with_name('config.env.bak'))
    tmp = p.with_name('config.env.tmp')
    tmp.write_text('\n'.join(out).rstrip('\n') + '\n', encoding='utf-8')
    os.replace(tmp, p)
    for k, v in new.items():                            # the running server also sees it (the workers still start at the next restart)
        if v == '':
            os.environ.pop(k, None)
        else:
            os.environ[k] = v


def save(values, clear=()):
    """Write the given settings into config.env (other lines and comments stay). An empty secret keeps the saved one; `clear` removes settings."""
    values = fix_urls(values)
    bad = validate(values)
    if bad:
        return bad
    cur = read_env()
    new = {}
    for k, v in values.items():
        v = v.strip().rstrip('/') if FIELDS[k]['kind'] == 'url' else v.strip()
        if v == '' and FIELDS[k]['kind'] == 'secret':
            continue                                   # blank secret box = keep what is saved
        new[k] = v
    for k in clear:
        if k in FIELDS:
            new[k] = ''
    write_env(new)
    return {}


def disconnect(gid):
    """Forget every saved setting of one app (its Firebase address, code and secrets). Returns False for an unknown group.
    Only this server's connection is removed: nothing in the cloud app / database is touched."""
    g = next((x for x in GROUPS if x['id'] == gid), None)
    if not g:
        return False
    save({}, clear=[f['key'] for f in g['fields']])
    return True


# ---------------------------------------------------------------- testing
def test_firebase(cfg, label):
    """Read, then write+delete a small test node. Returns (ok, message): tells a wrong address / secret / rule problem apart."""
    fb = cloud_gp.Firebase(cfg)
    try:
        fb.get('')
    except urllib.error.HTTPError as e:
        return False, f'{label}: the cloud answered "{e.code} {e.reason}". ' + ('The database secret / rules do not allow reading.' if e.code in (401, 403) else 'Check the address (URL) and the code.')
    except Exception as e:
        return False, f'{label}: cannot reach the cloud ({e}). Check the internet and the URL.'
    try:
        fb.put('_erp_check', {'at': int(time.time())})
        fb.delete('_erp_check')
    except Exception as e:
        return False, f'{label}: can read but NOT write ({e}). The database secret is missing / wrong, or the rules block writing.'
    return True, f'{label}: connected (read and write work).'


def test_worker(url, label):
    try:
        with urllib.request.urlopen(urllib.request.Request(url, headers={'User-Agent': 'SchoolERP/1.0'}), timeout=15) as r:
            return True, f'{label}: the worker answered (HTTP {r.status}).'
    except urllib.error.HTTPError as e:
        return (e.code < 500), f'{label}: the worker answered HTTP {e.code}' + ('.' if e.code < 500 else ' (a server error).')
    except Exception as e:
        return False, f'{label}: cannot reach the worker ({e}).'


def test_group(gid, values=None):
    """Test one group with the values typed on the page (a blank secret falls back to the saved one). Returns [(ok, message), ...]."""
    values = fix_urls(values)
    g = next((x for x in GROUPS if x['id'] == gid), None)
    if not g:
        return [(False, 'unknown group')]
    cur = read_env()
    val = {f['key']: ((values or {}).get(f['key'], '') or '').strip() or cur.get(f['key'], '') or f['default'] for f in g['fields']}
    missing = [k for k in g['need'] if not val.get(k)]
    if missing:
        return [(False, 'Fill in: ' + ', '.join(missing))]
    bad = validate({k: v for k, v in val.items() if k in FIELDS})
    if bad:
        return [(False, f'{k}: {m}') for k, m in bad.items()]
    cfg = lambda u, c, a: {'url': val[u].rstrip('/'), 'code': val[c].strip('/'), 'auth': val.get(a, '')}
    out = []
    if gid == 'contacts':
        from . import contacts_sync
        return [contacts_sync.test(val)]
    if gid == 'gate':
        out.append(test_firebase(cfg('CLOUD_FB_URL', 'CLOUD_FB_CODE', 'CLOUD_FB_AUTH'), 'Gate Pass database'))
    elif gid == 'result':
        out.append(test_firebase(cfg('CLOUD_RESULT_URL', 'CLOUD_RESULT_PATH', 'CLOUD_RESULT_SECRET'), 'Result portal database'))
    elif gid == 'fee':
        out.append(test_firebase(cfg('CLOUD_FEE_DUE_URL', 'CLOUD_FEE_DUE_PATH', 'CLOUD_FEE_DUE_SECRET'), 'Due List database'))
        same = not val.get('CLOUD_FEE_TXN_URL') or val['CLOUD_FEE_TXN_URL'].rstrip('/') == val['CLOUD_FEE_DUE_URL'].rstrip('/')
        turl = val['CLOUD_FEE_DUE_URL'] if not val.get('CLOUD_FEE_TXN_URL') else val['CLOUD_FEE_TXN_URL']
        tpath = (val.get('CLOUD_FEE_TXN_PATH') or 'TXN') if same or val.get('CLOUD_FEE_TXN_PATH') else ''
        tsec = val.get('CLOUD_FEE_TXN_SECRET') or (val.get('CLOUD_FEE_DUE_SECRET', '') if same else '')
        if turl and tpath:
            out.append(test_firebase({'url': turl.rstrip('/'), 'code': tpath.strip('/'), 'auth': tsec}, 'Payments database' + (' (same Firebase as the Due List)' if same else '')))
        else:
            out.append((False, 'Payments database: fill in its path (without it online payments are not picked up).'))
        if val.get('CLOUD_FEE_WORKER_URL'):
            out.append(test_worker(val['CLOUD_FEE_WORKER_URL'], 'Pay-page worker'))
    elif gid == 'att':
        out.append(test_firebase(cfg('CLOUD_ATT_URL', 'CLOUD_ATT_PATH', 'CLOUD_ATT_AUTH'), 'Biometric database'))
    elif gid == 'roll':
        out.append(test_firebase(cfg('CLOUD_ROLL_URL', 'CLOUD_ROLL_PATH', 'CLOUD_ROLL_AUTH'), 'Roll call database'))
        if val.get('CLOUD_ROLL_WORKER_URL'):
            out.append(test_worker(val['CLOUD_ROLL_WORKER_URL'], 'Rollcall worker'))
        else:
            out.append((True, 'Rollcall worker not filled in: only cloud -> ERP will run (ERP marks will not be sent to the cloud).'))
    return out
