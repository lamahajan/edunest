"""Result portal <-> ERP bridge, both ways, written straight to the portal's Firebase (the portal's worker is not needed for any of this).

  setup  ERP -> portal, automatic: classes, subjects, terms, assessments, max/pass marks, grade scale and students, whenever the ERP's setup or
         student list changes (the same `config` + `students` layout the old ECA Sync tool wrote). Logins, assignments and marks are left alone.
  marks  BOTH WAYS, live: a mark a teacher saves in the portal (`entries/<term>/<assessment>/<subject>/<student>` = {m, by, u, t}) lands in the
         ERP's Mark Entry / Register / Result Card; a mark typed or corrected in the ERP is written to the portal the same way (locked, like a
         saved mark: {m, by:'ERP', u:'admin', t}), so teachers see it and the portal never disagrees with the ERP.

Marks are compared with what both sides agreed on last time (a "base"), so a change on ONE side is never lost:
  - cloud changed, ERP did not  -> the ERP gets it;   ERP changed, cloud did not  -> the portal gets it (a cleared mark clears the other side too);
  - both changed the same mark differently -> the ERP wins (an authorised correction) and it is counted as a conflict;
  - the very first time (nothing agreed yet): marks only the ERP has go to the portal; where both have a mark and they differ the portal wins
    (the teacher's saved mark is the official one).
A big sudden disappearance of marks on one side (more than a fifth, over 20 marks) is treated as a glitch and not copied.

Nothing runs unless CLOUD_RESULT_URL and CLOUD_RESULT_SECRET are set in data/config.env.
"""
import hashlib
import json
import logging
import os
import re
import threading
import time
from pathlib import Path

from django.conf import settings
from django.db import transaction

from . import cloud_gp, events, livesync, store, views
from .models import Doc, Student


def _meta(key, default):
    d = Doc.objects.filter(coll='meta', key=key).first()
    return d.data if d and isinstance(d.data, dict) else default


def _set_meta(key, value):
    Doc.objects.update_or_create(coll='meta', key=key, defaults={'data': value})

log = logging.getLogger('cloud_result')
BASE_PREFIX = 'cr_base:'                # Doc(coll='meta') per term|assessment: the marks both sides last agreed on
PUSH_KEY = 'cloud_result_push'          # Doc(coll='meta'): session pushed to the portal + the portal ids given to ERP items


def config():
    url, secret = os.environ.get('CLOUD_RESULT_URL', '').strip().rstrip('/'), os.environ.get('CLOUD_RESULT_SECRET', '').strip()
    if not url or not secret:
        return None
    return {'url': url, 'code': os.environ.get('CLOUD_RESULT_PATH', 'Marks').strip().strip('/'), 'auth': secret,
            'safety': max(60, int(os.environ.get('CLOUD_RESULT_SAFETY_SECS', '600'))), 'autopush': os.environ.get('CLOUD_RESULT_AUTOPUSH', '1').strip() != '0', 'session': os.environ.get('ERP_CLOUD_SESSION', '').strip()}


# ------------------------------------------------------------------ reading the ERP's setup
def _doc_json(session, name, default):
    key = f'eacademics_{name}' if session == store.BASE else f'eacademics_s{session}_{name}'
    d = Doc.objects.filter(coll='kv', key=key).first()
    if not d:
        return default
    try:
        v = json.loads(store.load(key, d.data))
        return v if isinstance(v, type(default)) else default
    except (ValueError, TypeError):
        return default


def _name(s):
    return ' '.join(x.strip() for x in (s.first_name, s.middle_name, s.last_name) if x and x.strip())


def key_of(cls, stream):
    return f'{cls} - {stream}' if stream else cls


def _norm(x):
    return re.sub(r'\s+', ' ', str(x or '')).strip().casefold()


def _num(k):
    m = re.search(r'(\d+)$', str(k))
    return int(m.group(1)) if m else 0


def signature(payload):
    return hashlib.sha256(json.dumps(payload, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


_own = {'pending': 0}           # how many ERP changes our own pull is making right now: their change events are not news


class Ids:
    """Keeps the portal's ids (c3, sub12, stu481 ...) stable. Teachers' class/subject assignments and every mark already entered refer to
    them, so an item that already exists in the portal (same name) keeps its id; only really new items get a new number."""

    def __init__(self, prefix, existing, idmap):
        self.prefix, self.map = prefix, dict(idmap or {})
        self.by_name = {_norm(v.get('name')): k for k, v in (existing or {}).items() if isinstance(v, dict)}
        self.top = max([_num(k) for k in (existing or {})] + [_num(v) for v in self.map.values()] + [0])

    def get(self, name, *alt):
        if name in self.map:
            return self.map[name]
        for n in (name,) + alt:
            if _norm(n) in self.by_name:
                self.map[name] = self.by_name[_norm(n)]
                return self.map[name]
        self.top += 1
        self.map[name] = f'{self.prefix}{self.top}'
        return self.map[name]


def build_payload(session, existing=None, idmap=None):
    """ERP setup -> ({'config': {...}, 'students': {...}}, new idmap) in the portal's layout, reusing the portal's existing ids."""
    existing, idmap = existing or {}, idmap or {}
    ec, es = existing.get('config') or {}, existing.get('students') or {}
    classes, acad = _doc_json(session, 'classes', []), _doc_json(session, 'acad', {})
    terms, assess = acad.get('terms') or [], acad.get('assess') or []
    grades, subjects, marks, amap = acad.get('grades') or [], acad.get('subjects') or {}, acad.get('marks') or {}, acad.get('amap') or {}
    cfg = {'school': {'name': os.environ.get('ERP_SCHOOL_NAME', ''), 'address': ''}}
    new = {}

    def ids(kind, prefix, key):
        i = Ids(prefix, ec.get(key), idmap.get(kind))
        new[kind] = i.map
        return i
    I_c, I_sec, I_str, I_sub = ids('c', 'c', 'classes'), ids('sec', 'sec', 'sections'), ids('str', 'str', 'streams'), ids('sub', 'sub', 'subjects')
    I_term, I_ass, I_grd = ids('term', 'term', 'terms'), ids('ass', 'ass', 'assessments'), ids('grd', 'grd', 'grades')

    cid = {c['name']: I_c.get(c['name']) for c in classes}
    secid = {s: I_sec.get(s) for c in classes for s in (c.get('sections') or [])}
    named_streams = sorted({s for c in classes for s in (c.get('streams') or [])})
    strid = {s: I_str.get(s) for s in named_streams}

    def default_stream(cname):                 # the stream id a class WITHOUT streams already uses in the portal (else a new 'General')
        if cname in (idmap.get('dflt') or {}):
            return idmap['dflt'][cname]            # decided at an earlier push
        c_ = cid[cname]
        used = list((ec.get('classSubjects') or {}).get(c_, {})) or [x.get('streamId') for x in es.values() if isinstance(x, dict) and x.get('classId') == c_ and x.get('streamId')]
        return used[0] if used else I_str.get('', 'General')
    dflt = {c['name']: default_stream(c['name']) for c in classes if not c.get('streams')}
    subid = {}
    for lst in subjects.values():
        for x in lst:
            if (x.get('kind') or 'Scholastic') == 'Scholastic':
                subid[x['name']] = I_sub.get(x['name'])
    tid = {t['id']: I_term.get(t['id'], t.get('name')) for t in terms}
    aid = {a['code']: I_ass.get(a['code'], a.get('name')) for a in assess}
    gid = {g['id']: I_grd.get(g['id'], g.get('name')) for g in grades}

    def item(k, name, **extra):
        return dict({'id': _num(k), 'name': name, 'printName': name, 'active': True}, **extra)
    cfg['classes'] = {v: item(v, k) for k, v in cid.items()}
    cfg['sections'] = {v: item(v, k) for k, v in secid.items()}
    cfg['streams'] = {v: item(v, k) for k, v in strid.items()}
    for cname, sid in dflt.items():
        cfg['streams'].setdefault(sid, item(sid, (ec.get('streams') or {}).get(sid, {}).get('name') or (idmap.get('dflt_name') or {}).get(sid) or 'General'))
    cfg['subjects'] = {v: item(v, k) for k, v in subid.items()}
    cfg['terms'] = {tid[t['id']]: item(tid[t['id']], t.get('name', t['id']), active=t.get('active', True), sqc=_num(tid[t['id']]), erpId=t['id']) for t in terms}
    cfg['assessments'] = {aid[a['code']]: item(aid[a['code']], a.get('name', a['code']), sqc=_num(aid[a['code']]), code=a['code']) for a in assess}
    cfg['grades'] = {gid[g['id']]: item(gid[g['id']], g.get('name', g['id'])) for g in grades}
    cfg['gradeScale'] = {gid[g['id']]: [{'from': r['from'], 'to': r['to'], 'grade': r['grade'], 'point': r.get('points', 0), 'sqc': j + 1}
                                       for j, r in enumerate(g.get('rows') or [])] for g in grades}
    in_term = {c for t in terms for c in (t.get('assess') or [])}
    first_grade = next(iter(cfg['grades']), None)
    cs, ac = {}, {}
    for c in classes:
        for st in (c.get('streams') or ['']):
            key = key_of(c['name'], st)
            sid = strid[st] if st else dflt[c['name']]
            codes = [x for x in (amap[key] if key in amap else [a['code'] for a in assess]) if x in aid and x in in_term]
            for n, x in enumerate([x for x in (subjects.get(key) or []) if (x.get('kind') or 'Scholastic') == 'Scholastic']):
                c_, sb_ = cid[c['name']], subid[x['name']]
                cs.setdefault(c_, {}).setdefault(sid, {})[sb_] = {'optional': False, 'compulsory': True, 'sqc': n + 1}
                for code in codes:
                    a = next(a for a in assess if a['code'] == code)
                    cell = ((marks.get(key) or {}).get(x['name']) or {}).get(code) or {'max': a.get('max', 0), 'min': a.get('min', 0)}
                    ac.setdefault(c_, {}).setdefault(sid, {}).setdefault(sb_, {})[aid[code]] = {
                        'minPass': cell.get('min', 0), 'maxMark': cell.get('max', 0), 'gradeId': first_grade, 'marksStyle': 'Marks', 'sqc': _num(aid[code]), 'addToTotal': False}
    cfg['classSubjects'], cfg['assessmentConfig'] = cs, ac

    # students: the portal only accepts ids like stu123 (digits, at most 9); a student already in the portal keeps the id it has
    by_adm = {str(v.get('admNo')): k for k, v in es.items() if isinstance(v, dict) and v.get('admNo') is not None}
    smap = dict(idmap.get('stu') or {})
    top = max([_num(k) for k in es] + [_num(v) for v in smap.values()] + [0])
    students = {}
    for st in Student.objects.filter(session=session, left=False).order_by('cls', 'sec', 'roll', 'adm_no'):
        if st.cls not in cid:
            continue
        key = smap.get(st.adm_no) or by_adm.get(st.adm_no)
        if not key:
            top += 1
            key = f'stu{top}'
        smap[st.adm_no] = key
        stream = strid.get((st.data or {}).get('stream') or '') or dflt.get(st.cls) or I_str.get('', 'General')
        students[key] = {'id': _num(key), 'name': _name(st), 'admNo': st.adm_no, 'father': st.father, 'classId': cid[st.cls], 'sectionId': secid.get(st.sec),
                         'streamId': stream, 'rollNo': st.roll, 'gender': st.gender, 'status': 'Active'}
    new['stu'] = smap
    new['dflt'] = dflt
    new['dflt_name'] = {sid: cfg['streams'][sid]['name'] for sid in dflt.values()}      # so the next comparison needs no read of the portal
    return {'config': cfg, 'students': students}, new


# ------------------------------------------------------------------ the bridge
def update_acad(session, mutate):
    """Change the academics document (marks live in it) the same way a browser save does."""
    key = 'eacademics_acad' if session == store.BASE else f'eacademics_s{session}_acad'
    with transaction.atomic():
        views.lock(f'kv:{key}')
        d = Doc.objects.select_for_update().filter(coll='kv', key=key).first()
        obj = json.loads(store.load(key, d.data)) if d else {}
        if mutate(obj) is False:
            return False
        text = json.dumps(obj, ensure_ascii=False, separators=(',', ':'))
        if d is None:
            Doc.objects.create(coll='kv', key=key, data=store.store(key, text))
        else:
            d.data, d.version = store.store(key, text), d.version + 1
            d.save()
        views.note('kv', key)
    return True


class Bridge:
    def __init__(self, cfg, fb=None):
        self.cfg, self.fb = cfg, fb or cloud_gp.Firebase(cfg)

    def session(self):
        return cloud_gp.current_session(self.cfg)

    def push(self, new_session=False, force=True):
        """ERP setup + students -> portal. Logins, class-subject assignments and entered marks are left alone, ids already in the portal are kept.
        `new_session` clears the entered marks (the old session's marks must be in the ERP first: pull before)."""
        session, meta = self.session(), _meta(PUSH_KEY, {})
        existing = {'config': self.fb.get('config') or {}, 'students': self.fb.get('students') or {}}
        entries = self.fb.get('entries')
        if meta.get('session') and meta['session'] != session and entries and not new_session:
            raise ValueError(f"The portal still holds marks of session {meta['session']}. Pull them first, then push with --new-session "
                             f"(that clears the portal's marks for the new session; a backup is saved first).")
        self._backup({**existing, 'entries': entries}, force)
        p, idmap = build_payload(session, existing, meta.get('idmap'))
        self.fb.put('config', p['config'])
        self.fb.put('students', p['students'])
        if new_session:
            self.fb.delete('entries')
            Doc.objects.filter(coll='meta', key__startswith=BASE_PREFIX).delete()
        _set_meta(PUSH_KEY, {'session': session, 'idmap': idmap, 'sig': signature(p), 'students': len(p['students'])})
        return {'classes': len(p['config']['classes']), 'subjects': len(p['config']['subjects']), 'students': len(p['students']), 'session': session}

    @staticmethod
    def _backup(data, force):
        """A copy of what the portal held before we overwrite it. Automatic pushes keep at most one an hour (and the last 20); a manual push always does."""
        folder = Path(settings.DATA_DIR) / 'cloud_backups'
        folder.mkdir(parents=True, exist_ok=True)
        old = sorted(folder.glob('result_portal_*.json'))
        if not force and old and time.time() - old[-1].stat().st_mtime < 3600:
            return
        (folder / f"result_portal_{time.strftime('%Y%m%d_%H%M%S')}.json").write_text(json.dumps(data, ensure_ascii=False), encoding='utf-8')
        for f in old[:-19]:
            f.unlink(missing_ok=True)

    def push_if_changed(self):
        """Keep the portal's setup equal to the ERP's: send it when (and only when) something changed. Returns {'pushed': bool, 'reason': text}.
        Never automatic when it could do harm: a new session (needs push --new-session), an empty ERP setup, or a student list that suddenly shrank a lot."""
        session, meta = self.session(), _meta(PUSH_KEY, {})
        if meta.get('session') and meta['session'] != session:
            return {'pushed': False, 'reason': f"new session {session}: run 'cloud_result push --new-session' once the old marks are pulled"}
        p, _ = build_payload(session, {}, meta.get('idmap'))                     # ids from the saved map: no network needed to compare
        if not p['config']['classes'] or not p['students']:
            return {'pushed': False, 'reason': 'the ERP has no classes / students yet'}
        if meta.get('sig') == signature(p):
            return {'pushed': False, 'reason': 'unchanged'}
        before = int(meta.get('students') or 0)
        if before >= 20 and len(p['students']) < before * 0.5:
            return {'pushed': False, 'reason': f"the student list shrank from {before} to {len(p['students'])}: not sent automatically (push by hand if that is right)"}
        try:
            return {'pushed': True, **self.push(force=False)}
        except ValueError as e:                                                  # marks of another session are in the portal
            return {'pushed': False, 'reason': str(e)}

    def pull(self):
        """Marks, both ways (kept under this name for the command line)."""
        return self.sync_marks()

    def sync_marks(self):
        """Marks both ways. Returns {'to_erp': n, 'to_cloud': n, 'conflicts': n, 'skipped': n, 'changed': bool}."""
        session = _meta(PUSH_KEY, {}).get('session') or self.session()
        conf, studs = self.fb.get('config') or {}, self.fb.get('students') or {}
        ents = self.fb.get('entries') or {}
        k_term = {v.get('erpId'): k for k, v in (conf.get('terms') or {}).items() if v.get('erpId')}
        k_ass = {v.get('code'): k for k, v in (conf.get('assessments') or {}).items() if v.get('code')}
        k_sub = {v.get('name'): k for k, v in (conf.get('subjects') or {}).items()}
        k_stu = {str(v.get('admNo')): k for k, v in studs.items() if isinstance(v, dict) and v.get('admNo') is not None}
        e_term, e_ass = {v: k for k, v in k_term.items()}, {v: k for k, v in k_ass.items()}
        e_sub, e_stu = {v: k for k, v in k_sub.items()}, {v: k for k, v in k_stu.items()}
        acad = _doc_json(session, 'acad', {})
        mk = acad.get('mkdata') or {}
        cfg_ac = conf.get('assessmentConfig') or {}

        def max_mark(stu, sub, ass):
            s_ = studs.get(stu) or {}
            return (((cfg_ac.get(s_.get('classId')) or {}).get(s_.get('streamId')) or {}).get(sub) or {}).get(ass, {}).get('maxMark')

        out = {'to_erp': 0, 'to_cloud': 0, 'conflicts': 0, 'skipped': 0}
        erp_changes, cloud_patch, base_save, plans = [], {}, {}, []
        unplaced = 0
        for T, tk in k_term.items():
            for A, ak in k_ass.items():
                # the cloud's cells of this term / assessment, as {(adm, subject name): value}
                cloud = {}
                for sk, by_stu in ((ents.get(tk) or {}).get(ak) or {}).items():
                    for stk, e in (by_stu or {}).items():
                        v = _mark(e.get('m')) if isinstance(e, dict) else None
                        adm, sub = e_stu.get(stk), sub_of_key(conf, sk)
                        if v is None:
                            continue
                        if adm is None or sub is None:
                            unplaced += 1
                            continue
                        cloud[(adm, sub)] = v
                erp = {}
                for adm, by_sub in (mk.get(T, {}).get(A, {}) or {}).items():
                    for sub, v in (by_sub or {}).items():
                        v = _mark(v)
                        if v is not None and adm in k_stu and sub in k_sub:
                            erp[(adm, sub)] = v
                bkey = f'{BASE_PREFIX}{T}|{A}'
                bdoc = Doc.objects.filter(coll='meta', key=bkey).first()
                first = bdoc is None
                base = {tuple(k.split('|', 1)): v for k, v in (bdoc.data.get('cells', {}) if bdoc else {}).items()}
                to_erp, to_cloud, newbase, conflicts = {}, {}, {}, 0
                for cell in set(cloud) | set(erp) | set(base):
                    ce, ee, b = cloud.get(cell), erp.get(cell), base.get(cell)
                    if ce == ee:
                        if ce is not None:
                            newbase[cell] = ce
                        continue
                    if first:
                        if ce is None:
                            to_cloud[cell] = ee                    # only the ERP has it
                        else:
                            to_erp[cell] = ce                      # both have it, they differ: the portal's saved mark is official
                        continue
                    if ee == b:                                    # the ERP did not change: the cloud did
                        to_erp[cell] = ce
                    elif ce == b:                                  # the cloud did not change: the ERP did
                        to_cloud[cell] = ee
                    else:                                          # both changed, differently: the ERP wins
                        to_cloud[cell] = ee; conflicts += 1
                plans.append({'T': T, 'A': A, 'tk': tk, 'ak': ak, 'bkey': bkey, 'first': first, 'base': base, 'newbase': newbase, 'to_erp': to_erp, 'to_cloud': to_cloud, 'conflicts': conflicts})
        out['skipped'] += unplaced

        # judge the whole picture before touching anything. Deleting marks is normal (the portal's admin Clear of one class / subject / assessment);
        # what looks like a FAULT is (nearly) everything vanishing from one side at once: an empty answer from Firebase, an emptied ERP.
        total_base = sum(len(pl['base']) for pl in plans)
        gone_erp = sum(1 for pl in plans for v in pl['to_erp'].values() if v is None)
        gone_cloud = sum(1 for pl in plans for v in pl['to_cloud'].values() if v is None)
        block_erp = total_base >= 20 and gone_erp >= 20 and gone_erp >= 0.9 * total_base          # the portal lost (almost) all marks
        block_cloud = total_base >= 20 and gone_cloud >= 20 and gone_cloud >= 0.9 * total_base    # the ERP lost (almost) all marks
        if block_erp or block_cloud:
            log.warning('result marks: %s of %s marks vanished from the %s at once; that looks like a fault, so these deletions are not copied. '
                        'To start a new session on purpose use: cloud_result push --new-session', max(gone_erp, gone_cloud), total_base, 'portal' if block_erp else 'ERP')
        for pl in plans:
            T, A, tk, ak, base, newbase, conflicts = pl['T'], pl['A'], pl['tk'], pl['ak'], pl['base'], pl['newbase'], pl['conflicts']
            to_erp, to_cloud = dict(pl['to_erp']), dict(pl['to_cloud'])
            for blocked, side in ((block_erp, to_erp), (block_cloud, to_cloud)):
                if blocked:
                    for c in [c for c, v in side.items() if v is None]:
                        del side[c]
                        if c in base:
                            newbase[c] = base[c]                    # not agreed: it is looked at again next time
            for cell, v in to_erp.items():
                erp_changes.append((T, A, cell[0], cell[1], v))
                if v is not None:
                    newbase[cell] = v
            for (adm, sub), v in to_cloud.items():
                stk, sk = k_stu[adm], k_sub[sub]
                if v is not None:
                    mx = max_mark(stk, sk, ak)
                    if mx in (None, 0) or (v != 'AB' and v > mx):
                        out['skipped'] += 1                        # the portal would refuse it (no such mark column for this class, or above the maximum)
                        newbase.pop((adm, sub), None)
                        continue
                    cloud_patch[f'{tk}/{ak}/{sk}/{stk}'] = {'m': v, 'by': 'ERP', 'u': 'admin', 't': time.strftime('%Y-%m-%dT%H:%M:%S.000Z', time.gmtime())}
                    newbase[(adm, sub)] = v
                else:
                    cloud_patch[f'{tk}/{ak}/{sk}/{stk}'] = None
                out['to_cloud'] += 1
            out['to_erp'] += len(to_erp); out['conflicts'] += conflicts
            if pl['first'] or newbase != base:
                base_save[pl['bkey']] = {'cells': {f'{a}|{s_}': v for (a, s_), v in newbase.items()}}

        # cloud -> ERP (one save of the academics document)
        mine = _own['pending']
        if erp_changes:
            def apply(obj):
                md, n = obj.setdefault('mkdata', {}), 0
                for T, A, adm, sub, v in erp_changes:
                    cell = md.setdefault(T, {}).setdefault(A, {}).setdefault(adm, {})
                    if v is None:
                        if sub in cell:
                            del cell[sub]; n += 1
                    elif _mark(cell.get(sub)) != v:
                        cell[sub] = v; n += 1
                return n > 0 or False
            _own['pending'] = mine + 1
            try:
                update_acad(session, apply)
            finally:
                _own['pending'] = mine                              # (the change event, if any, has been handled by now)
        # ERP -> cloud (straight into the portal's database, 300 marks per request)
        items = list(cloud_patch.items())
        for i in range(0, len(items), 300):
            self.fb.patch('entries', dict(items[i:i + 300]))
        for k, v in base_save.items():                              # remembered only after the writes went through
            _set_meta(k, v)
        out['changed'] = bool(out['to_erp'])
        return out


def sub_of_key(conf, sk):
    return ((conf.get('subjects') or {}).get(sk) or {}).get('name')


def _mark(v):
    """A mark in one canonical form so that 61, '61', 61.0 are equal; 'AB' stays 'AB'; empty is None."""
    if v is None or (isinstance(v, str) and not v.strip()):
        return None
    if str(v).strip().upper() == 'AB':
        return 'AB'
    try:
        f = round(float(v), 2)
    except (TypeError, ValueError):
        return None
    return int(f) if f == int(f) else f


WAKE = livesync.Waker()
SETUP_KEY = re.compile(r'^eacademics_(s[\w-]+_)?(classes|acad)$')


def _on_kv(key):
    if not SETUP_KEY.match(key):
        return
    if _own['pending'] > 0 and key.endswith('_acad'):
        _own['pending'] -= 1                # the marks our own pull just wrote: not a setup change
        return
    WAKE.set()


def _on_adm(key):
    WAKE.set()


def attach():
    """A change of the ERP's classes / subjects / marks setup or of the student list wakes the worker (to push the setup to the portal)."""
    events.on('kv', _on_kv)
    events.on('adm', _on_adm)


def loop(stop=None):
    cfg = config()
    if not cfg:
        return
    attach()
    b = Bridge(cfg)
    livesync.start_streams(b.fb, ['entries'], WAKE, stop)                      # a teacher saving marks wakes us at once
    log.info('Result portal sync ON (live%s)', ', setup is pushed automatically' if cfg['autopush'] else ', automatic push of the setup is OFF')

    seen = {'skipped': 0}

    def work():
        if cfg['autopush']:
            r = b.push_if_changed()
            if r['pushed']:
                log.info('result portal setup updated: %s', {k: v for k, v in r.items() if k != 'pushed'})
            elif r['reason'] not in ('unchanged', 'the ERP has no classes / students yet'):
                log.warning('result portal setup NOT sent: %s', r['reason'])
        st = b.sync_marks()
        if st['to_erp'] or st['to_cloud'] or st['conflicts'] or st['skipped'] != seen['skipped']:
            log.info('result marks sync: %s', st)
        seen['skipped'] = st['skipped']
    livesync.run_loop('result sync', WAKE, work, cfg['safety'], stop)


def fetch_all():
    """FORCE FETCH: every mark entered on the portal comes into the ERP now (the portal and the ERP are compared in full)."""
    cfg = config()
    if not cfg:
        raise RuntimeError('Result portal is not set up')
    st = Bridge(cfg).sync_marks()
    return {'marks to the ERP': st.get('to_erp', 0), 'conflicts': st.get('conflicts', 0)}


def start_background():
    if not config():
        return None
    t = threading.Thread(target=loop, name='cloud-result', daemon=True)
    t.start()
    return t
