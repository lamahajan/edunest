"""Class roll call (Reception app -> Class Attendance Worker "rollcall" -> Attendance DB)  <->  ERP attendance, both ways.

The Reception app's teachers mark each student present / absent; the rollcall worker keeps today's marks at  attendance/<date>/<adm>
= {status, class, busNumber, name, ts}  in the Attendance DB, and (when a mark is sent to its /mark address) also updates the bus tally,
the biometric DB and the permanent Google Sheet. While the server is on this module keeps the ERP's Attendance and that cloud roll call equal:

  cloud -> ERP   a roll call mark in the cloud becomes P / A in the ERP's Attendance (live stream, a second or so).
  ERP -> cloud   an attendance mark a teacher saves on the ERP's Attendance screen is sent to the rollcall worker's /mark, exactly like the Reception app does,
                 so the bus tally, the Google Sheet and the Reception app stay right. Without CLOUD_ROLL_WORKER_URL it is written straight into the Attendance
                 Firebase instead (the Reception app shows it; the bus tally and the Sheet history are not updated).

Which side wins is decided with a three-way comparison against what both sides agreed on last time, so a change on ONE side is never lost:
a change on one side goes to the other; if both sides changed the same student differently, the ERP wins (teacher at the ERP) and it is logged.
Presence only seen on a biometric scan (see cloud_att) is not sent to the roll call as a mark, and an explicit roll call mark beats it.
Present never goes DOWN by itself: once a student is Present in the ERP, a later cloud mark (evening bus roll call, gate-out, a re-read of the day) that says absent / leave / cleared is ignored.
Only a teacher on the ERP Attendance screen can change a Present mark. (Set ERP_ATT_NO_DOWNGRADE=0 in config.env to switch this rule off.)
The cloud has only present / absent: an ERP Leave goes as absent, and a cloud absent never turns an ERP Leave into Absent.

Nothing runs unless CLOUD_ROLL_URL is set in data/config.env (CLOUD_ROLL_PATH only if the worker has a code).
"""
import json
import logging
import os
import re
import threading
import time
import urllib.error
import urllib.request
from datetime import datetime

from . import cloud_att, cloud_gp, events, livesync, store
from .models import Doc, Student

log = logging.getLogger('cloud_roll')
WAKE = livesync.Waker()
BASE_KEY, BIO_KEY = 'att_roll_base', 'att_bio'
TO_ERP = {'present': 'P', 'Present': 'P', 'PRESENT': 'P', 'P': 'P', 'p': 'P', '1': 'P', 'absent': 'A', 'Absent': 'A', 'ABSENT': 'A', 'A': 'A', 'a': 'A', '0': 'A', 'leave': 'L', 'Leave': 'L', 'LEAVE': 'L', 'L': 'L', 'l': 'L'}
TO_CLOUD = {'P': 'present', 'A': 'absent', 'L': 'absent'}      # the cloud has no "leave"
CHUNK = 150


def no_downgrade():
    return os.environ.get('ERP_ATT_NO_DOWNGRADE', '1').strip() != '0'


def config():
    url, code = os.environ.get('CLOUD_ROLL_URL', '').strip().rstrip('/'), os.environ.get('CLOUD_ROLL_PATH', '').strip().strip('/')
    if not url:
        return None                                 # the code (path) is optional: empty = the database root, like in the workers
    return {'url': url, 'code': code, 'auth': os.environ.get('CLOUD_ROLL_AUTH', '').strip(), 'session': os.environ.get('ERP_CLOUD_SESSION', '').strip(),
            'worker': os.environ.get('CLOUD_ROLL_WORKER_URL', '').strip().rstrip('/'), 'safety': max(60, int(os.environ.get('CLOUD_ROLL_SAFETY_SECS', '300')))}


def safe_key(v):
    return re.sub(r'[.$#\[\]/\s]', '_', str(v if v is not None else '').strip())     # same as the Reception app / worker


def _meta(key):
    d = Doc.objects.filter(coll='meta', key=key).first()
    return d.data if d and isinstance(d.data, dict) else {}


def _set_meta(key, value):
    Doc.objects.update_or_create(coll='meta', key=key, defaults={'data': value})


def note_biometric(date, adms):
    """cloud_att tells us which Present marks came from a scan only (not from a teacher's roll call)."""
    m = _meta(BIO_KEY)
    cur = set(m.get('adms', [])) if m.get('date') == date else set()
    cur.update(adms)
    _set_meta(BIO_KEY, {'date': date, 'adms': sorted(cur)})


def _post(url, body):
    req = urllib.request.Request(url, data=json.dumps(body).encode(), method='POST', headers={'Content-Type': 'application/json', 'User-Agent': 'SchoolERP/1.0'})
    with urllib.request.urlopen(req, timeout=60) as r:
        return json.loads(r.read() or b'{}')


class Bridge:
    def __init__(self, cfg, fb=None, post=None, directory=None):
        self.cfg, self.fb = cfg, fb or cloud_gp.Firebase(cfg)
        self.post = post or _post
        self.directory = directory                    # optional: fn() -> {adm: {name, class, busNumber}} from the gate / Reception student list
        self.warned = False
        self.warned_unknown = set()

    def _directory(self):
        if self.directory:
            return self.directory() or {}
        gcfg = cloud_gp.config()
        if not gcfg:
            return {}
        try:
            studs = cloud_gp.Firebase(gcfg).get('students') or {}
        except Exception:
            return {}
        return {str(v.get('admissionNumber')): v for v in studs.values() if isinstance(v, dict) and v.get('admissionNumber') is not None}

    def run_once(self, date=None):
        date = date or cloud_att.today()
        session = cloud_gp.session_for_date(self.cfg, date)
        key = 'eacademics_att' if session == store.BASE else f'eacademics_s{session}_att'
        studs = {s.adm_no: s for s in Student.objects.filter(session=session, left=False)}
        if not studs:
            d_sess = Doc.objects.filter(coll='kv', key='eacademics_sessions').first()
            if d_sess:
                try:
                    s_list = json.loads(store.load(d_sess.key, d_sess.data))
                    for sx in reversed(s_list):
                        sid = sx.get('id')
                        found = {s.adm_no: s for s in Student.objects.filter(session=sid, left=False)}
                        if found:
                            session, studs = sid, found
                            key = 'eacademics_att' if session == store.BASE else f'eacademics_s{session}_att'
                            break
                except Exception:
                    pass
        by_safe = {safe_key(a): a for a in studs}
        nz = {}                                                     # 0104 in the ERP / 104 in the cloud (or the reverse): same child, as the biometric sync already treats it
        for a in studs:
            if a.lstrip('0'):
                nz.setdefault(a.lstrip('0'), []).append(a)
        nozero = {z: v[0] for z, v in nz.items() if len(v) == 1}
        out = {'to_erp': 0, 'to_cloud': 0, 'conflicts': 0, 'unknown': 0}
        ckey, bad = {}, []
        self.last = {'date': date, 'session': session, 'active_students': len(studs)}

        raw = self.fb.get(f'attendance/{date}') or {}
        if not raw:
            raw = self.fb.get(date) or self.fb.get(f'rollcall/{date}') or {}
        cloud = {}
        for k, rec in (raw.items() if isinstance(raw, dict) else []):
            if not isinstance(rec, dict):
                continue
            rec_adm = rec.get('admissionNumber') or rec.get('adm') or rec.get('personId') or rec.get('studentId') or ''
            adm = (
                by_safe.get(str(k))
                or nozero.get(str(k).lstrip('0'))
                or (by_safe.get(str(rec_adm)) if rec_adm else None)
                or (nozero.get(str(rec_adm).lstrip('0')) if rec_adm else None)
            )
            if adm is None:
                out['unknown'] += 1
                bad.append(k)
                continue
            ckey[adm] = k
            raw_st = str(rec.get('status') or rec.get('att') or '').strip()
            st_norm = TO_ERP.get(raw_st) or TO_ERP.get(raw_st.lower())
            if st_norm == 'P':
                cloud[adm] = 'present'
            elif st_norm == 'A':
                cloud[adm] = 'absent'
            elif st_norm == 'L':
                cloud[adm] = 'leave'

        d = Doc.objects.filter(coll='kv', key=key).first()
        att = json.loads(store.load(key, d.data)) if d else {}
        erp, where = {}, {}
        for k, day in att.items():
            parts = k.split('|')
            if len(parts) == 3 and parts[0] == date and isinstance(day, dict):
                for adm, st in day.items():
                    if st in TO_CLOUD and adm in studs:
                        erp[adm], where[adm] = st, (parts[1], parts[2])

        self.last['cloud_marks'] = len(cloud); self.last['cloud_unmatched'] = sorted(map(str, bad))[:20]
        if not studs:
            log.warning('roll call: no active students in session %s, so nothing can sync. Check the session (ERP_CLOUD_SESSION in config.env) and that students are not all marked Left', session)
        elif bad and not cloud:
            other = sorted(set(Student.objects.filter(adm_no__in=[str(k) for k in bad]).exclude(session=session).values_list('session', flat=True)))
            if other:
                log.warning('roll call: the cloud admission numbers belong to session(s) %s but the sync uses %s. Set ERP_CLOUD_SESSION in config.env', ', '.join(other), session)
        if bad and set(bad) != self.warned_unknown:
            self.warned_unknown = set(bad)
            log.warning('roll call: %d cloud admission number(s) match no active student in the ERP and are ignored: %s', len(bad), ', '.join(sorted(map(str, bad))[:12]))
        base_doc = _meta(BASE_KEY)
        base = base_doc.get('marks', {}) if base_doc.get('date') == date else {}
        bio_doc = _meta(BIO_KEY)
        bio = set(bio_doc.get('adms', [])) if bio_doc.get('date') == date else set()

        set_erp, push, newbase = {}, {}, dict(base)
        conflict_adms = []
        for adm in set(cloud) | set(erp) | set(base):
            ce, ee, b = cloud.get(adm), erp.get(adm), base.get(adm)
            e_c = TO_CLOUD.get(ee)                                  # the ERP mark as the cloud would say it
            if ce == e_c:
                if ce:
                    newbase[adm] = ce
                else:
                    newbase.pop(adm, None)
                continue
            if adm in bio and ee == 'P' and b is None:              # present only because the child scanned
                if ce is None:
                    continue                                        # not a roll call mark: leave it in the ERP only
                if no_downgrade():
                    continue                                        # Present (scan) never goes down because of a later cloud mark
                set_erp[adm] = ce; newbase[adm] = ce; bio.discard(adm)     # a teacher's explicit mark beats the scan
                continue
            if e_c == b:                                            # the ERP did not change: the cloud did
                if ee == 'P' and ce != 'present' and no_downgrade():
                    continue                                        # keep Present: the base stays as it was, so nothing is sent to the cloud either
                set_erp[adm] = ce; newbase[adm] = ce
            elif ce == b:                                           # the cloud did not change: the ERP did
                push[adm] = e_c
            else:                                                   # both changed, differently: the ERP wins
                push[adm] = e_c; out['conflicts'] += 1; conflict_adms.append(adm)

        # cloud -> ERP
        if set_erp:
            def mutate(obj):
                n = 0
                for adm, new in set_erp.items():
                    s = studs[adm]
                    k = f'{date}|{s.cls}|{s.sec or ""}'
                    day = obj.get(k) or {}
                    now = day.get(adm)
                    if new is None:
                        if adm in day and now in TO_CLOUD:
                            del day[adm]; n += 1
                    elif TO_CLOUD.get(now) != new:               # (an ERP Leave stays Leave when the cloud says absent)
                        day[adm] = TO_ERP[new]; n += 1
                    if day:
                        obj[k] = day
                    else:
                        obj.pop(k, None)
                return n > 0 or False
            if cloud_att.update_doc(key, mutate):
                out['to_erp'] = len(set_erp)

        # ERP -> cloud: through the rollcall worker when its address is set (exactly what the Reception app does: the bus tally, the biometric DB and the
        # Google Sheet history are updated too), else straight into the Attendance DB (the Reception app shows it; tally / Sheet are not updated)
        if push:
            dr = self._directory()
            items, back = [], {}                                       # back: the number sent to the cloud -> the ERP's own admission number
            for adm, status in push.items():
                s, info = studs[adm], dr.get(adm) or {}
                cls, sec = where.get(adm, (s.cls, s.sec or ''))
                label = info.get('class') or (f'{cls}-{sec}' if sec else cls)         # the class name the cloud already uses, else the ERP's
                back[ckey.get(adm, adm)] = adm
                items.append({'admissionNumber': ckey.get(adm, adm), 'name': info.get('name') or ' '.join(x for x in (s.first_name, s.last_name) if x),
                              'class': label, 'busNumber': info.get('busNumber') or '', 'status': status or 'unmarked'})
            for i in range(0, len(items), CHUNK):
                part = items[i:i + CHUNK]
                try:
                    if self.cfg.get('worker'):
                        r = self.post(self.cfg['worker'] + '/mark', {'date': date, 'students': part})
                        if not (r or {}).get('ok', True):
                            log.warning('rollcall worker refused: %s', r)
                            break
                    else:
                        now = int(time.time() * 1000)
                        self.fb.patch(f'attendance/{date}', {safe_key(it['admissionNumber']): (None if it['status'] == 'unmarked' else
                                      {'status': it['status'], 'class': it['class'], 'busNumber': it['busNumber'], 'name': it['name'], 'ts': now}) for it in part})
                        if not self.warned:
                            self.warned = True
                            log.info('attendance: ERP marks are written straight into the Attendance Firebase (no rollcall worker address set): the Reception app shows '
                                     'them, but the bus tally and the Google Sheet history are not updated')
                except Exception as e:
                    log.warning('sending ERP attendance to the cloud failed (%s); will retry', e)
                    break
                for it in part:
                    if it['status'] == 'unmarked':
                        newbase.pop(back.get(it['admissionNumber'], it['admissionNumber']), None)
                    else:
                        newbase[back.get(it['admissionNumber'], it['admissionNumber'])] = it['status']
                out['to_cloud'] += len(part)

        self.last['erp_marks'] = len(erp); self.last['conflicts_adms'] = sorted(c for c in conflict_adms)[:20]
        if conflict_adms:
            log.warning('roll call: %d student(s) had different marks on both sides before the first sync, the ERP mark was kept and sent to the cloud: %s', len(conflict_adms), ', '.join(sorted(conflict_adms)[:12]))
        _set_meta(BASE_KEY, {'date': date, 'marks': newbase})
        _set_meta(BIO_KEY, {'date': date, 'adms': sorted(bio)})
        return out


def _on_kv(key):
    if key.endswith('_att'):
        WAKE.set()


def attach():
    """An attendance change saved in the ERP wakes the worker at once."""
    events.on('kv', _on_kv)


def date_stream(bridge, stop=None):
    """Listen to today's roll call in the Attendance DB; at midnight (India) move on to the next day's."""
    while not (stop and stop.is_set()):
        d = cloud_att.today()
        livesync.stream(bridge.fb._url(f'attendance/{d}'), WAKE, stop, until=lambda d=d: cloud_att.today() != d)


def loop(stop=None):
    cfg = config()
    if not cfg:
        return
    attach()
    b = Bridge(cfg)
    threading.Thread(target=date_stream, args=(b, stop), name='stream-rollcall', daemon=True).start()
    log.info('Class roll call sync ON (live, both ways%s)', '' if cfg['worker'] else '; ERP attendance is written straight into the Firebase: set CLOUD_ROLL_WORKER_URL to also update the bus tally / Google Sheet')

    def work():
        st = b.run_once()
        if any(st.values()):
            log.info('roll call sync: %s', st)
    livesync.run_loop('roll call sync', WAKE, work, cfg['safety'], stop)


def fetch_all():
    """FORCE FETCH: every day in the cloud's roll call (not only today). The usual two-way rules apply to each day."""
    cfg = config()
    if not cfg:
        raise RuntimeError('Class roll call is not set up')
    b = Bridge(cfg)
    days = [d for d in b.fb.keys('attendance') if re.match(r'^\d{4}-\d{2}-\d{2}$', d) and d <= cloud_att.today()]
    tot = {'days in the cloud': len(days), 'marks to the ERP': 0, 'conflicts': 0}
    for d in days:
        st = b.run_once(d)
        tot['marks to the ERP'] += st.get('to_erp', 0)
        tot['conflicts'] += st.get('conflicts', 0)
    return tot


def start_background():
    if not config():
        return None
    t = threading.Thread(target=loop, name='cloud-roll', daemon=True)
    t.start()
    return t
