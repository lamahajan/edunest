import base64
import json
import os
from django.http import HttpResponse
import re
import threading
import time
import urllib.parse
import zlib
from pathlib import Path

from django.conf import settings
from django.db import IntegrityError, connection, transaction
from rest_framework.authtoken.models import Token
from rest_framework.decorators import api_view, authentication_classes, permission_classes, throttle_classes
from rest_framework.exceptions import PermissionDenied
from rest_framework.response import Response
from rest_framework.throttling import AnonRateThrottle
from django.contrib.auth import get_user_model

import threading

from django.core.management.base import CommandError
from django.http import FileResponse

from . import dbtools, events, mediafix, medianame, perms, store, person
from .models import Change, Doc, DocAsset, Person, ReceiptDoc, SavedDoc, Student, drop_orphan_person


def lock(name):
    """Serialise writers per student on PostgreSQL (no-op on SQLite dev DB)."""
    if connection.vendor == 'postgresql':
        with connection.cursor() as c:
            c.execute('SELECT pg_advisory_xact_lock(%s)', [zlib.crc32(name.encode())])


# Real-time push (long-poll): a browser asks delta/?wait=25 and the server holds that request until something changes, then answers at once.
_cv = threading.Condition()
_tick = 0
_shutting_down = threading.Event()


def begin_shutdown():
    """serve.py calls this when the server stops / restarts: every held long-poll request answers at once, so the old server ends in about a second
    (before, it waited up to 25 s for the open browsers and kept the https port busy, so the new server could not start)."""
    _shutting_down.set()
    with _cv:
        _cv.notify_all()


def _wake():
    global _tick
    with _cv:
        _tick += 1
        _cv.notify_all()


def note(coll, key, action='put'):
    Change.objects.create(coll=coll, key=str(key), action=action)
    transaction.on_commit(_wake)          # wake every waiting browser the moment the change is really saved
    transaction.on_commit(lambda: events.fire(coll, key))          # and every cloud sync worker that cares


def _wait_for_change(since, secs):
    """Block up to `secs` seconds until a Change newer than `since` exists. Wakes instantly for changes made by this server;
    also looks at the database every 5 s so changes made by another process (a sync script) are noticed too."""
    end = time.monotonic() + secs
    while True:
        if _shutting_down.is_set():
            return
        with _cv:
            t0 = _tick
        if Change.objects.filter(id__gt=since).exists():
            return
        left = end - time.monotonic()
        if left <= 0:
            return
        with _cv:
            if _tick == t0:
                _cv.wait(min(5, left))


def last_change():
    return Change.objects.order_by('-id').values_list('id', flat=True).first() or 0


def rec_out(r):
    return {'id': r.pk, 'version': r.version, 'session': r.session, 'data': r.data}


def need(request, pairs):
    if pairs is not None and not perms.can_any(request.user, pairs):
        raise PermissionDenied('You do not have permission for this action.')


def mine(user, key):
    """Per-user settings live under u/<username>/...; everybody else's are never sent."""
    key = urllib.parse.unquote(key)
    return not key.startswith('u/') or key.startswith(f'u/{user.username}/')


def doc_out(d):
    return {'key': d.key, 'version': d.version, 'data': d.data}


def kv_val(d):
    """Document text as the screens expect it (hashes hidden; table-backed documents rebuilt from their tables)."""
    if d.key == perms.USERS_KEY:
        return perms.public_users(d.data)
    return store.load(d.key, d.data)


def stud_key(st):
    return f'{st.session}|{st.adm_no}'


def _with_people(students):
    """The students of a list, each with its personal copy attached (one query instead of one per student)."""
    students = list(students)
    pm = {p.adm_no: p.data for p in Person.objects.filter(adm_no__in={s.adm_no for s in students})} if len(students) < 20000 else {p.adm_no: p.data for p in Person.objects.all()}
    for st in students:
        st._pd = pm.get(st.adm_no, {})
    return students


def stud_out(st):
    return {'key': stud_key(st), 'version': st.version, 'data': st.data}


@api_view(['GET'])
def adm_check(request):
    """Does this admission number exist (in ANY session)? -> {exists, name, sessions}"""
    adm = (request.query_params.get('adm') or '').strip().upper()
    p = Person.objects.filter(adm_no=adm).first() if adm else None
    if p is None:
        return Response({'exists': False, 'name': '', 'sessions': []})
    return Response({'exists': True, 'name': f'{p.data.get("first", "")} {p.data.get("last", "")}'.strip(), 'sessions': list(Student.objects.filter(adm_no=adm).order_by('session').values_list('session', flat=True))})


@api_view(['GET'])
def register(request):
    """The Admission & Withdrawal Register is PROGRESSIVE: up to a session it holds every child admitted in that session or earlier (2009: 10 admitted; 2010: 15 more, 5 left -> 25 lines).
    One record per admission number: personal details and withdrawal as of the latest session <= `upto`, admission date / class from the FIRST session the child appears in."""
    upto = (request.query_params.get('upto') or '').strip()
    rows = {}
    qs = Student.objects.order_by('session', 'adm_no')
    if upto:
        qs = qs.filter(session__lte=upto)
    for st in _with_people(qs):
        rows.setdefault(st.adm_no, []).append(st)
    out = []
    for adm, lst in rows.items():
        first, last = lst[0], lst[-1]
        d = dict(last.data)
        fd = first.data
        d['date'] = fd.get('date') or ''
        d['_first'] = first.session
        d['_admCls'] = ((fd.get('family') or {}).get('ward') or {}).get('admClass') or ' '.join(x for x in (fd.get('cls'), ('(' + fd['sec'] + ')') if fd.get('sec') else '') if x)
        d['_lastSeen'] = last.session
        out.append(d)
    out.sort(key=lambda d: (d['_first'], d['date'], len(str(d.get('adm', ''))), str(d.get('adm', ''))))
    return Response({'upto': upto, 'last': last_change(), 'rows': out})


# ---------------------------------------------------------------- bootstrap / delta
@api_view(['GET'])
def bootstrap(request):
    last = last_change()
    docs = Doc.objects.all()
    # Only the students / receipts of the session the user works in are sent (the app shows one session at a time; a switch reloads the page).
    # ?sess=<id> says which, ?sess=all sends everything; without it the server uses the user's saved active session (all, if unknown).
    sess = (request.query_params.get('sess') or '').strip()
    if not sess:
        d0 = Doc.objects.filter(coll='kv', key=f'u/{request.user.username}/eacademics_activesess').first()
        sess = str(kv_val(d0) if d0 else '').strip().strip('"')
    if sess == 'all' or not sess:
        sess, students, receipts = 'all', Student.objects.order_by('session', 'adm_no'), ReceiptDoc.objects.order_by('voucher_no')
    else:
        students, receipts = Student.objects.filter(session=sess).order_by('adm_no'), ReceiptDoc.objects.filter(session=sess).order_by('voucher_no')
    # Nothing changed since this browser last loaded: answer 304 (no body).
    etag = '"bs-%s-%s-%s-%s-%s-%s-%s"' % (last, request.user.username, sess, Doc.objects.count(), Student.objects.count(), ReceiptDoc.objects.count(), os.environ.get('ERP_VER', ''))
    if request.headers.get('If-None-Match', '').replace('-gz"', '"') == etag:
        r = HttpResponse(status=304)
        r['ETag'] = etag
        r['Cache-Control'] = 'private, no-cache'
        return r
    resp = Response({
        'last': last,
        'user': request.user.username,
        'https_port': settings.ERP_HTTPS_PORT if (settings.DATA_DIR / 'certs' / 'server.crt').exists() else 0,
        'trusted_domain': os.environ.get('ERP_DOMAIN', '') if (settings.DATA_DIR / 'certs' / 'trusted.crt').exists() else '',
        'seeded': docs.filter(coll='meta', key='seeded').exists(),
        'kv': {d.key: {'v': kv_val(d), 'ver': d.version} for d in docs if d.coll == 'kv' and mine(request.user, d.key)},
        'adm_session': sess,
        'adm': [stud_out(st) for st in _with_people(students)],
        'receipts': [rec_out(r) for r in receipts],
    })
    resp['ETag'] = etag
    resp['Cache-Control'] = 'private, no-cache'
    return resp


@api_view(['GET'])
def delta(request):
    since = int(request.query_params.get('since', 0))
    try:
        wait = max(0, min(int(request.query_params.get('wait', 0)), 25))
    except ValueError:
        wait = 0
    if wait:
        _wait_for_change(since, wait)
    rows = list(Change.objects.filter(id__gt=since).order_by('id')[:3000])
    if not rows:
        return Response({'last': since, 'kv': [], 'adm': [], 'receipts': [], 'events': []})
    latest = {(c.coll, c.key): c for c in rows}
    out = {'last': rows[-1].id, 'kv': [], 'adm': [], 'receipts': [], 'events': [{'coll': c, 'key': k} for (c, k) in latest if c not in ('kv', 'adm', 'receipts')]}
    for (coll, key) in latest:
        if coll == 'kv' and not mine(request.user, key):
            continue
        if coll == 'kv':
            d = Doc.objects.filter(coll='kv', key=key).first()
            out['kv'].append({'key': key, 'deleted': d is None, 'version': d.version if d else 0, 'data': kv_val(d) if d else None})
        elif coll == 'adm':
            ses, _, adm = key.partition('|')
            st = Student.objects.filter(session=ses, adm_no=adm).first()
            out['adm'].append({'key': key, 'deleted': st is None, 'version': st.version if st else 0, 'data': st.data if st else None})
        elif coll == 'receipts':
            r = ReceiptDoc.objects.filter(pk=int(key)).first()
            out['receipts'].append({'id': int(key), 'deleted': r is None, 'version': r.version if r else 0,
                                    'session': r.session if r else None, 'data': r.data if r else None})
    return Response(out)


# ---------------------------------------------------------------- generic docs (kv / adm)
def _merge_users(old_text, new_text):
    """The browser never sees password hashes: keep the stored hash unless a new one was sent; a changed password signs that user out."""
    try:
        old, new = json.loads(old_text or '[]'), json.loads(new_text)
        by = {str(o.get('id')): o for o in old}
        for u in new:
            o = by.get(str(u.get('id')))
            if not u.get('pass'):
                u['pass'] = (o or {}).get('pass', '')
            elif o and o.get('pass') != u['pass']:
                Token.objects.filter(user__username=str(u.get('username', '')).lower()).delete()
        gone = {str(o.get('username', '')).lower() for o in old} - {str(u.get('username', '')).lower() for u in new}
        if gone:
            Token.objects.filter(user__username__in=gone).delete()
        return json.dumps(new)
    except (TypeError, ValueError, AttributeError):
        return new_text


def _put_kv(key, data, base):
    data = mediafix.fix_text(data)
    if key == medianame.SCHOOL_KEY:
        data = medianame.rename_school(data)
    with transaction.atomic():
        lock(f'kv:{key}')
        d = Doc.objects.select_for_update().filter(coll='kv', key=key).first()
        if key == perms.USERS_KEY:
            data = _merge_users(store.load(key, d.data) if d else '[]', data)
        if d is None:
            d = Doc.objects.create(coll='kv', key=key, data=store.store(key, data))
        else:
            if base != d.version:
                return Response({'error': 'version', 'key': key, 'version': d.version, 'data': kv_val(d)}, status=409)
            d.data, d.version = store.store(key, data), d.version + 1
            d.save()
        note('kv', key)
        return Response({'version': d.version})


def current_session(today=None):
    from datetime import date
    d = today or date.today()
    return f'{d.year}-{d.year + 1}' if d.month >= 4 else f'{d.year - 1}-{d.year}'


def ensure_session(ses):
    """A student admitted into a session that is not in the session list yet (admission date of another year): the session is added to the list."""
    import json
    d = Doc.objects.filter(coll='kv', key='eacademics_sessions').first()
    cur = json.loads(store.load('eacademics_sessions', d.data)) if d else [{'id': current_session()}]
    if any(x.get('id') == ses for x in cur):
        return
    cur.append({'id': ses, 'from': '', 'at': '', 'carried': 0, 'added': True})
    cur.sort(key=lambda x: str(x.get('id')))
    _put_kv('eacademics_sessions', json.dumps(cur), d.version if d else None)


def _put_adm(key, rec, base):
    rec = mediafix.fix_obj(rec) if isinstance(rec, dict) else rec
    ses, _, adm = key.partition('|')
    if not ses or not adm or not isinstance(rec, dict) or str(rec.get('adm')) != adm:
        return Response({'error': 'invalid admission'}, status=400)
    rec = medianame.rename_record(rec, ses, adm)            # photos / documents get names like 22012_student.jpg
    with transaction.atomic():
        lock(f'adm:{key}')
        st = Student.objects.select_for_update().filter(session=ses, adm_no=adm).first()
        if st is None:
            owner = Person.objects.filter(adm_no=adm).first()           # one admission number = one child (a child who left and joins again gets a NEW number)
            if owner is not None and person.clearly_different(owner.data, rec):
                return Response({'error': 'number', 'message': f'Admission No {adm} already belongs to {owner.data.get("first", "")} {owner.data.get("last", "")}'.strip()}, status=409)
            st = Student.objects.create(session=ses, adm_no=adm, **store.student_fields(rec))
            ensure_session(ses)
        else:
            if base != st.version:
                return Response({'error': 'version', **stud_out(st)}, status=409)
            for k, v in store.student_fields(rec).items():
                setattr(st, k, v)
            st.version += 1
            st.save()
        note('adm', key)
        for other in st.touched:                              # the personal part is ONE copy: the other sessions' rows changed with it
            note('adm', f'{other}|{adm}')
        return Response({'version': st.version})


@api_view(['PUT', 'DELETE'])
def doc(request, coll, key):
    key = urllib.parse.unquote(key)
    if coll not in ('kv', 'adm'):
        return Response({'error': 'bad collection'}, status=404)
    if coll == 'kv' and not mine(request.user, key):
        return Response({'error': 'not allowed'}, status=403)
    if coll == 'kv':
        need(request, None if key.startswith('u/') else perms.kv_pairs(key))
    else:
        need(request, perms.ADM_WRITE if request.method == 'PUT' else perms.ADM_DELETE)
    if request.method == 'PUT':
        return _put_kv(key, request.data.get('data'), request.data.get('base_version')) if coll == 'kv' else _put_adm(key, request.data.get('data'), request.data.get('base_version'))
    with transaction.atomic():
        if coll == 'kv':
            store.purge(key)
            n, _ = Doc.objects.filter(coll='kv', key=key).delete()
        else:
            ses, _, adm = key.partition('|')
            n, _ = Student.objects.filter(session=ses, adm_no=adm).delete()
            drop_orphan_person(adm)
        if n:
            note(coll, key, 'delete')
    return Response({'deleted': n})


# ---------------------------------------------------------------- receipts
def _check(rec, exclude_pk=None):
    """Returns an error Response if the voucher number or a period is already taken."""
    d, ses = rec.get('data') or {}, str(rec.get('session') or '2026-2027')
    try:
        v, adm, periods = int(d['v']), str(d['adm']), [int(p) for p in d['periods']]
    except (KeyError, TypeError, ValueError):
        return None, Response({'error': 'invalid receipt'}, status=400)
    if v <= 0:
        return None, Response({'error': 'invalid receipt', 'detail': 'Receipt No must be > 0'}, status=400)
    same = ReceiptDoc.objects.filter(session=ses, voucher_no=v)
    if exclude_pk:
        same = same.exclude(pk=exclude_pk)
    if same.exists():
        return None, Response({'error': 'voucher', 'detail': f'Receipt No {v} is already used by another voucher.'}, status=409)
    if not d.get('cancelled'):
        others = ReceiptDoc.objects.filter(session=ses, adm=adm, cancelled=False)
        if exclude_pk:
            others = others.exclude(pk=exclude_pk)
        # 1.0.36 part payments: a month may be on two receipts when one of them carries only that month's BALANCE (data.recv.__ovr lists such months)
        def carried(x):
            try:
                return {int(k) for k in (((x or {}).get('recv') or {}).get('__ovr') or {}).keys()}
            except (TypeError, ValueError, AttributeError):
                return set()
        mine_c = carried(d)
        if any((set(periods) & set(o.periods)) - mine_c - carried(o.data) for o in others):
            return None, Response({'error': 'period', 'detail': 'A period on this receipt was already paid on another receipt.'}, status=409)
    return (ses, v, adm, periods, bool(d.get('cancelled'))), None


@api_view(['POST'])
def receipt_create(request):
    need(request, [('feeReceipt', 'add')])
    with transaction.atomic():
        lock('adm:' + str(request.data.get('session') or '') + '|' + str((request.data.get('data') or {}).get('adm')))
        ok, err = _check(request.data)
        if err:
            return err
        ses, v, adm, periods, canc = ok
        try:
            with transaction.atomic():
                r = ReceiptDoc.objects.create(session=ses, voucher_no=v, adm=adm, cancelled=canc, periods=periods, data=request.data['data'])
        except IntegrityError:
            return Response({'error': 'voucher', 'detail': f'Receipt No {v} is already used by another voucher.'}, status=409)
        note('receipts', r.pk)
        return Response({'id': r.pk, 'version': r.version}, status=201)


@api_view(['PUT', 'DELETE'])
def receipt_item(request, pk):
    need(request, [('feeReceipt', 'delete')] if request.method == 'DELETE' else [('feeReceipt', 'edit')])
    with transaction.atomic():
        r = ReceiptDoc.objects.select_for_update().filter(pk=pk).first()
        if r is None:
            return Response({'error': 'gone'}, status=404)
        lock('adm:' + r.session + '|' + r.adm)
        if request.method == 'DELETE':
            r.delete()                      # frees the voucher number
            note('receipts', pk, 'delete')
            return Response({'deleted': 1})
        if request.data.get('base_version') != r.version:
            return Response({'error': 'version', **rec_out(r)}, status=409)
        ok, err = _check(request.data, exclude_pk=r.pk)
        if err:
            return err
        r.session, r.voucher_no, r.adm, r.periods, r.cancelled = ok
        r.data, r.version = request.data['data'], r.version + 1
        try:
            with transaction.atomic():
                r.save()
        except IntegrityError:
            return Response({'error': 'voucher', 'detail': 'Receipt No already used.'}, status=409)
        note('receipts', r.pk)
        return Response({'id': r.pk, 'version': r.version})


@api_view(['POST'])
def seed(request):
    """First run only: store the sample students/receipts the UI generated."""
    need(request, [('adminZone', 'edit')])
    with transaction.atomic():
        lock('seed')
        if Doc.objects.filter(coll='meta', key='seeded').exists():
            return Response({'error': 'already seeded'}, status=409)
        ses = str(request.data.get('session') or '2026-2027')
        for a in request.data.get('adm', []):
            Student.objects.create(session=ses, adm_no=str(a['adm']), **store.student_fields(a))
            note('adm', f"{ses}|{a['adm']}")
        for d in request.data.get('receipts', []):
            r = ReceiptDoc.objects.create(session=ses, voucher_no=int(d['v']), adm=str(d['adm']), cancelled=bool(d.get('cancelled')),
                                          periods=d['periods'], data=d)
            note('receipts', r.pk)
        Doc.objects.create(coll='meta', key='seeded', data=True)
    return Response({'ok': True}, status=201)


# ---------------------------------------------------------------- photos / documents -> files on the server
EXT = {'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp', 'image/gif': 'gif', 'application/pdf': 'pdf'}
MAGIC = {'jpg': (b'\xff\xd8\xff',), 'png': (b'\x89PNG',), 'gif': (b'GIF8',), 'pdf': (b'%PDF',), 'webp': (b'RIFF',)}
MAX_FILE = 15 * 1024 * 1024


def media_path(name, ext):
    return Path(settings.MEDIA_ROOT) / f'{name}.{ext}'


@api_view(['POST'])
def file_upload(request):
    """Stores a photo/PDF sent as a data URL under a content-derived name; idempotent, never overwrites different bytes."""
    name, data = str(request.data.get('name', '')), str(request.data.get('data', ''))
    m = re.fullmatch(r'data:([\w/+.-]+);base64,(.+)', data, re.S)
    if not m or m.group(1) not in EXT or not re.fullmatch(r'[0-9a-z]{16,64}', name):
        return Response({'error': 'bad file'}, status=400)
    ext = EXT[m.group(1)]
    try:
        raw = base64.b64decode(m.group(2), validate=True)
    except Exception:
        return Response({'error': 'bad base64'}, status=400)
    if len(raw) > MAX_FILE:
        return Response({'error': 'file too large (max 15 MB)'}, status=413)
    if not raw.startswith(MAGIC[ext]):
        return Response({'error': 'content does not match type'}, status=400)
    path = media_path(name, ext)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        if path.read_bytes() != raw:
            return Response({'error': 'name clash'}, status=409)
        medianame.after_upload(name, ext, note, store, lock)
        return Response({'url': f'/media/{name}.{ext}'})
    tmp = path.with_name(path.name + '.part')
    tmp.write_bytes(raw)
    os.replace(tmp, path)
    medianame.after_upload(name, ext, note, store, lock)      # the record may have been saved before the file arrived
    return Response({'url': f'/media/{name}.{ext}'}, status=201)


@api_view(['POST'])
def doc_pdf(request):
    """PDF of a certificate / document that got a reference number: kept in media/certificates/<year>/<Ref No> <Name>.pdf (year = year of the issue date)."""
    name = re.sub(r'[\\/:*?"<>|\r\n\t]+', '-', str(request.data.get('name', ''))).strip(' .')
    name = name[:-4].strip(' .') if name.lower().endswith('.pdf') else name
    name = re.sub(r'\s+', ' ', name)[:150].strip(' .')
    m = re.fullmatch(r'data:application/pdf;base64,(.+)', str(request.data.get('data', '')), re.S)
    if not name or not m:
        return Response({'error': 'bad file'}, status=400)
    y = str(request.data.get('date', ''))[:4]
    year = y if y.isdigit() and 1990 <= int(y) <= 2100 else str(time.localtime().tm_year)
    try:
        raw = base64.b64decode(m.group(1), validate=True)
    except Exception:
        return Response({'error': 'bad base64'}, status=400)
    if len(raw) > 4 * MAX_FILE:
        return Response({'error': 'file too large'}, status=413)
    if not raw.startswith(b'%PDF'):
        return Response({'error': 'content does not match type'}, status=400)
    path = Path(settings.MEDIA_ROOT) / 'certificates' / year / f'{name}.pdf'
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + '.part')
    tmp.write_bytes(raw)
    os.replace(tmp, path)
    return Response({'url': f'/media/certificates/{year}/{urllib.parse.quote(name)}.pdf'})


# ---------------------------------------------------------------- sign in (against the app's own user list)
class LoginThrottle(AnonRateThrottle):
    scope = 'login'


@api_view(['POST'])
@authentication_classes([])
@permission_classes([])
@throttle_classes([LoginThrottle])
def login(request):
    un, pw = str(request.data.get('username', '')).strip().lower(), str(request.data.get('password', ''))
    rec = perms.ui_user(un)
    if not (perms.is_active(rec) and perms.password_ok(rec.get('pass'), pw)):
        return Response({'error': 'Wrong username or password'}, status=401)
    U = get_user_model()
    user, made = U.objects.get_or_create(username=un)
    if made:
        user.set_unusable_password()
        user.save()
    token, _ = Token.objects.get_or_create(user=user)
    return Response({'token': token.key, 'username': un, 'name': rec.get('name', un)})


@api_view(['GET'])
@authentication_classes([])
@permission_classes([])
@throttle_classes([LoginThrottle])
def login_info(request):
    """What the sign-in screen needs before anybody is signed in: school name and (unless ERP_LOGIN_LIST=0) the list of login names."""
    name = ''
    d = Doc.objects.filter(coll='kv', key='eacademics_school').first()
    try:
        name = (json.loads(d.data) or {}).get('name', '') if d else ''
    except (TypeError, ValueError, AttributeError):
        name = ''
    users = []
    if os.environ.get('ERP_LOGIN_LIST', '1') != '0':
        users = [{'username': u.get('username'), 'name': u.get('name') or u.get('username')} for u in perms.load_users() if perms.is_active(u) and u.get('username')]
    return Response({'school': name or os.environ.get('ERP_SCHOOL_NAME') or 'EduNest', 'users': users})


# ---------------------------------------------------------------- backup (same file as ERP.bat > Backup now / export_data)
_backup_lock = threading.Lock()


@api_view(['POST'])
def backup_now(request):
    """Makes the backup zip on the server (backups folder) and sends the same file for download. Administrator only."""
    need(request, [('adminZone', 'edit')])
    with _backup_lock:
        try:
            path = dbtools.make_backup()
        except CommandError as e:
            return Response({'error': str(e)}, status=500)
    resp = FileResponse(open(path, 'rb'), as_attachment=True, filename=path.name, content_type='application/zip')
    resp['X-Backup-Saved'] = str(path)
    resp['X-Backup-Media'] = '1' if path.stem.endswith('_media') else '0'
    if path.parent != dbtools.backup_dir():
        resp['X-Backup-Warning'] = f'The chosen backup folder could not be used, so this backup was saved in {path.parent}'
    return resp


@api_view(['POST'])
def backup_closing(request):
    """Cash closure: any cashier who may take fees can trigger the server backup (kept in the backups folder, nothing is downloaded)."""
    need(request, [('feeReceipt', 'add'), ('feeReceipt', 'edit')])
    with _backup_lock:
        try:
            path = dbtools.make_backup()
        except CommandError as e:
            return Response({'error': str(e)}, status=500)
    out = {'ok': True, 'saved': str(path)}
    if path.parent != dbtools.backup_dir():
        out['warn'] = f'The chosen backup folder could not be used, so this backup was saved in {path.parent}'
    return Response(out)


@api_view(['GET', 'POST'])
def backup_options(request):
    """What goes into a backup (Setup > School Setup > Backup): photos / documents every time, and / or on the last date of every month. Administrator only.
    POST {media_every: bool, media_monthend: bool} saves it."""
    need(request, [('adminZone', 'edit')])
    if request.method == 'POST':
        from . import cloud_setup
        cloud_setup.write_env({'ERP_BACKUP_MEDIA': '1' if request.data.get('media_every') else '0', 'ERP_BACKUP_MEDIA_MONTHEND': '1' if request.data.get('media_monthend') else ''})
    return Response({'ok': True, 'options': dbtools.backup_options()})


@api_view(['GET'])
def security_notice(request):
    """Administrator only: is the well-known default password (admin123) still in use? The ERP shows a warning until it is changed."""
    need(request, [('adminZone', 'edit')])
    return Response({'defaultPassword': perms.uses_default_password()})


@api_view(['GET', 'POST'])
def backup_folder(request):
    """Where the server keeps its backups (Setup > School Setup > Backup folder). Administrator only.
    POST {path} saves it (empty = the program's own folder); POST {path, test: true} only checks the folder."""
    need(request, [('adminZone', 'edit')])
    if request.method == 'POST':
        path = str(request.data.get('path') or '').strip().strip('"')
        if path:
            if not (re.match(r'^[A-Za-z]:[\\/]', path) or path.startswith('\\\\') or path.startswith('/')):
                return Response({'ok': False, 'error': 'Type the full path of the folder, for example D:\\ERP-Backups'}, status=400)
            if re.search(r'[\r\n\x00]', path):
                return Response({'ok': False, 'error': 'not a valid folder path'}, status=400)
            why = dbtools.check_folder(path)
            if why:
                return Response({'ok': False, 'error': why}, status=400)
        if not request.data.get('test'):
            from . import cloud_setup
            cloud_setup.write_env({'ERP_BACKUP_DIR': path})
        info = dbtools.backup_info() if not request.data.get('test') else {'folder': path or str(dbtools.default_backup_dir())}
        return Response({'ok': True, 'message': 'This folder works.' if request.data.get('test') else ('Saved. Backups now go to ' + info['folder']), 'info': info})
    return Response({'info': dbtools.backup_info()})


# ---------------------------------------------------------------- saved certificates (were in each browser's IndexedDB)
@api_view(['GET'])
def docs_list(request):
    return Response([d.data for d in SavedDoc.objects.order_by('at')])


@api_view(['GET', 'PUT', 'DELETE'])
def docs_item(request, key):
    if request.method == 'GET':
        d = SavedDoc.objects.filter(doc_id=key).first()
        return Response(d.data) if d else Response({'error': 'gone'}, status=404)
    need(request, perms.DOC_WRITE)
    if request.method == 'DELETE':
        SavedDoc.objects.filter(doc_id=key).delete()
        return Response({'deleted': 1})
    rec = request.data
    if not isinstance(rec, dict) or str(rec.get('id')) != key:
        return Response({'error': 'invalid record'}, status=400)
    rec = mediafix.offload(dict(rec))
    SavedDoc.objects.update_or_create(doc_id=key, defaults={'at': int(rec.get('at') or 0), 'signed': bool(rec.get('signed')), 'data': rec})
    return Response({'ok': 1})


@api_view(['GET'])
def assets_list(request):
    return Response([{'k': a.key, 'v': a.value} for a in DocAsset.objects.all()])


@api_view(['GET', 'PUT'])
def assets_item(request, key):
    if request.method == 'GET':
        a = DocAsset.objects.filter(key=key).first()
        return Response({'k': a.key, 'v': a.value}) if a else Response({'error': 'gone'}, status=404)
    need(request, perms.DOC_WRITE)
    rec = request.data
    if not isinstance(rec, dict) or str(rec.get('k')) != key or not isinstance(rec.get('v'), str):
        return Response({'error': 'invalid record'}, status=400)
    DocAsset.objects.update_or_create(key=key, defaults={'value': mediafix.offload({'v': rec['v']})['v']})
    return Response({'ok': 1})
