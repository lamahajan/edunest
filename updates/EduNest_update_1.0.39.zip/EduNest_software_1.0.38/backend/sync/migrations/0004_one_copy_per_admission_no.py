"""One copy of each child's / family's details (table Person) instead of one full copy per academic session.
The session rows keep only their own part (class, section, roll, fee, left-status ...). A safety copy of the database is made first (SQLite)."""
import sqlite3
from datetime import datetime

from django.conf import settings
from django.db import migrations, models


MON = {m: i + 1 for i, m in enumerate(['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'])}


def when(st):
    """When was this session's admission record last edited? The form's own 'modified on' (else 'entered on'), else the row's save time."""
    import re
    d = st.sdata if isinstance(st.sdata, dict) else {}
    for k in ('modAt', 'addedAt'):
        m = re.match(r'\s*(\d{1,2})-([A-Za-z]{3})-(\d{4}),?\s*(\d{1,2}):(\d{2})\s*([AaPp][Mm])?', str(d.get(k) or ''))
        if m and m.group(2).title() in MON:
            h = int(m.group(4)) % 12 + (12 if (m.group(6) or '').lower() == 'pm' else 0) if m.group(6) else int(m.group(4))
            try:
                return datetime(int(m.group(3)), MON[m.group(2).title()], int(m.group(1)), h, int(m.group(5))).timestamp()
            except ValueError:
                pass
    return st.updated_at.timestamp() if st.updated_at else 0


def split_students(apps, schema_editor):
    from sync import person
    from sync.store import student_fields
    Student, Person = apps.get_model('sync', 'Student'), apps.get_model('sync', 'Person')
    db = schema_editor.connection
    if db.vendor == 'sqlite' and Student.objects.exists():                       # committed state = the data as it is now
        try:
            d = settings.DATA_DIR / 'backups'
            d.mkdir(parents=True, exist_ok=True)
            src, out = sqlite3.connect(str(db.settings_dict['NAME'])), sqlite3.connect(str(d / f'before_one_copy_{datetime.now():%Y%m%d_%H%M%S}.sqlite3'))
            with out:
                src.backup(out)
            src.close(); out.close()
        except Exception:
            pass
    rows = {}
    for st in Student.objects.all().order_by('adm_no', 'session'):
        rows.setdefault(st.adm_no, []).append(st)
    conflicts = []
    for adm, lst in rows.items():
        best = max(lst, key=lambda st: (when(st), st.session))                      # the session edited LAST wins (a tie: the newer session)
        final = person.split(best.sdata)[0]
        parts = [person.split(st.sdata)[0] for st in lst if st is not best]
        if any(p != final for p in parts):
            diff = sorted({k for p in parts for k in set(p) | set(final) if p.get(k) != final.get(k) and k != 'family'})
            if diff:
                conflicts.append(f'{adm}: {", ".join(diff)} differed between sessions - kept the value of {best.session} (edited last)')
        Person.objects.create(adm_no=adm, data=final)
        for st in lst:
            full = person.merge(final, person.split(st.sdata)[1])
            cols = student_fields(full)
            cols.pop('data')
            for k, v in cols.items():
                setattr(st, k, v)
            st.sdata = person.split(st.sdata)[1]
            st.save()
    if conflicts:
        try:
            (settings.DATA_DIR / 'one_copy_conflicts.txt').write_text('\n'.join(conflicts), encoding='utf-8')
        except Exception:
            pass


class Migration(migrations.Migration):
    dependencies = [('sync', '0003_docasset_saveddoc')]

    operations = [
        migrations.CreateModel(name='Person', fields=[
            ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
            ('adm_no', models.CharField(max_length=20, unique=True)),
            ('data', models.JSONField(default=dict)),
            ('version', models.PositiveIntegerField(default=1)),
            ('updated_at', models.DateTimeField(auto_now=True)),
        ]),
        migrations.RenameField(model_name='student', old_name='data', new_name='sdata'),
        migrations.AlterField(model_name='student', name='sdata', field=models.JSONField(default=dict)),
        migrations.RunPython(split_students, migrations.RunPython.noop),
    ]
