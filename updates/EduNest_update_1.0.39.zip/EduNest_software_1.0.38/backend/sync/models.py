from django.db import models


class Doc(models.Model):
    """Generic shared document: coll='kv' (settings blobs), 'adm' (one admission per row), 'meta'."""
    coll = models.CharField(max_length=20)
    key = models.CharField(max_length=120)
    data = models.JSONField()
    version = models.PositiveIntegerField(default=1)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        constraints = [models.UniqueConstraint(fields=['coll', 'key'], name='uniq_doc')]


class ReceiptDoc(models.Model):
    """A fee receipt exactly as the UI computed it; the server enforces the invariants."""
    session = models.CharField(max_length=20, default='2026-2027')
    voucher_no = models.PositiveIntegerField()               # unique per session -> a deleted number can be reused
    adm = models.CharField(max_length=20, db_index=True)
    cancelled = models.BooleanField(default=False)
    periods = models.JSONField(default=list)
    data = models.JSONField()
    version = models.PositiveIntegerField(default=1)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        constraints = [models.UniqueConstraint(fields=['session', 'voucher_no'], name='uniq_voucher_per_session_doc')]


class Change(models.Model):
    id = models.BigAutoField(primary_key=True)
    coll = models.CharField(max_length=20)
    key = models.CharField(max_length=120)
    action = models.CharField(max_length=8)   # put / delete
    at = models.DateTimeField(auto_now_add=True)


# ------------------------------------------------------------------ proper tables (one set per academic session)
class Person(models.Model):
    """The child's / family's details - ONE copy per admission number, shared by every academic session (see person.py)."""
    adm_no = models.CharField(max_length=20, unique=True)
    data = models.JSONField(default=dict)
    version = models.PositiveIntegerField(default=1)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.adm_no


class Student(models.Model):
    """One row per (session, admission no): the session's own part in `sdata`; the personal part lives in Person. `data` (property) is the full admission
    form the UI works with. Real columns hold what reports/searches need."""
    session = models.CharField(max_length=20)
    adm_no = models.CharField(max_length=20)
    reg_no = models.CharField(max_length=40, blank=True)
    first_name = models.CharField(max_length=120, blank=True)
    middle_name = models.CharField(max_length=120, blank=True)
    last_name = models.CharField(max_length=120, blank=True)
    gender = models.CharField(max_length=12, blank=True)
    dob = models.CharField(max_length=12, blank=True)
    father = models.CharField(max_length=120, blank=True)
    mother = models.CharField(max_length=120, blank=True)
    mobile = models.CharField(max_length=30, blank=True)
    cls = models.CharField(max_length=40, blank=True)
    sec = models.CharField(max_length=10, blank=True)
    roll = models.PositiveIntegerField(null=True, blank=True)
    category = models.CharField(max_length=40, blank=True)
    left = models.BooleanField(default=False)
    sdata = models.JSONField(default=dict)
    version = models.PositiveIntegerField(default=1)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        constraints = [models.UniqueConstraint(fields=['session', 'adm_no'], name='uniq_student_per_session')]
        indexes = [models.Index(fields=['session', 'cls', 'sec'])]

    def __str__(self):
        return f'{self.adm_no} {self.first_name} {self.last_name}'.strip()

    # ---- the full admission record (personal + session part)
    def _personal(self):
        pd = getattr(self, '_pd', None)
        if pd is None:
            row = Person.objects.filter(adm_no=self.adm_no).values_list('data', flat=True).first()
            pd = self._pd = row or {}
        return pd

    @property
    def data(self):
        m = getattr(self, '_merged', None)
        if m is None:
            from . import person
            m = self._merged = person.merge(self._personal(), self.sdata or {})
        return m

    @data.setter
    def data(self, rec):
        from . import person
        p, s = person.split(rec)
        self.sdata, self._pd, self._pending_person, self._merged = s, p, p, None

    touched = ()          # sessions whose rows changed because the personal part changed (the view announces them to the other browsers)

    def save(self, *a, **k):
        if k.get('update_fields'):
            k['update_fields'] = ['sdata' if f == 'data' else f for f in k['update_fields']]
        pend = getattr(self, '_pending_person', None)
        super().save(*a, **k)
        self.touched = ()
        if pend is not None:
            self._pending_person = None
            self.touched = self._store_person(pend)

    def _store_person(self, personal):
        from django.db.models import F
        from . import person, store
        p = Person.objects.filter(adm_no=self.adm_no).first()
        if p is None:
            Person.objects.create(adm_no=self.adm_no, data=personal)
            return ()
        if p.data == personal:
            return ()
        p.data, p.version = personal, p.version + 1
        p.save()
        out = []
        for o in Student.objects.filter(adm_no=self.adm_no).exclude(pk=self.pk):      # names / mother / mobile columns of the other sessions follow
            cols = store.student_fields(person.merge(personal, o.sdata))
            cols.pop('data')
            Student.objects.filter(pk=o.pk).update(version=F('version') + 1, **cols)
            out.append(o.session)
        return tuple(out)


def drop_orphan_person(adm_no):
    """After a student row was deleted: the personal copy goes when no session uses it any more."""
    if not Student.objects.filter(adm_no=adm_no).exists():
        Person.objects.filter(adm_no=adm_no).delete()


class GatePass(models.Model):
    session = models.CharField(max_length=20)
    pass_id = models.CharField(max_length=40)
    adm_no = models.CharField(max_length=20, db_index=True)
    date = models.CharField(max_length=12, blank=True)
    time = models.CharField(max_length=12, blank=True)
    name = models.CharField(max_length=120, blank=True)
    cls = models.CharField(max_length=40, blank=True)
    taken_by = models.CharField(max_length=120, blank=True)
    reason = models.CharField(max_length=255, blank=True)
    seq = models.PositiveIntegerField(default=0)
    data = models.JSONField()

    class Meta:
        constraints = [models.UniqueConstraint(fields=['session', 'pass_id'], name='uniq_gatepass_per_session')]


class RefEntry(models.Model):
    """Reference register entry (certificates / letters issued)."""
    session = models.CharField(max_length=20)
    entry_id = models.CharField(max_length=60)
    refno = models.CharField(max_length=60, blank=True)
    date = models.CharField(max_length=12, blank=True)
    adm_no = models.CharField(max_length=20, blank=True, db_index=True)
    category = models.CharField(max_length=60, blank=True)
    status = models.CharField(max_length=30, blank=True)
    seq = models.PositiveIntegerField(default=0)
    data = models.JSONField()

    class Meta:
        constraints = [models.UniqueConstraint(fields=['session', 'entry_id'], name='uniq_refentry_per_session')]


class AttendanceMark(models.Model):
    """One row per student per class-day: P / A / L."""
    session = models.CharField(max_length=20)
    date = models.CharField(max_length=12)
    cls = models.CharField(max_length=40)
    sec = models.CharField(max_length=10, blank=True)
    adm_no = models.CharField(max_length=20)
    status = models.CharField(max_length=10)

    class Meta:
        constraints = [models.UniqueConstraint(fields=['session', 'date', 'cls', 'sec', 'adm_no'], name='uniq_attendance_mark')]
        indexes = [models.Index(fields=['session', 'adm_no'])]


class Mark(models.Model):
    """Exam marks: one row per student, term, assessment and subject."""
    session = models.CharField(max_length=20)
    term_id = models.CharField(max_length=40)
    assess = models.CharField(max_length=40)
    adm_no = models.CharField(max_length=20)
    subject = models.CharField(max_length=80)
    value = models.JSONField(null=True)

    class Meta:
        constraints = [models.UniqueConstraint(fields=['session', 'term_id', 'assess', 'adm_no', 'subject'], name='uniq_mark')]
        indexes = [models.Index(fields=['session', 'adm_no'])]


class CoGrade(models.Model):
    """Co-scholastic grades."""
    session = models.CharField(max_length=20)
    term_id = models.CharField(max_length=40)
    area_id = models.CharField(max_length=60)
    adm_no = models.CharField(max_length=20)
    grade = models.CharField(max_length=20, blank=True)

    class Meta:
        constraints = [models.UniqueConstraint(fields=['session', 'term_id', 'area_id', 'adm_no'], name='uniq_cograde')]


class SavedDoc(models.Model):
    """Exact copy of every printed certificate (kept here, on the server, so every PC sees the same archive and backups contain it)."""
    doc_id = models.CharField(max_length=60, unique=True)
    at = models.BigIntegerField(default=0)
    signed = models.BooleanField(default=False)
    data = models.JSONField()
    updated_at = models.DateTimeField(auto_now=True)


class DocAsset(models.Model):
    """Big images (logos) used inside the saved certificates, stored once."""
    key = models.CharField(max_length=80, unique=True)
    value = models.TextField()
