"""Photos and documents are stored directly in the media folder (data/media/<name>.jpg).
Older versions put them in data/media/f/. This module moves such files up and rewrites the saved links, and keeps old links working."""
import base64
import hashlib
import json
import re
import shutil
from pathlib import Path

from django.conf import settings

from .models import Doc, GatePass, RefEntry, Student

OLD = '/media/f/'
NEW = '/media/'
EXTS = ('jpg', 'png', 'webp', 'gif', 'pdf')


def fix_text(text):
    return text.replace(OLD, NEW) if isinstance(text, str) and OLD in text else text


def fix_obj(obj):
    """Same for a stored record (dict/list)."""
    s = json.dumps(obj, ensure_ascii=False)
    return json.loads(s.replace(OLD, NEW)) if OLD in s else obj


def move_files():
    """media/f/<file>  ->  media/<file>. Returns how many files were moved."""
    root, old = Path(settings.MEDIA_ROOT), Path(settings.MEDIA_ROOT) / 'f'
    moved = 0
    if not old.is_dir():
        return 0
    for f in list(old.iterdir()):
        if not f.is_file():
            continue
        dest = root / f.name
        if dest.exists():
            if dest.stat().st_size == f.stat().st_size:      # same name = same content (names are made from the content)
                f.unlink()
                moved += 1
            continue
        shutil.move(str(f), str(dest))
        moved += 1
    try:
        old.rmdir()
    except OSError:
        pass
    return moved


def fix_links():
    """Rewrite /media/f/ links in everything that is stored. Returns the number of records changed."""
    n = 0
    for d in Doc.objects.all():
        new = fix_obj(d.data) if not isinstance(d.data, str) else fix_text(d.data)
        if new != d.data:
            d.data = new
            d.save(update_fields=['data'])
            n += 1
    for model in (Student, GatePass, RefEntry):
        for r in model.objects.all().iterator(chunk_size=500):
            new = fix_obj(r.data)
            if new != r.data:
                r.data = new
                r.save(update_fields=['data'])
                n += 1
    return n


DATA_RE = re.compile(r'data:(image/(?:jpeg|png|webp|gif)|application/pdf);base64,([A-Za-z0-9+/=]{1500,})')
EXT_OF = {'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp', 'image/gif': 'gif', 'application/pdf': 'pdf'}


def offload(obj):
    """Photos / PDFs embedded as data: text inside a record become files in the media folder (the record keeps the short link)."""
    s = json.dumps(obj, ensure_ascii=False)
    if 'data:' not in s:
        return obj
    root = Path(settings.MEDIA_ROOT)

    def sub(mt):
        raw = base64.b64decode(mt.group(2))
        name = hashlib.sha256(raw).hexdigest()[:32] + '.' + EXT_OF[mt.group(1)]
        root.mkdir(parents=True, exist_ok=True)
        if not (root / name).exists():
            (root / name).write_bytes(raw)
        return NEW + name
    new = DATA_RE.sub(sub, s)
    return json.loads(new) if new != s else obj
