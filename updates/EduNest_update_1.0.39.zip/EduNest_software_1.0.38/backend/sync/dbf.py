"""Tiny reader for dBase / FoxPro .DBF files (no extra program needed). Deleted rows are skipped; memo (.FPT) fields are ignored."""
import struct
from datetime import date


def read_dbf(path, encoding='cp1252'):
    """-> list of dicts (field name -> value). Text is stripped, dates are datetime.date, numbers int/float, empty numbers None."""
    with open(path, 'rb') as f:
        raw = f.read()
    n, hlen, rlen = struct.unpack('<IHH', raw[4:12])
    fields, pos = [], 32
    while pos < hlen - 1 and raw[pos] != 0x0D:
        d = raw[pos:pos + 32]
        fields.append((d[:11].split(b'\0')[0].decode('ascii', 'ignore'), chr(d[11]), d[16], d[17]))
        pos += 32
    rows = []
    for i in range(n):
        rec = raw[hlen + i * rlen: hlen + (i + 1) * rlen]
        if len(rec) < rlen or rec[:1] == b'*':
            continue
        out, off = {}, 1
        for name, typ, ln, dec in fields:
            b = rec[off:off + ln]
            off += ln
            if typ in 'CV':
                v = b.decode(encoding, 'replace').replace('\x00', '').strip()
            elif typ in 'NF':
                s = b.decode('ascii', 'ignore').strip()
                try:
                    v = None if not s else (float(s) if ('.' in s or dec) else int(s))
                except ValueError:
                    v = None
            elif typ == 'D':
                s = b.decode('ascii', 'ignore').strip()
                try:
                    v = date(int(s[:4]), int(s[4:6]), int(s[6:8])) if len(s) == 8 and s.isdigit() else None
                except ValueError:
                    v = None
            elif typ == 'L':
                v = b.decode('ascii', 'ignore').strip().upper() in ('T', 'Y')
            elif typ == 'I':
                v = struct.unpack('<i', b)[0] if len(b) == 4 else None
            else:
                v = None
            out[name] = v
        rows.append(out)
    return rows
