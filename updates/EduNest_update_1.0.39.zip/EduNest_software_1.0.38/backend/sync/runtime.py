"""Starts and stops the cloud sync workers while the server is running (Cloud Connections: Save starts / restarts a group at once,
Disconnect stops it at once, no server restart needed). serve.py starts every configured group at boot through start_all()."""
import logging
import threading
import time

from . import cloud_att, cloud_fee, cloud_gp, cloud_result, cloud_roll, contacts_sync

log = logging.getLogger('runtime')
MODULES = {'gate': cloud_gp, 'result': cloud_result, 'fee': cloud_fee, 'att': cloud_att, 'roll': cloud_roll, 'contacts': contacts_sync}
NAMES = {'gate': 'Gate Pass', 'result': 'Result portal', 'fee': 'Online fee', 'att': 'Biometric attendance', 'roll': 'Class roll call', 'contacts': 'Google Contacts'}
_lock = threading.Lock()
_running = {}                       # group id -> (thread, stop event)


def is_running(gid):
    with _lock:
        t = _running.get(gid)
        return bool(t and t[0].is_alive() and not t[1].is_set())


def status():
    return {gid: is_running(gid) for gid in MODULES}


def stop(gid):
    """Stop a group's worker (it finishes the step it is in, then ends)."""
    with _lock:
        t = _running.pop(gid, None)
    if not t:
        return False
    t[1].set()
    wake = getattr(MODULES[gid], 'WAKE', None)
    if wake:
        wake.set()                  # wakes it from its sleep so it notices at once
    log.info('%s cloud sync stopped', NAMES[gid])
    return True


def start(gid):
    """(Re)start a group with the settings now in the environment. Returns True when it is running (False: not set up)."""
    stop(gid)
    mod = MODULES[gid]
    if not mod.config():
        return False
    ev = threading.Event()
    t = threading.Thread(target=mod.loop, args=(ev,), name=f'cloud-{gid}', daemon=True)
    with _lock:
        _running[gid] = (t, ev)
    t.start()
    log.info('%s cloud sync started', NAMES[gid])
    return True


def stop_all():
    for gid in list(MODULES):
        stop(gid)


def start_all():
    """At server start: every group that is set up in config.env. Logs one line per group."""
    out = {}
    for gid in MODULES:
        out[gid] = start(gid)
        if not out[gid]:
            log.info('%s cloud sync is OFF (not set up; see Setup > Cloud Connections, or ERP.bat option 5)', NAMES[gid])
    return out


_fetch = {}                         # group id -> {'state': running / done / error, 'text': ..., 'at': time}


def fetch_all(gid):
    """FORCE FETCH of a group, in the background: everything the cloud has (also what came while it was not connected). Returns False when not set up."""
    mod = MODULES.get(gid)
    if mod is None or not mod.config():
        return False
    with _lock:
        if _fetch.get(gid, {}).get('state') == 'running':
            return True
        _fetch[gid] = {'state': 'running', 'text': 'Fetching ...', 'at': time.time()}

    def work():
        from django.db import connection
        try:
            res = mod.fetch_all() or {}
            text = ' | '.join(f'{k}: {v}' for k, v in res.items())
            _fetch[gid] = {'state': 'done', 'text': text or 'Done.', 'at': time.time()}
            log.info('%s force fetch: %s', NAMES[gid], text)
        except Exception as e:
            _fetch[gid] = {'state': 'error', 'text': str(e)[:300], 'at': time.time()}
            log.warning('%s force fetch failed: %s', NAMES[gid], e)
        finally:
            connection.close()
    threading.Thread(target=work, name=f'fetch-{gid}', daemon=True).start()
    return True


def fetch_status():
    return dict(_fetch)
