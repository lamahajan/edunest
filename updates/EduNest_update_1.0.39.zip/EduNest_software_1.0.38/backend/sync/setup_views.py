"""API of the Cloud Setup page (administrators only)."""
from rest_framework.decorators import api_view
from rest_framework.response import Response

from . import cloud_setup, runtime
from .views import need

ADMIN = [('adminZone', 'edit')]


def _apply(before):
    """After a change: start (or restart) every app that is now set up, stop every app that no longer is. No server restart needed."""
    env = cloud_setup.read_env()
    for g in cloud_setup.GROUPS:
        keys = [f['key'] for f in g['fields']]
        if all(env.get(k) for k in g['need']):
            if any(env.get(k, '') != before.get(k, '') for k in keys) or not runtime.is_running(g['id']):
                runtime.start(g['id'])
        else:
            runtime.stop(g['id'])


@api_view(['GET', 'POST'])
def cloud_setup_view(request):
    need(request, ADMIN)
    if request.method == 'POST':
        values = request.data.get('values') or {}
        before = cloud_setup.read_env()
        bad = cloud_setup.save(values if isinstance(values, dict) else {}, request.data.get('clear') or [])
        if bad:
            return Response({'ok': False, 'errors': bad}, status=400)
        _apply(before)
    return Response({'groups': cloud_setup.view()})


@api_view(['POST'])
def cloud_setup_disconnect(request):
    need(request, ADMIN)
    gid = str(request.data.get('group') or '')
    before = cloud_setup.read_env()
    if not cloud_setup.disconnect(gid):
        return Response({'ok': False, 'error': 'unknown group'}, status=400)
    runtime.stop(gid)
    _apply(before)
    return Response({'ok': True, 'groups': cloud_setup.view()})


@api_view(['POST'])
def cloud_setup_test(request):
    need(request, ADMIN)
    values = request.data.get('values')
    res = cloud_setup.test_group(str(request.data.get('group') or ''), values if isinstance(values, dict) else {})
    return Response({'ok': all(o for o, _ in res), 'results': [{'ok': o, 'message': m} for o, m in res]})


@api_view(['GET', 'POST'])
def cloud_setup_fetch(request):
    """POST {group}: force fetch (everything the cloud has) in the background. GET: how each fetch is going."""
    need(request, ADMIN)
    if request.method == 'POST':
        gid = str(request.data.get('group') or '')
        if gid not in runtime.MODULES:
            return Response({'ok': False, 'error': 'unknown group'}, status=400)
        if not runtime.fetch_all(gid):
            return Response({'ok': False, 'error': 'Not set up yet: fill in and Save the connection first.'}, status=400)
    return Response({'ok': True, 'fetch': runtime.fetch_status()})
