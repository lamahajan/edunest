"""Asking the running school server to restart or stop itself (no killing of processes, no administrator rights).

The server (serve.py) checks for this every second. A request is either made inside the server (the Restart button in the ERP) or by a small file
in the data folder (ERP.bat / tools/erpctl.py). run_server.bat starts serve.py again when it ends with RESTART_CODE."""
import threading

from django.conf import settings

RESTART_CODE = 75
_event = {'restart': threading.Event(), 'stop': threading.Event()}


def flag(kind):
    return settings.DATA_DIR / f'{kind}.request'


def request(kind):
    """kind: 'restart' | 'stop'."""
    if kind not in _event:
        raise ValueError(kind)
    _event[kind].set()
    try:
        flag(kind).write_text('1')
    except OSError:
        pass


def clear():
    for kind, ev in _event.items():
        ev.clear()
        try:
            flag(kind).unlink(missing_ok=True)
        except OSError:
            pass


def pending():
    """'restart', 'stop' or None. A stop wins over a restart."""
    for kind in ('stop', 'restart'):
        if _event[kind].is_set() or flag(kind).exists():
            return kind
    return None
