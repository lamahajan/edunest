"""Tiny in-process event hub: views.note() tells it what changed in the ERP (after the change is really saved), and the cloud sync
workers subscribe so they react at once instead of checking on a timer."""
import logging

log = logging.getLogger('events')
subs = {}


def on(coll, fn):
    if fn not in subs.setdefault(coll, []):
        subs[coll].append(fn)


def fire(coll, key):
    for fn in list(subs.get(coll, [])):
        try:
            fn(str(key))
        except Exception:                  # a broken subscriber must never break saving
            log.exception('event handler failed')
