"""Uploaded photos / documents get a readable name in the media folder:  22012_student.jpg, 22012_father.jpg, 22012_birth-certificate.pdf,
principal_sign.png, school_seal.png ...  The browser first stores a file under a content-hash name (safe, no duplicates); as soon as the
record that uses it is saved, the file is renamed here and the record's link is rewritten. Hash-named files nobody uses any more are removed."""
import json
import os
import re
import shutil
import threading
from pathlib import Path

from django.conf import settings
from django.db.models import TextField
from django.db.models.functions import Cast

from .models import Doc, GatePass, Person, RefEntry, Student

HASH = re.compile(r'/media/([0-9a-z]{16,64})\.(jpg|png|webp|gif|pdf)')
OLDTYPES = 'student_pics|father_pics|mother_pics|guardian_pics|documents'
SESSDIR = re.compile(r'\d{4}-\d{2,4}')
FLAT = re.compile(r'/media/((?:[^/\s"\']+/(?:' + OLDTYPES + r')/|\d{4}-\d{2,4}/[^/\s"\']+/)?[^/\s"\']+)\.(jpg|png|webp|gif|pdf)')   # a file directly in media/ (hash or readable name) or in an earlier layout (<session>/<type>/, <session>/<adm>/) - NOT one already in students/<adm>/
PHOTO = {'ward': 'student', 'father': 'father', 'mother': 'mother', 'guardian': 'guardian'}
ADM_DOCS = ['birth-certificate', 'aadhaar-student', 'aadhaar-father', 'aadhaar-mother', 'transfer-certificate', 'previous-report-card',
            'passport-photos', 'address-proof', 'caste-certificate', 'ews-certificate', 'medical-certificate', 'apaar-id', 'sibling-proof']
SCHOOL_KEY = 'eacademics_school'
SCHOOL_IMGS = {'logo': 'school_logo', 'logoName': 'school_logo_with_name', 'signImg': 'authorised_sign', 'prinSign': 'principal_sign', 'seal': 'school_seal', 'rscBg': 'report_card_background'}


def _root():
    return Path(settings.MEDIA_ROOT)


# ---- old links keep working: when a hash-named upload is renamed (70001_student.jpg), remember  <hash>.<ext> -> <new name>, so a browser that still holds the
# old link (a form printed straight after saving, a second PC that has not refreshed yet) does not show a broken-picture sign.
_ALIAS_LOCK = threading.Lock()
_ALIAS_CACHE = {'mtime': None, 'map': {}}


def _alias_path():
    return Path(settings.DATA_DIR) / 'media_aliases.json'


def _alias_map():
    p = _alias_path()
    try:
        m = p.stat().st_mtime
    except OSError:
        return {}
    if _ALIAS_CACHE['mtime'] != m:
        try:
            _ALIAS_CACHE.update(mtime=m, map=json.loads(p.read_text(encoding='utf-8')) or {})
        except (OSError, ValueError):
            _ALIAS_CACHE.update(mtime=m, map={})
    return _ALIAS_CACHE['map']


def _alias_add(old_name, new_name):
    if old_name == new_name:
        return
    with _ALIAS_LOCK:
        mp = dict(_alias_map())
        if mp.get(old_name) == new_name:
            return
        mp[old_name] = new_name
        p = _alias_path()
        tmp = p.with_name(p.name + '.tmp')
        tmp.write_text(json.dumps(mp), encoding='utf-8')
        os.replace(tmp, p)


def alias_of(name):
    """/media/<name> no longer exists: the file name it was renamed to (still existing), or None."""
    mp, root, cur = _alias_map(), _root(), name.lstrip('/')
    if cur.startswith('f/'):
        cur = cur[2:]
    for _ in range(6):
        nxt = mp.get(cur)
        if not nxt:
            return None
        if (root / nxt).is_file():
            return nxt
        cur = nxt
    return None


def _find(h, ext):
    r = _root()
    return next((c for c in (r / f'{h}.{ext}', r / 'f' / f'{h}.{ext}') if c.is_file()), None)


def _referenced(url, skip_student=None, skip_doc=None):
    """Does any stored record still use this file link? (skip_student = (session, adm) being rewritten right now)"""
    for model, fld in ((Student, 'sdata'), (Person, 'data'), (Doc, 'data'), (GatePass, 'data'), (RefEntry, 'data')):
        qs = model.objects.annotate(_t=Cast(fld, TextField())).filter(_t__contains=url)
        if model is Student and skip_student:
            qs = qs.exclude(session=skip_student[0], adm_no=skip_student[1])
        if model is Person and skip_student:
            qs = qs.exclude(adm_no=skip_student[1])
        if model is Doc and skip_doc:
            qs = qs.exclude(coll='kv', key=skip_doc)
        if qs.exists():
            return True
    return False


def _same(a, b):
    return a.stat().st_size == b.stat().st_size and a.read_bytes() == b.read_bytes()


def _rename(h, ext, base, claimed, skip_student, skip_doc=None):
    """Give file <h>.<ext> the name <base>.<ext>. Returns the new link, or None when the file is not there yet."""
    src = _find(h, ext)
    if src is None:
        old = alias_of(f'{h}.{ext}')                   # renamed earlier (this record still has the old link): point it to the new file
        if old:
            return f'/media/{old}'
        if (_root() / f'{base}.{ext}').is_file():      # the readable name this file would get is already there
            return f'/media/{base}.{ext}'
        return None
    root, i = _root(), 1
    while True:
        name = base if i == 1 else f'{base}_{i}'
        dst, url = root / f'{name}.{ext}', f'/media/{name}.{ext}'
        if name in claimed:
            i += 1
            continue
        if not dst.exists() or _same(src, dst) or not _referenced(url, skip_student, skip_doc):
            break
        i += 1
    claimed.add(name)
    _alias_add(f'{h}.{ext}', f'{name}.{ext}')
    old_url = f'/media/{h}.{ext}'
    still_used = _referenced(old_url, skip_student, skip_doc)          # another record (e.g. a gate pass) may still point at the hash name
    if not (dst.exists() and _same(src, dst)):
        dst.parent.mkdir(parents=True, exist_ok=True)
        tmp = dst.with_name(dst.name + '.part')
        shutil.copy2(src, tmp)
        os.replace(tmp, dst)
    if not still_used:
        try:
            src.unlink()
        except OSError:
            pass
    return url


def _walk(node, path, fn, rx=HASH):
    if isinstance(node, str):
        return rx.sub(lambda m: fn(path, m) or m.group(0), node)
    if isinstance(node, dict):
        return {k: _walk(v, path + (str(k),), fn, rx) for k, v in node.items()}
    if isinstance(node, list):
        return [_walk(v, path + (str(i),), fn, rx) for i, v in enumerate(node)]
    return node


def _slug(s):
    return re.sub(r'[^0-9A-Za-z._-]+', '-', str(s)).strip('-.') or 'student'


def _label(path):
    p = list(path)
    if p[:1] == ['photos'] and len(p) >= 2 and p[1] in PHOTO:
        return PHOTO[p[1]]
    if p[:1] == ['docFiles'] and len(p) >= 2 and p[1].isdigit() and int(p[1]) < len(ADM_DOCS):
        return ADM_DOCS[int(p[1])]
    if p[:2] == ['prev', 'tcFile']:
        return 'transfer-certificate'
    return None


def rename_record(rec, session, adm):
    """Admission record -> same record with readable file links, one folder per student:
    media/students/<adm no>/<adm>_student.jpg, <adm>_father.jpg, <adm>_mother.jpg, <adm>_birth-certificate.pdf ...
    (files are moved on disk; files still directly in media/ or in an earlier layout are moved the first time). Returns the record (same object if nothing changed)."""
    if not isinstance(rec, dict):
        return rec
    claimed = set()

    def fn(path, m):
        lab = _label(path)
        if not lab:
            return None
        base = f'students/{_slug(adm)}/{_slug(adm)}_{lab}'
        return _rename(m.group(1), m.group(2), base, claimed, (session, adm))
    return _walk(rec, (), fn, FLAT)


def rename_school(text):
    """School settings (JSON text): logo / signatures / seal."""
    try:
        obj = json.loads(text)
    except (TypeError, ValueError):
        return text
    if not isinstance(obj, dict):
        return text
    claimed, out = set(), dict(obj)
    for k, lab in SCHOOL_IMGS.items():
        v = obj.get(k)
        m = HASH.fullmatch(v) if isinstance(v, str) else None
        if m:
            new = _rename(m.group(1), m.group(2), lab, claimed, None, SCHOOL_KEY)
            if new:
                out[k] = new
    return json.dumps(out) if out != obj else text


def after_upload(name, ext, note, store, lock):
    """A file has just arrived: if a saved record already uses it, rename it now. Never raises."""
    from django.db import transaction
    url = f'/media/{name}.{ext}'
    try:
        adms = set(Student.objects.annotate(_t=Cast('sdata', TextField())).filter(_t__contains=url).values_list('adm_no', flat=True))
        adms |= set(Person.objects.annotate(_t=Cast('data', TextField())).filter(_t__contains=url).values_list('adm_no', flat=True))
        for st in Student.objects.filter(adm_no__in=adms):
            with transaction.atomic():
                lock(f'adm:{st.session}|{st.adm_no}')
                cur = Student.objects.select_for_update().filter(pk=st.pk).first()
                new = rename_record(cur.data, cur.session, cur.adm_no) if cur else None
                if cur and new != cur.data:
                    for k, v in store.student_fields(new).items():
                        setattr(cur, k, v)
                    cur.version += 1
                    cur.save()
                    note('adm', f'{cur.session}|{cur.adm_no}')
        d = Doc.objects.filter(coll='kv', key=SCHOOL_KEY).first()
        if d is not None and url in str(d.data):
            with transaction.atomic():
                lock(f'kv:{SCHOOL_KEY}')
                d = Doc.objects.select_for_update().filter(coll='kv', key=SCHOOL_KEY).first()
                cur = store.load(SCHOOL_KEY, d.data)
                new = rename_school(cur)
                if new != cur:
                    d.data, d.version = store.store(SCHOOL_KEY, new), d.version + 1
                    d.save()
                    note('kv', SCHOOL_KEY)
    except Exception:
        pass


def _tidy():
    """Earlier layouts: remove the empty <session>/... folders and move media/pdf/<year>/ to media/certificates/<year>/."""
    root = _root()
    for sd in root.glob('*'):
        if sd.is_dir() and SESSDIR.fullmatch(sd.name):
            for d in sorted((x for x in sd.rglob('*') if x.is_dir()), key=lambda x: len(x.parts), reverse=True) + [sd]:
                try:
                    d.rmdir()
                except OSError:
                    pass
    old = root / 'pdf'
    if old.is_dir():
        for f in [x for x in old.rglob('*') if x.is_file()]:
            dst = root / 'certificates' / f.relative_to(old)
            dst.parent.mkdir(parents=True, exist_ok=True)
            if not dst.exists():
                shutil.move(str(f), str(dst))
            elif f.stat().st_size == dst.stat().st_size:
                f.unlink()
        for d in sorted((x for x in old.rglob('*') if x.is_dir()), key=lambda x: len(x.parts), reverse=True) + [old]:
            try:
                d.rmdir()
            except OSError:
                pass


def rename_all():
    """All existing records (update / manual run). Returns (students changed, school settings changed)."""
    from . import store
    n = 0
    for st in Student.objects.all().order_by('session', 'adm_no'):
        new = rename_record(st.data, st.session, st.adm_no)
        if new != st.data:
            for k, v in store.student_fields(new).items():
                setattr(st, k, v)
            st.version += 1
            st.save()
            n += 1
    _tidy()
    s = 0
    d = Doc.objects.filter(coll='kv', key=SCHOOL_KEY).first()
    if d is not None:
        cur = store.load(SCHOOL_KEY, d.data)
        new = rename_school(cur)
        if new != cur:
            d.data, d.version = store.store(SCHOOL_KEY, new), d.version + 1
            d.save()
            s = 1
    return n, s
