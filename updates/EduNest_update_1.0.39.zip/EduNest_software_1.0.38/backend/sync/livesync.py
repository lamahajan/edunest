"""Event-driven plumbing for the cloud sync workers.

  Waker       a flag a worker sleeps on. Anything that matters (a change in the ERP, a change pushed by Firebase) sets it.
  stream()    keeps one Firebase node open (optionally handing every changed record to a callback) as a live stream (the same server-sent-events stream eGateSys / Reception Suite use) and
              sets the Waker the moment anything in that node changes, plus once after every (re)connect so nothing is missed.
  run_loop()  work once, sleep until woken, work again. A long safety timer (default 5 minutes) only covers a stream that silently died.
"""
import json
import logging
import threading
import time
import urllib.request

log = logging.getLogger('livesync')


class Waker:
    def __init__(self):
        self.ev = threading.Event()

    def set(self, *_):
        self.ev.set()


def run_loop(name, wake, work, safety_secs=300, stop=None, settle=0.4, gap=1.0):
    """work() runs at start and after every wake. `settle` lets a burst of changes finish first; `gap` is the minimum time between runs."""
    quiet = False
    while not (stop and stop.is_set()):
        try:
            work()
            quiet = False
        except Exception as e:                 # no internet / cloud down: keep trying, the ERP itself keeps working
            if not quiet:
                log.warning('%s waiting (%s)', name, e)
            quiet = True
            wake.ev.wait(timeout=15)           # retry soon, but not in a tight loop
        else:
            wake.ev.wait(timeout=safety_secs)
        time.sleep(settle)
        wake.ev.clear()
        time.sleep(gap)


def stream(url, wake, stop=None, read_timeout=75, backoff0=3, on_data=None, until=None):
    """Hold `url` (a Firebase REST path, .json) open as an event stream. Firebase sends a keep-alive every ~30 s, so 75 s of silence = dead link."""
    backoff = backoff0
    while not (stop and stop.is_set()):
        try:
            req = urllib.request.Request(url, headers={'Accept': 'text/event-stream'})
            with urllib.request.urlopen(req, timeout=read_timeout) as r:
                backoff = backoff0
                wake.set()                     # (re)connected: look at everything once
                event = None
                for raw in r:
                    line = raw.decode('utf-8', 'replace').rstrip('\r\n')
                    if line.startswith('event:'):
                        event = line[6:].strip()
                    elif line.startswith('data:'):
                        if event in ('put', 'patch'):
                            if on_data:
                                try:
                                    d = json.loads(line[5:]) or {}
                                    on_data(d.get('path') or '/', d.get('data'))
                                except Exception:
                                    log.debug('stream data not understood')
                            wake.set()
                        elif event in ('cancel', 'auth_revoked'):
                            break
                    if (stop and stop.is_set()) or (until and until()):
                        return
        except Exception as e:
            log.debug('stream %s dropped (%s)', url.split('?')[0], e)
        if stop and stop.is_set():
            return
        time.sleep(backoff)
        backoff = min(backoff * 2, 60)


def start_streams(fb, paths, wake, stop=None):
    """One daemon thread per Firebase node (fb is a cloud_gp.Firebase)."""
    out = []
    for p in paths:
        t = threading.Thread(target=stream, args=(fb._url(p), wake, stop), name=f'stream-{p or "root"}', daemon=True)
        t.start()
        out.append(t)
    return out
