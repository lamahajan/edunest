"""API used by static/erp-fee-sync.js (due snapshot from the browser, payment queue, closing a payment)."""
from rest_framework.response import Response
from rest_framework.decorators import api_view

from . import cloud_fee
from .views import need

FEE = [('feeReceipt', 'add')]


@api_view(['POST'])
def fee_dues(request):
    need(request, FEE)
    d = request.data
    return Response({'changed': cloud_fee.save_snapshot(str(d.get('session') or ''), str(d.get('asOn') or ''), d.get('dues') or {}, d.get('total')), 'on': bool(cloud_fee.config())})


@api_view(['GET'])
def fee_txns(request):
    need(request, FEE)
    return Response({'on': bool(cloud_fee.config()), 'items': cloud_fee.queue()})


@api_view(['POST'])
def fee_txn_action(request, key, action):
    need(request, FEE)
    cfg = cloud_fee.config()
    if not cfg or not cfg['txn'] or key not in cloud_fee.queue():
        return Response({'error': 'unknown payment'}, status=404)
    if action == 'claim':
        return Response({'ok': True}) if cloud_fee.claim(key) else Response({'error': 'busy'}, status=409)
    b = cloud_fee.Bridge(cfg)
    if action == 'done':
        b.mark_done(key, request.data.get('voucher'))
    elif action == 'review':
        b.mark_review(key, request.data.get('reason') or 'marked for review in ERP')
    else:
        return Response({'error': 'bad action'}, status=400)
    b.poll_payments()
    return Response({'ok': True})
