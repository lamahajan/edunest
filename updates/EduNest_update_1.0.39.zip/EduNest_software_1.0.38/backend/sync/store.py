"""Maps the app's saved documents onto proper database tables (and back), so reports and a future mobile app can query real
tables while the existing screens keep working unchanged. A document that does not have the expected shape is kept as-is."""
import json
import re

from django.db import transaction

from .models import AttendanceMark, CoGrade, GatePass, Mark, RefEntry, Student

TAB = 'TAB:'                    # Doc.data prefix: "content is in the tables; the rest of this text is the leftover configuration"
BASE = '2026-2027'
KEY_RE = re.compile(r'^eacademics_(?:s(\d{4}-\d{4})_)?(.+)$')
dumps = lambda x: json.dumps(x, ensure_ascii=False, separators=(',', ':'))


def _s(v, n):
    return ('' if v is None else str(v))[:n]


def sync_rows(model, session, want, keyf, fields):
    """Make the table rows of one session equal `want` ({key tuple: {field: value}}), writing only what changed."""
    n = len(keyf)
    have = {}
    for row in model.objects.filter(session=session).values_list('pk', *keyf, *fields):
        have[tuple(row[1:1 + n])] = (row[0], tuple(row[1 + n:]))
    create, update = [], []
    for k, vals in want.items():
        if k not in have:
            create.append(model(session=session, **dict(zip(keyf, k)), **vals))
        elif have[k][1] != tuple(vals[f] for f in fields):
            update.append(model(pk=have[k][0], session=session, **dict(zip(keyf, k)), **vals))
    gone = [pk for k, (pk, _) in have.items() if k not in want]
    for i in range(0, len(gone), 500):
        model.objects.filter(pk__in=gone[i:i + 500]).delete()
    model.objects.bulk_create(create, batch_size=500)
    if update:
        model.objects.bulk_update(update, list(fields), batch_size=500)


def _obj(text):
    v = json.loads(text)
    if not isinstance(v, dict):
        raise ValueError('object expected')
    return v


def _arr_with_ids(text):
    arr = json.loads(text)
    if not isinstance(arr, list):
        raise ValueError('list expected')
    seen = set()
    for x in arr:
        if not isinstance(x, dict) or not isinstance(x.get('id'), str) or not x['id'] or x['id'] in seen:
            raise ValueError('records with unique id expected')
        seen.add(x['id'])
    return arr


# ---------------------------------------------------------------- codecs: explode(text) -> (leftover text, [(model, session-independent rows, keyf, fields)])
GP_F = ['adm_no', 'date', 'time', 'name', 'cls', 'taken_by', 'reason', 'seq', 'data']


def gp_explode(text):
    arr = _arr_with_ids(text)
    want = {(x['id'],): dict(adm_no=_s(x.get('adm'), 20), date=_s(x.get('date'), 12), time=_s(x.get('time'), 12), name=_s(x.get('name'), 120),
                             cls=_s(x.get('cls'), 40), taken_by=_s(x.get('takenBy'), 120), reason=_s(x.get('reason'), 255), seq=i, data=x)
            for i, x in enumerate(arr)}
    return '', [(GatePass, want, ['pass_id'], GP_F)]


def gp_implode(session, cfg):
    return dumps([r.data for r in GatePass.objects.filter(session=session).order_by('seq')])


RR_F = ['refno', 'date', 'adm_no', 'category', 'status', 'seq', 'data']


def rr_explode(text):
    obj = _obj(text)
    ents = obj.pop('entries', [])
    if not isinstance(ents, list):
        raise ValueError
    arr = _arr_with_ids(dumps(ents))
    want = {(x['id'],): dict(refno=_s(x.get('refno'), 60), date=_s(x.get('date'), 12), adm_no=_s(x.get('adm'), 20), category=_s(x.get('category'), 60),
                             status=_s(x.get('status'), 30), seq=i, data=x) for i, x in enumerate(arr)}
    return dumps(obj), [(RefEntry, want, ['entry_id'], RR_F)]


def rr_implode(session, cfg):
    obj = json.loads(cfg or '{}')
    obj['entries'] = [r.data for r in RefEntry.objects.filter(session=session).order_by('seq')]
    return dumps(obj)


def att_explode(text):
    obj, want = _obj(text), {}
    for k, v in obj.items():
        p = k.split('|')
        if len(p) != 3 or not isinstance(v, dict):
            raise ValueError('unexpected attendance key')
        for adm, st in v.items():
            if not isinstance(st, str) or len(st) > 10:
                raise ValueError('unexpected status')
            if st:
                want[(_s(p[0], 12), _s(p[1], 40), _s(p[2], 10), _s(adm, 20))] = {'status': st}
    return '', [(AttendanceMark, want, ['date', 'cls', 'sec', 'adm_no'], ['status'])]


def att_implode(session, cfg):
    out = {}
    for d, c, s, a, st in AttendanceMark.objects.filter(session=session).order_by('date', 'cls', 'sec', 'adm_no').values_list('date', 'cls', 'sec', 'adm_no', 'status'):
        out.setdefault(f'{d}|{c}|{s}', {})[a] = st
    return dumps(out)


def acad_explode(text):
    obj = _obj(text)
    mk, co = obj.pop('mkdata', {}), obj.pop('cogr', {})
    if not isinstance(mk, dict) or not isinstance(co, dict):
        raise ValueError
    marks, grades = {}, {}
    for term, a in mk.items():
        if not isinstance(a, dict):
            raise ValueError
        for assess, b in a.items():
            if not isinstance(b, dict):
                raise ValueError
            for adm, subs in b.items():
                if not isinstance(subs, dict):
                    raise ValueError
                for sub, val in subs.items():
                    if isinstance(val, (dict, list)):
                        raise ValueError
                    marks[(_s(term, 40), _s(assess, 40), _s(adm, 20), _s(sub, 80))] = {'value': val}
    for term, a in co.items():
        if not isinstance(a, dict):
            raise ValueError
        for area, b in a.items():
            if not isinstance(b, dict):
                raise ValueError
            for adm, g in b.items():
                if not isinstance(g, str):
                    raise ValueError
                grades[(_s(term, 40), _s(area, 60), _s(adm, 20))] = {'grade': g[:20]}
    return dumps(obj), [(Mark, marks, ['term_id', 'assess', 'adm_no', 'subject'], ['value']), (CoGrade, grades, ['term_id', 'area_id', 'adm_no'], ['grade'])]


def acad_implode(session, cfg):
    obj = json.loads(cfg or '{}')
    mk, co = {}, {}
    for t, a, adm, sub, val in Mark.objects.filter(session=session).order_by('term_id', 'assess', 'adm_no', 'subject').values_list('term_id', 'assess', 'adm_no', 'subject', 'value'):
        mk.setdefault(t, {}).setdefault(a, {}).setdefault(adm, {})[sub] = val
    for t, ar, adm, g in CoGrade.objects.filter(session=session).order_by('term_id', 'area_id', 'adm_no').values_list('term_id', 'area_id', 'adm_no', 'grade'):
        co.setdefault(t, {}).setdefault(ar, {})[adm] = g
    obj['mkdata'], obj['cogr'] = mk, co
    return dumps(obj)


CODECS = {'gp': (gp_explode, gp_implode, [GatePass]), 'refreg': (rr_explode, rr_implode, [RefEntry]), 'att': (att_explode, att_implode, [AttendanceMark]),
          'acad': (acad_explode, acad_implode, [Mark, CoGrade])}


def codec_for(key):
    m = KEY_RE.match(key)
    if not m or m.group(2) not in CODECS:
        return None, None
    return CODECS[m.group(2)], m.group(1) or BASE


def store(key, text):
    """Save a document. Returns the text to keep in Doc.data: TAB-marked when the content went into tables, the original otherwise."""
    codec, session = codec_for(key)
    if not codec:
        return text
    try:
        cfg, parts = codec[0](text)
    except (ValueError, TypeError, AttributeError):
        purge(key)                      # unexpected shape: keep the document as it is, and make sure no stale rows remain
        return text
    for model, want, keyf, fields in parts:
        sync_rows(model, session, want, keyf, fields)
    return TAB + cfg


def purge(key):
    codec, session = codec_for(key)
    if codec:
        for model in codec[2]:
            model.objects.filter(session=session).delete()


def load(key, data):
    """Document text as the screens expect it."""
    if not data.startswith(TAB):
        return data
    codec, session = codec_for(key)
    return codec[1](session, data[len(TAB):])


# ---------------------------------------------------------------- admissions
def student_fields(rec):
    roll = str(rec.get('roll') or '').strip()
    return dict(reg_no=_s(rec.get('regNo'), 40), first_name=_s(rec.get('first'), 120), middle_name=_s(rec.get('middle'), 120),
                last_name=_s(rec.get('last'), 120), gender=_s(rec.get('gender') or rec.get('sex'), 12), dob=_s(rec.get('dob'), 12), father=_s(rec.get('father'), 120),
                mother=_s(rec.get('mother'), 120), mobile=_s(rec.get('mobile') or rec.get('phone'), 30), cls=_s(rec.get('cls'), 40),
                sec=_s(rec.get('sec'), 10), roll=int(roll) if roll.isdigit() and len(roll) < 9 else None, category=_s(rec.get('castCat'), 40),
                left=bool(rec.get('left')), data=rec)
