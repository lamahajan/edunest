"""Gate Pass <-> cloud bridge  (ERP  <->  Reception Suite / eGateSys).

The school's cloud apps (Reception Suite, eGateSys) keep working all day from the cloud database (Firebase), even when the
school server is switched off.  While the server IS on, this module keeps both sides equal:

  ERP -> cloud    a pass cut in the ERP is written to  <code>/passes/<id>  (so eGateSys shows it at the gate);
                  a gate-out marked in the ERP is written to  <code>/gateout/<id>.
  cloud -> ERP    a gate-out marked by eGateSys comes back into the ERP pass (time, bus, "by eGateSys");
                  a pass cut in Reception Suite while the server was off is added to the ERP.
  deleted pass    a pass deleted in the ERP is removed from the cloud as well.

Nothing here runs unless CLOUD_FB_URL and CLOUD_FB_CODE are set in data/config.env, so existing schools are not affected.
"""
import base64
import hashlib
import json
import logging
import os
import re
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timedelta, timezone
from pathlib import Path

from django.conf import settings
from django.db import transaction

from . import events, livesync, store, views
from .models import Doc, GatePass

log = logging.getLogger('cloud_gp')
IST = timezone(timedelta(hours=5, minutes=30))     # the cloud apps decide 'today' in India time (no daylight saving)
ERP_ID = re.compile(r'^GP-\d+$')          # ids made by the ERP; the cloud apps use random ids
IMG_EXT = {'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp'}


# ------------------------------------------------------------------ settings
def config():
    url, code = os.environ.get('CLOUD_FB_URL', '').strip().rstrip('/'), os.environ.get('CLOUD_FB_CODE', '').strip().strip('/')
    if not url or not code:
        return None
    return {'url': url, 'code': code, 'auth': os.environ.get('CLOUD_FB_AUTH', '').strip(),
            'safety': max(30, int(os.environ.get('CLOUD_SYNC_SAFETY_SECS', '300'))), 'session': os.environ.get('ERP_CLOUD_SESSION', '').strip()}


class Firebase:
    """Tiny Firebase Realtime Database REST client (no extra packages needed)."""

    def __init__(self, cfg, timeout=15):
        self.cfg, self.timeout = cfg, timeout

    def _url(self, path):
        q = '?auth=' + urllib.parse.quote(self.cfg['auth']) if self.cfg['auth'] else ''
        where = '/'.join(x for x in (self.cfg['code'], path) if x)
        return f"{self.cfg['url']}/{where}.json{q}"

    def _call(self, method, path, value=None):
        body = None if value is None else json.dumps(value, ensure_ascii=False).encode()
        req = urllib.request.Request(self._url(path), data=body, method=method, headers={'Content-Type': 'application/json'})
        with urllib.request.urlopen(req, timeout=self.timeout) as r:
            raw = r.read()
        return json.loads(raw) if raw else None

    def get(self, path):
        return self._call('GET', path)

    def keys(self, path):
        """Only the names directly under `path` (Firebase 'shallow'): cheap even when the node holds years of data."""
        url = self._url(path)
        url += ('&' if '?' in url else '?') + 'shallow=true'
        with urllib.request.urlopen(urllib.request.Request(url), timeout=self.timeout) as r:
            raw = r.read()
        d = json.loads(raw) if raw else None
        return sorted(d) if isinstance(d, dict) else []

    def put(self, path, value):
        return self._call('PUT', path, value)

    def patch(self, path, value):
        """Several changes at once; keys may be paths like 'a/b' and a None value deletes that node."""
        return self._call('PATCH', path, value)

    def delete(self, path):
        return self._call('DELETE', path)


# ------------------------------------------------------------------ format conversion
def _t_to_cloud(hhmm):
    """ERP '15:45' -> cloud '03:45:00 PM'."""
    try:
        return datetime.strptime(hhmm, '%H:%M').strftime('%I:%M:%S %p')
    except (TypeError, ValueError):
        return hhmm or ''


def _t_from_cloud(text):
    """Cloud '03:45:12 PM' (or '15:45') -> ERP '15:45'."""
    s = re.sub(r'\s+', ' ', str(text or '').strip().upper())
    for fmt in ('%I:%M:%S %p', '%I:%M %p', '%H:%M:%S', '%H:%M'):
        try:
            return datetime.strptime(s, fmt).strftime('%H:%M')
        except ValueError:
            pass
    return ''


def photo_data_url(photo):
    """The picker photo of an ERP pass as a data URL ('/media/x.jpg' is read from the media folder)."""
    if not photo:
        return ''
    if photo.startswith('data:'):
        return photo
    if photo.startswith('/media/'):
        f = Path(settings.MEDIA_ROOT) / photo[len('/media/'):]
        mime = {'jpg': 'image/jpeg', 'png': 'image/png', 'webp': 'image/webp'}.get(f.suffix.lstrip('.').lower())
        if mime and f.is_file() and f.stat().st_size < 3_000_000:
            return f'data:{mime};base64,' + base64.b64encode(f.read_bytes()).decode()
    return ''


def save_photo(data_url):
    """A cloud photo (data URL) -> media file; returns '/media/<name>.<ext>' or ''."""
    m = re.fullmatch(r'data:([\w/+.-]+);base64,(.+)', data_url or '', re.S)
    if not m or m.group(1) not in IMG_EXT:
        return ''
    try:
        raw = base64.b64decode(m.group(2), validate=True)
    except Exception:
        return ''
    name = hashlib.sha256(raw).hexdigest()
    path = views.media_path(name, IMG_EXT[m.group(1)])
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists():
        tmp = path.with_name(path.name + '.part')
        tmp.write_bytes(raw)
        os.replace(tmp, path)
    return f'/media/{name}.{IMG_EXT[m.group(1)]}'


def to_cloud(e):
    """ERP gate pass record -> the record Reception Suite / eGateSys expect in <code>/passes/<id>.
    (gateOutTime is never stored in /passes - gate-outs live in /gateout, exactly like Reception Suite does it.)"""
    out = {'id': e['id'], 'date': e.get('date', ''), 'time': _t_to_cloud(e.get('time', '')), 'studentName': e.get('name', ''),
           'admissionNumber': e.get('adm', ''), 'class': e.get('cls', ''), 'fatherName': e.get('father', ''), 'motherName': e.get('mother', ''),
           'pickedUpBy': e.get('takenBy', ''), 'relation': e.get('relation', ''), 'reason': e.get('reason', ''), 'busNumber': e.get('bus', '')}
    if e.get('photo'):
        out['_hasPhoto'] = True
    return out


def from_cloud(p, pid):
    """Cloud pass -> ERP record."""
    t = _t_from_cloud(p.get('time')) or datetime.now(IST).strftime('%H:%M')
    e = {'id': pid, 'type': 'Student', 'date': p.get('date', ''), 'time': t, 'ts': int(time.time() * 1000), 'name': p.get('studentName', ''),
         'adm': str(p.get('admissionNumber', '')), 'cls': p.get('class', ''), 'father': p.get('fatherName', ''), 'mother': p.get('motherName', ''),
         'mobile': '', 'takenBy': p.get('pickedUpBy', ''), 'relation': p.get('relation', ''), 'reason': p.get('reason', ''),
         'bus': p.get('busNumber', ''), 'photo': '', 'from': 'cloud'}
    return e


def approved(e):
    """With principal approval switched on, only approved passes go to the gate."""
    return not e.get('needApr') or e.get('apr') is True


# ------------------------------------------------------------------ ERP document helpers
def doc_key(session=None):
    """The gate pass list is NOT kept per session in the app (it is not in SESS_SCOPED): one key, always the base session's tables."""
    return 'eacademics_gp'


def current_session(cfg):
    """Latest academic session (for session-scoped documents such as classes / academics; NOT for gate passes)."""
    if cfg['session']:
        return cfg['session']
    d = Doc.objects.filter(coll='kv', key='eacademics_sessions').first()
    try:
        ids = [x['id'] for x in json.loads(store.load(d.key, d.data))] if d else []
        if ids:
            return ids[-1]
    except (ValueError, TypeError, KeyError):
        pass
    return store.BASE


def session_for_date(cfg, date):
    """The academic session a calendar day belongs to (an Apr-Mar year: 2026-11-05 -> 2026-2027), for attendance. The LATEST session is wrong for a
    school day once the next session exists (after Promotion): today's marks must go to the session the school is actually in."""
    if cfg['session']:
        return cfg['session']
    try:
        y, m = int(date[:4]), int(date[5:7])
        start = str(y if m >= 4 else y - 1)
        d = Doc.objects.filter(coll='kv', key='eacademics_sessions').first()
        for x in (json.loads(store.load(d.key, d.data)) if d else []):
            if str(x.get('id', '')).startswith(start):
                return x['id']
    except (ValueError, TypeError, KeyError, AttributeError):
        pass
    return current_session(cfg)


def update_passes(session, mutate):
    """Change the gate-pass list of a session the same way a browser save does (tables + version + 'changed' note for open screens)."""
    key = doc_key(session)
    with transaction.atomic():
        views.lock(f'kv:{key}')
        d = Doc.objects.select_for_update().filter(coll='kv', key=key).first()
        arr = json.loads(store.load(key, d.data)) if d else []
        if mutate(arr) is False:
            return False
        text = json.dumps(arr, ensure_ascii=False, separators=(',', ':'))
        if d is None:
            Doc.objects.create(coll='kv', key=key, data=store.store(key, text))
        else:
            d.data, d.version = store.store(key, text), d.version + 1
            d.save()
        views.note('kv', key)
    return True


# ------------------------------------------------------------------ one sync round
class Bridge:
    def __init__(self, cfg, fb=None):
        self.cfg, self.fb = cfg, fb or Firebase(cfg)
        self.sig = {}            # last pass record written to the cloud, per id (so unchanged passes cost nothing)
        self.out_sent = set()    # gate-outs already written to the cloud

    def run_once(self, today=None):
        today = today or datetime.now(IST).strftime('%Y-%m-%d')
        cloud = {k: v for k, v in (self.fb.get('passes') or {}).items() if isinstance(v, dict) and v.get('date') == today}
        gout = {k: v for k, v in (self.fb.get('gateout') or {}).items() if isinstance(v, dict) and v.get('gateOutTime')}
        erp = {r.pass_id: (r.session, dict(r.data)) for r in GatePass.objects.filter(date=today)}
        stats = {'pushed': 0, 'imported': 0, 'out_to_erp': 0, 'out_to_cloud': 0, 'removed': 0}

        # 1. ERP -> cloud: passes (and photos)
        for pid, (_, e) in erp.items():
            if not approved(e):
                if pid in cloud:
                    self._remove(pid); stats['removed'] += 1
                continue
            rec = to_cloud(e)
            s = json.dumps(rec, sort_keys=True)
            if self.sig.get(pid) != s or pid not in cloud:
                self.fb.put(f'passes/{pid}', rec)
                if e.get('photo'):
                    url = photo_data_url(e['photo'])
                    if url:
                        self.fb.put(f'photos/{pid}', url)
                self.sig[pid] = s; stats['pushed'] += 1

        # 2. cloud -> ERP: passes cut while the server was off; ERP-made ids missing in the ERP were deleted there
        new = {}
        for pid, p in cloud.items():
            if pid in erp:
                continue
            if ERP_ID.match(pid):
                self._remove(pid); stats['removed'] += 1
            else:
                new[pid] = p
        if new:
            session = store.BASE            # gate passes always live in the base session's document
            added = []
            for pid, p in new.items():
                e = from_cloud(p, pid)
                if p.get('_hasPhoto'):
                    try:
                        e['photo'] = save_photo(self.fb.get(f'photos/{pid}'))
                    except (urllib.error.URLError, ValueError):
                        pass
                added.append(e)

            def add(arr):
                have = {x.get('id') for x in arr}
                fresh = [e for e in added if e['id'] not in have]
                if not fresh:
                    return False
                arr.extend(fresh)
            if update_passes(session, add):
                stats['imported'] += len(added)
                for pid in new:
                    erp[pid] = (session, {})        # so step 3 can apply a gate-out to it right away

        # 3. gate-outs, both ways
        incoming = {}   # session -> {pass id: gate-out record from the cloud}
        for pid, g in gout.items():
            if pid in erp and not (erp[pid][1].get('outTime')):
                incoming.setdefault(erp[pid][0], {})[pid] = g
        for session, recs in incoming.items():
            def apply(arr, recs=recs):
                n = 0
                for e in arr:
                    g = recs.get(e.get('id'))
                    if g and not e.get('outTime'):
                        e['outTime'] = _t_from_cloud(g.get('gateOutTime')) or datetime.now(IST).strftime('%H:%M')
                        e['outTs'] = int(g.get('_ts') or time.time() * 1000)
                        e['outBy'] = 'eGateSys'
                        if g.get('busNumber'):
                            e['bus'] = g['busNumber']
                        n += 1
                return n > 0 or False
            if update_passes(session, apply):
                stats['out_to_erp'] += len(recs)
        for pid, (_, e) in erp.items():
            if e.get('outTime') and pid not in gout and pid not in self.out_sent and approved(e):
                self.fb.put(f'gateout/{pid}', {'gateOutTime': _t_to_cloud(e['outTime']), 'busNumber': e.get('bus', ''), '_ts': e.get('outTs') or int(time.time() * 1000)})
                self.fb.put('lastMod', int(time.time() * 1000))
                self.out_sent.add(pid); stats['out_to_cloud'] += 1
        return stats

    def fetch_history(self):
        """FORCE FETCH: every pass and gate-out in the cloud, of ANY date, that the ERP does not have yet. Nothing in the cloud is changed or deleted."""
        cloud = {k: v for k, v in (self.fb.get('passes') or {}).items() if isinstance(v, dict)}
        gout = {k: v for k, v in (self.fb.get('gateout') or {}).items() if isinstance(v, dict) and v.get('gateOutTime')}
        erp = {r.pass_id: (r.session, dict(r.data)) for r in GatePass.objects.all()}
        stats = {'passes in the cloud': len(cloud), 'passes added': 0, 'gate-outs added': 0}
        new = {pid: p for pid, p in cloud.items() if pid not in erp}
        if new:
            added = []
            for pid, p in new.items():
                e = from_cloud(p, pid)
                if p.get('_hasPhoto'):
                    try:
                        e['photo'] = save_photo(self.fb.get(f'photos/{pid}'))
                    except (urllib.error.URLError, ValueError):
                        pass
                added.append(e)

            def add(arr):
                have = {x.get('id') for x in arr}
                fresh = [e for e in added if e['id'] not in have]
                if not fresh:
                    return False
                arr.extend(fresh)
            if update_passes(store.BASE, add):
                stats['passes added'] = len(added)
                for pid in new:
                    erp[pid] = (store.BASE, {})
        incoming = {}
        for pid, g in gout.items():
            if pid in erp and not erp[pid][1].get('outTime'):
                incoming.setdefault(erp[pid][0], {})[pid] = g
        for session, recs in incoming.items():
            def apply(arr, recs=recs):
                n = 0
                for e in arr:
                    g = recs.get(e.get('id'))
                    if g and not e.get('outTime'):
                        e['outTime'] = _t_from_cloud(g.get('gateOutTime')) or datetime.now(IST).strftime('%H:%M')
                        e['outTs'] = int(g.get('_ts') or time.time() * 1000)
                        e['outBy'] = 'eGateSys'
                        if g.get('busNumber'):
                            e['bus'] = g['busNumber']
                        n += 1
                stats['gate-outs added'] += n
                return n > 0 or False
            update_passes(session, apply)
        return stats

    def _remove(self, pid):
        for node in ('passes', 'gateout', 'photos'):
            self.fb.delete(f'{node}/{pid}')
        self.sig.pop(pid, None)


# ------------------------------------------------------------------ background worker (started by serve.py): event driven
WAKE = livesync.Waker()


def _on_kv(key):
    if key == 'eacademics_gp':
        WAKE.set()


def attach():
    """A gate pass saved in the ERP wakes the worker at once."""
    events.on('kv', _on_kv)


def loop(stop=None):
    cfg = config()
    if not cfg:
        return
    attach()
    bridge = Bridge(cfg)
    livesync.start_streams(bridge.fb, ['passes', 'gateout'], WAKE, stop)       # the cloud tells us the moment a pass / gate-out changes
    log.info('Gate Pass cloud sync ON (live)')

    def work():
        st = bridge.run_once()
        if any(st.values()):
            log.info('gate pass cloud sync: %s', st)
    livesync.run_loop('gate pass cloud sync', WAKE, work, cfg['safety'], stop)


def fetch_all():
    cfg = config()
    if not cfg:
        raise RuntimeError('Gate Pass is not set up')
    return Bridge(cfg).fetch_history()


def start_background():
    if not config():
        return None
    t = threading.Thread(target=loop, name='cloud-gp', daemon=True)
    t.start()
    return t
