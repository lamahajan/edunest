"""Old-program addresses -> clean ones: no 'Vill' / 'V.P.O' / 'P.O' labels, no phone numbers, proper capitalisation; and the PIN code looked up on the internet (India Post)."""
import json
import re
import time
import urllib.parse
import urllib.request
from pathlib import Path

SMALL = {'of', 'and', 'the', 'near', 'opp', 'opp.', 'behind', 'in', 'at', 'by', 's/o', 'd/o', 'w/o'}
PHONE_RX = re.compile(r'\b(?:M|PH|MOB|MOBILE|PHONE|TEL|CELL)\b\s*[-:.]*\s*[\d\-\s,/.+]+', re.I)
VPO_RX = re.compile(r'\bV\s*\.?\s*P\s*\.?\s*O\s*\.?\s*[-:.]?\s*', re.I)
VILL_RX = re.compile(r'\b(?:VILLAGE|VILL|VIL|VLG)\b\s*\.?\s*[-:.]?\s*', re.I)
PO_RX = re.compile(r'\b(?:P\s*\.\s*O|PO|POST\s*OFFICE)\b\s*\.?\s*[-:.]?\s*', re.I)
LABELS = ('V.P.O', 'VPO', 'VILL', 'VILLAGE', 'VIL', 'P.O', 'PO', 'PH', 'M', 'MOB', 'TEH', 'TEHSIL', 'DISTT', 'DIST', 'H', 'HNO')


def smart_title(s):
    """Title Case that keeps abbreviations such as 'N.J.S' or 'H.No.' and small words in lower case."""
    out = []
    for i, w in enumerate(re.split(r'(\s+)', s.strip())):
        if not w.strip():
            out.append(' ')
            continue
        core = w.strip(',;')
        if re.fullmatch(r'(?:[A-Za-z]\.){2,}[A-Za-z]?\.?', core):
            t = core.upper()
        elif re.fullmatch(r'[A-Za-z]\.[A-Za-z]+\.?', core):                  # H.NO -> H.No
            t = '.'.join(x[:1].upper() + x[1:].lower() for x in core.split('.'))
        elif '.' in core.strip('.') and not core.isdigit():                    # NAROT.J.S -> Narot.J.S
            t = '.'.join(x[:1].upper() + x[1:].lower() for x in core.split('.'))
        elif core.lower() in SMALL and i > 0:
            t = core.lower()
        elif core.isdigit() or re.fullmatch(r'\d+[A-Za-z]?', core):
            t = core.upper()
        else:
            t = '-'.join(p[:1].upper() + p[1:].lower() for p in core.split('-'))
        out.append(w.replace(core, t, 1))
    return re.sub(r'\s+', ' ', ''.join(out)).strip()


def _tidy(s):
    return re.sub(r'\s+', ' ', re.sub(r'\s*,\s*', ', ', s)).strip(' ,.-:;')


def parse_address(*parts):
    """-> dict(addr, place, po, pin, phones). addr = places written plainly ('Pharwal, Narot'); place = village / locality; po = post office when it was named."""
    raw = ' , '.join(str(p or '') for p in parts)
    phones = [m.group(0) for m in PHONE_RX.finditer(raw)]
    raw = PHONE_RX.sub(' , ', raw)
    pin = ''
    m = re.search(r'(?<!\d)([1-9]\d{5})(?!\d)', raw)
    if m:
        pin = m.group(1)
        raw = raw.replace(m.group(1), ' ')
    raw = re.sub(r'(?<!\d)0\d{2,5}[\s-]?\d{5,8}(?!\d)', ' ', raw)                    # a landline number left without PH-
    vpo = None
    m = VPO_RX.search(raw)
    if m:
        seg = re.split(r'[,;]|\bP\s*\.\s*O\b|\bVILL\b', raw[m.end():], 1, flags=re.I)[0]
        vpo = _tidy(seg)
        raw = raw[:m.start()] + ' , ' + vpo + ' , ' + raw[m.end() + len(seg):]
    po = None
    m = PO_RX.search(raw)
    if m:
        seg = re.split(r'[,;]|\bVILL\b|\bVIL\b', raw[m.end():], 1, flags=re.I)[0]
        po = _tidy(seg)
        raw = raw[:m.start()] + ' , ' + po + ' , ' + raw[m.end() + len(seg):]
    village = None
    m = VILL_RX.search(raw)
    if m:
        seg = re.split(r'[,;]|\bP\s*\.\s*O\b', raw[m.end():], 1, flags=re.I)[0]
        village = _tidy(seg)
    segs = []
    for seg in re.split(r'[,;]', VILL_RX.sub(' , ', PO_RX.sub(' , ', VPO_RX.sub(' , ', raw)))):
        seg = _tidy(seg)
        if seg and seg.lower() not in (x.lower() for x in segs):
            segs.append(seg)
    place = vpo or village or (segs[0] if segs else '')
    return {'addr': smart_title(', '.join(segs)), 'place': smart_title(place) if place else '', 'po': smart_title(po or vpo or '') if (po or vpo) else '', 'pin': pin, 'phones': phones}


class PinLookup:
    """PIN code of a post office / village name through the India Post service (needs internet). Only an EXACT name match inside the school's state is accepted;
    when two different PIN codes fit, the preferred districts decide; if it is still unclear nothing is guessed (the row goes to the review list)."""

    URL = 'https://api.postalpincode.in/postoffice/'

    def __init__(self, cache_path, state='Punjab', districts=('Gurdaspur', 'Pathankot'), fetch=None, timeout=15):
        self.path, self.state, self.districts, self.timeout = Path(cache_path), state.lower(), [d.lower() for d in districts], timeout
        self.fetch = fetch or self._http
        try:
            self.cache = json.loads(self.path.read_text(encoding='utf-8'))
        except Exception:
            self.cache = {}
        self.errors = 0

    def _http(self, name):
        time.sleep(0.2)                                                      # be gentle with the free service
        req = urllib.request.Request(self.URL + urllib.parse.quote(name), headers={'User-Agent': 'EduNest'})
        with urllib.request.urlopen(req, timeout=self.timeout) as r:
            return json.loads(r.read().decode('utf-8'))

    @staticmethod
    def _norm(n):
        return re.sub(r'\s+', ' ', re.sub(r'\b(?:B\.?O|S\.?O|H\.?O|G\.?P\.?O)\b\.?', '', str(n or ''), flags=re.I)).strip().lower()

    def find(self, name):
        """-> {'pin','district','state','how'} or None"""
        key = self._norm(name)
        if not key:
            return None
        if key not in self.cache:
            try:
                data = self.fetch(name.strip())
            except Exception:
                self.errors += 1
                return None
            offices = (data[0].get('PostOffice') if isinstance(data, list) and data else None) or []
            self.cache[key] = [{'n': o.get('Name'), 'p': o.get('Pincode'), 'd': o.get('District'), 's': o.get('State')} for o in offices]
            try:
                self.path.write_text(json.dumps(self.cache, ensure_ascii=False), encoding='utf-8')
            except OSError:
                pass
        hits = [o for o in self.cache[key] if (o.get('s') or '').lower() == self.state and self._norm(o.get('n')) == key and o.get('p')]
        pins = sorted({o['p'] for o in hits})
        if len(pins) == 1:
            o = hits[0]
            return {'pin': o['p'], 'district': o.get('d') or '', 'state': o.get('s') or '', 'how': 'exact name'}
        if len(pins) > 1:
            pref = [o for o in hits if (o.get('d') or '').lower() in self.districts]
            pp = sorted({o['p'] for o in pref})
            if len(pp) == 1:
                return {'pin': pp[0], 'district': pref[0].get('d') or '', 'state': pref[0].get('s') or '', 'how': 'exact name, school district'}
        return None


def lookup_names(addr):
    """Names to try for the PIN lookup, best first: the LAST place of a written address (post office / town), then the earlier ones."""
    out = []
    for seg in reversed([x.strip() for x in str(addr or '').split(',') if x.strip()]):
        seg = re.sub(r'^(?:teh(?:sil)?|distt?|dist\.?|tehsil|po|p\.o\.?)\s+', '', seg, flags=re.I).strip()
        if len(seg) < 3 or re.match(r'^(?:h\.?\s*no|house|ward|gali|street|mohalla|plot|flat|opp|near|behind)\b', seg, re.I) or re.search(r'\d', seg):
            continue
        if seg.lower() not in (o.lower() for o in out):
            out.append(seg)
    return out
