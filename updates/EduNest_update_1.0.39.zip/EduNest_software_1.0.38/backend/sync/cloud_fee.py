"""Online fee payments (UPI-Redirect / DigiFee) <-> ERP.

Parents pay from a QR / link (Razorpay). Two things must stay in step with the ERP while the server is on, and both are EVENT DRIVEN:

  due list   the pay page shows each student's pending fee. The browser that has the ERP open works the dues out with the ERP's own
             Dues Report engine (so the cloud shows exactly what Reports > Dues shows) and sends them to the server whenever the ERP data
             changes; the server then updates the cloud Due List at once. Money that has arrived online but is not yet a fee receipt is
             taken off the balance (the pay page's worker already does that when a payment lands, so a refresh must not undo it).
  payments   every successful online payment (cloud `pay_...` record) is picked up the moment it is written (live stream) and queued.
             A payment closes in the cloud as soon as a fee receipt with its bank reference (RRN / payment id) exists in the ERP. The RRN is
             the proof of the payment: one that is not 12 digits, or is already on another student's receipt, is held back (`hold`).
             Every other payment is turned into a fee receipt by the browser (static/erp-fee-sync.js) with the ERP's own receipt rules,
             whatever the amount. Browsers are told about queue changes through the normal ERP live channel (event 'feeq').

Nothing runs unless the Due List / payment database is configured in data/config.env (see HELP.html).
"""
import json
import logging
import os
import threading
import time
import urllib.error
import urllib.request

from django.db import transaction

from . import cloud_gp, events, livesync, views
from .models import Doc, ReceiptDoc, Student

log = logging.getLogger('cloud_fee')
SNAP_KEY, QUEUE_KEY = 'fee_due_snapshot', 'fee_txn_queue'
BATCH = 300
WAKE = livesync.Waker()


def _cfg(prefix, same_as=None):
    """One Firebase database from config.env. `same_as` (the Due List's): Payments with no address of their own use it (the usual case:
    both sit in one Firebase project), and with it the same secret and the standard path TXN."""
    url = os.environ.get(f'CLOUD_FEE_{prefix}_URL', '').strip().rstrip('/')
    code = os.environ.get(f'CLOUD_FEE_{prefix}_PATH', '').strip().strip('/')
    auth = os.environ.get(f'CLOUD_FEE_{prefix}_SECRET', '').strip()
    if same_as and not url:
        url = same_as['url']
    if same_as and url == same_as['url']:
        auth = auth or same_as['auth']                 # one Firebase: one secret
    if prefix == 'TXN' and url:
        code = code or 'TXN'                           # the payments node is always called TXN
    if not url or not code:
        return None
    return {'url': url, 'code': code, 'auth': auth}


def config():
    due = _cfg('DUE')
    txn = _cfg('TXN', same_as=due)
    if not due and not txn:
        return None
    wurl, token = os.environ.get('CLOUD_FEE_WORKER_URL', '').strip().rstrip('/'), os.environ.get('CLOUD_FEE_APP_TOKEN', '').strip()
    return {'due': due, 'txn': txn, 'safety': max(30, int(os.environ.get('CLOUD_FEE_SAFETY_SECS', '300'))), 'worker': {'url': wurl, 'token': token} if wurl and token else None}


def _meta(key, default):
    d = Doc.objects.filter(coll='meta', key=key).first()
    return d.data if d and isinstance(d.data, dict) else default


def _set_meta(key, value):
    Doc.objects.update_or_create(coll='meta', key=key, defaults={'data': value})


# ---------------------------------------------------------------- due list
def save_snapshot(session, as_on, dues, total=None):
    """Called by the browser: {adm: {balance, name, cls, mob}} for every student who owes money today (`total` = how many active students the
    browser looked at). Returns True when it changed. A list worked out from NO students is a page that was not ready: never accepted."""
    if total is not None and not total:
        return False
    clean = {}
    for adm, v in (dues or {}).items():
        try:
            bal = round(float(v.get('balance')), 2)
        except (TypeError, ValueError, AttributeError):
            continue
        key = ''.join(c for c in str(adm) if c.isalnum() or c in '_-')       # Firebase keys cannot hold . $ # [ ] /
        if bal > 0 and key:
            clean[key] = {'adm': str(adm)[:30], 'balance': bal, 'name': str(v.get('name') or '')[:80], 'cls': str(v.get('cls') or '')[:20], 'mob': str(v.get('mob') or '')[:20]}
    old = _meta(SNAP_KEY, {})
    if old.get('dues') == clean:
        return False
    _set_meta(SNAP_KEY, {'session': session, 'asOn': as_on, 'dues': clean, 'at': int(time.time())})
    WAKE.set()                                                                   # new dues: update the cloud Due List now
    return True


def due_changes(dues, existing):
    """The multi-path PATCH that makes the cloud Due List equal to `dues` (other fields a node may have are kept).
    The pay page's worker finds a student by the `adm` field, so every node carries it."""
    push = {}
    for key, v in dues.items():
        node = existing.get(key) if isinstance(existing.get(key), dict) else {}
        if node.get('balance') != v['balance']:
            push[f'{key}/balance'] = v['balance']
        for f in ('adm', 'name', 'cls', 'mob'):
            if v.get(f) and node.get(f) != v[f]:
                push[f'{key}/{f}'] = v[f]
    for key, node in existing.items():
        if key in dues:
            continue
        if not isinstance(node, dict):
            push[key] = None
        elif node.get('name') or node.get('adm'):
            if node.get('balance', 0) != 0:
                push[f'{key}/balance'] = 0               # paid up: keep name/class/mobile, clear the amount
        else:
            try:
                if float(node.get('balance') or 0) <= 0:
                    push[key] = None                     # empty leftover
            except (TypeError, ValueError):
                push[key] = None
    return push


class Bridge:
    def __init__(self, cfg, due_fb=None, txn_fb=None):
        self.cfg = cfg
        self.due_fb = due_fb or (cloud_gp.Firebase(cfg['due']) if cfg['due'] else None)
        self.txn_fb = txn_fb or (cloud_gp.Firebase(cfg['txn']) if cfg['txn'] else None)
        self.sent = None
        self.open_amounts = {}           # adm -> rupees paid online but not yet a receipt

    def push_dues(self):
        snap = _meta(SNAP_KEY, {})
        if not self.due_fb or 'dues' not in snap:
            return 0
        shown = {}
        for key, v in snap['dues'].items():
            bal = round(v['balance'] - self.open_amounts.get(v.get('adm', key), 0), 2)       # what the parent still has to pay
            if bal > 0:
                shown[key] = dict(v, balance=bal)
        if shown == self.sent:
            return 0
        existing = self.due_fb.get('') or {}
        push = due_changes(shown, existing if isinstance(existing, dict) else {})
        items = list(push.items())
        for i in range(0, len(items), BATCH):
            self.due_fb.patch('', dict(items[i:i + BATCH]))
        self.sent = shown
        return len(items)

    def reconcile_qrs(self, post=None):
        """After the Due List changed, ask the pay page's worker to close the fixed-amount QR of every student who no longer owes anything
        (paid by cash, say), so that old QR can not be paid again. The worker reads the Due List itself and closes a chunk per call.
        Optional (needs CLOUD_FEE_WORKER_URL + CLOUD_FEE_APP_TOKEN); never fails the sync. Returns how many QRs were closed."""
        w = self.cfg.get('worker')
        if not w:
            return 0
        post = post or self._post
        total = 0
        try:
            for _ in range(100):
                status, d = post(w['url'] + '/reconcile-qrs', w['token'])
                if status == 409:
                    log.warning('QR reconcile: the worker found the Due List empty or unreadable - nothing closed')
                    break
                closed = int((d or {}).get('closed_count') or 0)
                total += closed
                if not (d or {}).get('remaining') or not closed:
                    break
        except Exception as e:
            log.warning('QR reconcile failed (%s); closed %s so far', e, total)
        return total

    @staticmethod
    def _post(url, token):
        req = urllib.request.Request(url, data=b'{}', method='POST', headers={'Content-Type': 'application/json', 'X-App-Token': token, 'User-Agent': 'SchoolERP/1.0'})
        try:
            with urllib.request.urlopen(req, timeout=60) as r:
                return r.status, json.loads(r.read() or b'{}')
        except urllib.error.HTTPError as e:
            if e.code == 409:
                return 409, {}
            raise

    # ---------------------------------------------------------------- payments
    def poll_payments(self):
        """Close payments that already have a receipt, queue the rest. Returns (closed, waiting)."""
        if not self.txn_fb:
            return 0, 0
        all_txn = self.txn_fb.get('') or {}
        queue, closed, amounts = {}, 0, {}
        for key, t in (all_txn.items() if isinstance(all_txn, dict) else []):
            if not (key.startswith('pay_') and isinstance(t, dict)) or t.get('logged_to_mdb') or t.get('needs_review') or not t.get('adm') or not t.get('amount'):
                continue
            refs = {str(x) for x in (t.get('rrn'), t.get('payment_id'), key) if x}
            adm = str(t['adm'])
            voucher = next((r.voucher_no for r in ReceiptDoc.objects.filter(adm=adm, cancelled=False) if str((r.data or {}).get('ref') or '').strip() in refs), None)
            if voucher is not None:
                self.mark_done(key, voucher)
                closed += 1
                continue
            rrn = str(t.get('rrn') or '').strip()
            rrn_ok = rrn.isdigit() and len(rrn) == 12                    # a bank reference number (RRN) has 12 digits
            clash = ReceiptDoc.objects.filter(cancelled=False, data__ref=rrn).exclude(adm=adm).first() if rrn_ok else None
            hold = '' if rrn_ok and not clash else ('RRN is missing or not 12 digits' if not rrn_ok else f'RRN already used on voucher {clash.voucher_no} of another student')
            s = Student.objects.filter(adm_no=adm).order_by('-session').first()
            queue[key] = {'rrn_ok': rrn_ok, 'hold': hold, 'adm': adm, 'name': (' '.join(x for x in (s.first_name, s.last_name) if x) if s else ''),
                          'cls': (f'{s.cls}-{s.sec}' if s else ''), 'amount': round(float(t['amount']) / 100, 2), 'paid_at': t.get('paid_at') or 0,
                          'ref': t.get('rrn') or t.get('payment_id') or key, 'method': t.get('method') or 'upi'}
            amounts[adm] = round(amounts.get(adm, 0) + queue[key]['amount'], 2)
        self.open_amounts = amounts
        old = _meta(QUEUE_KEY, {}).get('items', {})
        for key, it in old.items():
            if key in queue and it.get('claim'):
                queue[key]['claim'] = it['claim']          # a browser is posting this payment right now
        strip = lambda q: {k: {f: v for f, v in x.items() if f != 'claim'} for k, x in q.items()}
        _set_meta(QUEUE_KEY, {'items': queue, 'at': int(time.time())})
        if strip(queue) != strip(old):
            views.note('feeq', 'queue')                    # open ERP screens are told through the normal live channel
        return closed, len(queue)

    def mark_done(self, key, voucher=None):
        now = int(time.time() * 1000)
        body = {'processed': True, 'processedAt': now, 'logged_to_mdb': True, 'logged_by': 'ERP', 'logged_at': now}
        if voucher is not None:
            body['voucher'] = voucher
        self.txn_fb.patch(key, body)

    def mark_review(self, key, reason):
        self.txn_fb.patch(key, {'needs_review': str(reason)[:200]})

    def run_once(self):
        out = {'due_changes': 0, 'closed': 0, 'waiting': 0}
        if self.txn_fb:
            out['closed'], out['waiting'] = self.poll_payments()          # first: the due list must know what is already paid online
        if self.due_fb:
            out['due_changes'] = self.push_dues()
            if out['due_changes']:
                out['qr_closed'] = self.reconcile_qrs()
        return out


def claim(key, ttl=120):
    """One browser at a time posts a payment: True for the first caller, False for others until `ttl` seconds pass."""
    with transaction.atomic():
        d = Doc.objects.select_for_update().filter(coll='meta', key=QUEUE_KEY).first()
        data = d.data if d and isinstance(d.data, dict) else {}
        item = (data.get('items') or {}).get(key)
        if item is None or (item.get('claim') and time.time() - item['claim'] < ttl):
            return False
        item['claim'] = time.time()
        d.data = data
        d.save()
        return True


def queue():
    return _meta(QUEUE_KEY, {}).get('items', {})


def _on_receipt(key):
    WAKE.set()


def attach():
    """A receipt saved / changed in the ERP may close a payment: look at once."""
    events.on('receipts', _on_receipt)


def loop(stop=None):
    cfg = config()
    if not cfg:
        return
    attach()
    b = Bridge(cfg)
    if b.txn_fb:
        livesync.start_streams(b.txn_fb, [''], WAKE, stop)              # a payment landing wakes us at once
    log.info('Online fee sync ON (live)')

    def work():
        st = b.run_once()
        if st['due_changes'] or st['closed']:
            log.info('online fee sync: %s', st)
    livesync.run_loop('online fee sync', WAKE, work, cfg['safety'], stop)


def fetch_all():
    """FORCE FETCH: every online payment still waiting in the cloud is turned into a receipt now, and the due list is sent again."""
    cfg = config()
    if not cfg:
        raise RuntimeError('Online fee is not set up')
    b = Bridge(cfg)
    return {'payments closed': (b.run_once() or {}).get('closed', 0)}


def start_background():
    if not config():
        return None
    t = threading.Thread(target=loop, name='cloud-fee', daemon=True)
    t.start()
    return t
