"""Send students' parents' and teachers' phone numbers to Google Contacts (one way). See sync/contacts_sync.py and google_contacts/SETUP.txt.
  python manage.py sync_contacts           send the changes
  python manage.py sync_contacts --full    send everything again (contacts that are no longer in the ERP are removed too)
  python manage.py sync_contacts --test    only check the connection to the Google script
  python manage.py sync_contacts --list    show what would be sent (nothing is sent)"""
from django.core.management.base import BaseCommand

from sync import contacts_sync


class Command(BaseCommand):
    help = 'ERP -> Google Contacts'

    def add_arguments(self, p):
        p.add_argument('--full', action='store_true')
        p.add_argument('--test', action='store_true')
        p.add_argument('--list', action='store_true')

    def handle(self, *a, **o):
        if o['test']:
            ok, msg = contacts_sync.test()
            self.stdout.write(('OK: ' if ok else 'PROBLEM: ') + msg)
            return
        if o['list']:
            want = contacts_sync.collect(contacts_sync.settings_now())
            for k, (n, p) in sorted(want.items()):
                self.stdout.write(f'{p}  {n}')
            self.stdout.write(f'{len(want)} contacts')
            return
        ok, msg = contacts_sync.run(full=o['full'])
        self.stdout.write(('OK: ' if ok else 'PROBLEM: ') + msg)
