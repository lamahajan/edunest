"""One round of Gate Pass cloud sync (ERP <-> Reception Suite / eGateSys). `--loop` keeps going (the server does this by itself)."""
from django.core.management.base import BaseCommand, CommandError

from sync import cloud_gp


class Command(BaseCommand):
    help = 'Sync today\'s gate passes and gate-outs between the ERP and the cloud database.'

    def add_arguments(self, parser):
        parser.add_argument('--loop', action='store_true', help='repeat forever')

    def handle(self, *args, **opts):
        cfg = cloud_gp.config()
        if not cfg:
            raise CommandError('Set CLOUD_FB_URL and CLOUD_FB_CODE in data/config.env first (see HELP.html).')
        if opts['loop']:
            return cloud_gp.loop()
        self.stdout.write(str(cloud_gp.Bridge(cfg).run_once()))
