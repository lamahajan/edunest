"""First-time setup: creates the first Administrator. With no options it creates the default one (name Administrator, username admin, password admin123) and
asks nothing; --ask (or --name / --username / --password, or ERP_DEFAULT_ADMIN=0) lets the school choose its own."""
import getpass
import json
import secrets

from django.core.management.base import BaseCommand, CommandError

from sync import perms
from sync.models import Change, Doc


class Command(BaseCommand):
    help = 'Create the first Administrator login'

    def add_arguments(self, p):
        p.add_argument('--name'); p.add_argument('--username'); p.add_argument('--password')
        p.add_argument('--ask', action='store_true', help='ask for the name, username and password instead of using the default login')

    def handle(self, *a, **o):
        if perms.load_users():
            self.stdout.write('Setup is already done. To change a password run ERP.bat (option 8)')
            return
        if not (o['ask'] or o['name'] or o['username'] or o['password']) and perms.ensure_default_admin():
            d = perms.DEFAULT_ADMIN
            self.stdout.write(self.style.SUCCESS(f'Done. Sign in with username "{d["username"]}" and password "{d["password"]}", then CHANGE THE PASSWORD '
                                                 f'(profile menu > User Management).'))
            return
        name = o['name'] or input('Your full name (e.g. Dr. Lakshaya): ').strip()
        un = (o['username'] or input('Choose a username (small letters, e.g. admin): ').strip()).lower()
        pw = o['password']
        if not pw:
            pw, pw2 = getpass.getpass('Choose a password (at least 8 characters): '), None
            pw2 = getpass.getpass('Type the password again: ')
            if pw != pw2:
                raise CommandError('The two passwords are different. Run setup again.')
        if not name or not un or len(pw) < 8:
            raise CommandError('Name and username are required and the password needs at least 8 characters.')
        user = {'id': 'U' + secrets.token_hex(4), 'name': name, 'username': un, 'pass': perms.hash_h1(pw),
                'role': 'Administrator', 'active': True, 'perm': {}, 'created': '', 'lastLogin': ''}
        Doc.objects.update_or_create(coll='kv', key=perms.USERS_KEY, defaults={'data': json.dumps([user]), 'version': 1})
        Change.objects.create(coll='kv', key=perms.USERS_KEY, action='put')
        self.stdout.write(self.style.SUCCESS(f'Done. You can sign in as "{un}".'))
