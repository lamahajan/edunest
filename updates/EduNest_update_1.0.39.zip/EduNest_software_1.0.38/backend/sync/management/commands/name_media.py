"""Gives the uploaded photos / documents in data/media readable names (22012_student.jpg ...). Safe to run any time."""
from django.core.management.base import BaseCommand

from sync import medianame


class Command(BaseCommand):
    help = 'Rename hash-named photos in the media folder to <AdmNo>_<what>.<ext>.'

    def handle(self, *a, **o):
        n, s = medianame.rename_all()
        self.stdout.write(f'{n} admission records and {s} school-setting record renamed.' if n or s else 'Nothing to rename.')
