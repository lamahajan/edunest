"""Brings the students of an OLD FoxPro school program (A.DBF + FEE.DBF) into one academic session. Run the years in order (oldest first).

    python manage.py import_foxpro "<folder with A.DBF>" --session 2010-2011 [--also "<another copy of the same year>"]   (preview only: nothing is saved)
    python manage.py import_foxpro "<folder with A.DBF>" --session 2010-2011 --apply                                      (saves; a backup is made first)

One admission number = one child. The old program numbered by class series and REUSED numbers after a child left, so children are recognised by NAME + FATHER : a child already in the software keeps his/her admission number in the new session; a NEW child gets the old number, or 'number-2'
when another child already owns it. --also: other copies of the same year; they only fill what the main copy has blank. Everything is listed in data/import_preview_<session>.csv.
"""
import collections
import csv
import json
import re
from datetime import datetime
from pathlib import Path

from django.conf import settings
from django.core.management import call_command
from django.core.management.base import BaseCommand, CommandError
from django.db import transaction

from sync import addrfix, person, store
from sync.dbf import read_dbf
from sync.models import Doc, Person, Student

CLASS_OF = {'PRE-NUR': 'Pre Nursery', 'NUR': 'Nursery', 'JR-KG': 'LKG', 'SR-KG': 'UKG', 'IST': '1st', '1ST': '1st', '2ND': '2nd', '3RD': '3rd', '4TH': '4th', '5TH': '5th',
            '6TH': '6th', '7TH': '7th', '8TH': '8th', '9TH': '9th', '10TH': '10th'}
HONOR = re.compile(r'^\s*(SH|SMT|SHRI|SHRIMATI|MR|MRS|MS|KUM|S|SRI)\b[\s.\-]*', re.I)
PHONE = re.compile(r'\b(?:M|PH|MOB|MOBILE|PHONE|TEL)\b\s*[-:.]*\s*[\d\-\s,/]+', re.I)


def clean_name(s):
    s = re.sub(r'\s+', ' ', HONOR.sub('', (s or '').strip())).strip(' .-')
    return s.title()


def parse_phones(*texts):
    mobiles, lands = [], []
    for t in texts:
        for m in re.findall(r'(?<![\d])(?:\+?91[\s-]?)?([6-9]\d{9})(?![\d])', t or ''):
            if m not in mobiles:
                mobiles.append(m)
        for m in re.findall(r'(?:PH|TEL)?\s*[-:.]*\s*(0\d{2,5}[\s-]?\d{5,8})', t or '', flags=re.I):
            d = re.sub(r'\D', '', m)
            if d not in lands and not any(d.endswith(x) for x in mobiles):
                lands.append(d)
    return mobiles, lands


def fix_year(d):
    """FoxPro with the century switched off stored 2007 as 1907."""
    if d and d.year < 1950:
        try:
            return d.replace(year=d.year + 100), True
        except ValueError:
            return None, True
    return d, False


def class_sec(old):
    s = (old or '').strip().upper()
    s = re.sub(r'^\d+(?=(?:PRE|NUR|JR|SR))', '', s)             # a typed '09NUR-B'
    m = re.match(r'^(.*?)(?:-([A-Z]))?$', s)
    base, sec = (m.group(1), m.group(2)) if m else (s, None)
    return CLASS_OF.get(base, ''), (sec or 'A') if CLASS_OF.get(base) else ''


def build(a, adm_date):
    first, *rest = (a['NAME'] or '').split() or ['']
    nm = clean_name(a['NAME']).split()
    cls, sec = class_sec(a['CLASS'])
    dob, fixed = fix_year(a['DOB'])
    mob, lands = parse_phones(a['ADDRESS1'], a['ADDRESS2'], a['CITY'])
    pa = addrfix.parse_address(a['ADDRESS1'], a['ADDRESS2'], a['CITY'])
    addr = pa['addr']                                   # no Vill / V.P.O / P.O words, proper capitals; the PIN code is filled later by fix_addresses
    rec = {'adm': str(a['REGD']), 'date': adm_date.isoformat() if adm_date else '', 'regNo': '', 'first': nm[0] if nm else '', 'last': ' '.join(nm[1:]),
           'gender': {'M': 'Male', 'F': 'Female'}.get((a['SEX'] or '').upper(), ''), 'dob': dob.isoformat() if dob else '', 'nationality': 'Indian',
           'fatherSal': 'Mr.', 'father': clean_name(a['FNAME']), 'motherSal': 'Mrs.', 'mother': clean_name(a['MNAME']),
           'mobile': mob[0] if mob else '', 'mobiles': mob[1:] + lands, 'addr': addr, 'pin': pa['pin'], 'state': '',
           'cls': cls, 'sec': sec, 'roll': str(a['ROLLNO']) if a['ROLLNO'] else '', 'left': False, 'leftDate': '', 'leftReason': '', 'leftNote': '',
           'family': {'ward': {'admClass': '', 'admDate': ''}}, 'fee': {'type': 'Existing', 'cat': 'General', 'transport': False, 'route': '', 'stop': ''},
           'remarks': 'Imported from the old FoxPro program.' + (f' Old route: {a["ROOT"]}.' if a['ROOT'] else ''), 'addedBy': 'Old program import'}
    return rec, fixed, bool(a['DOB']), cls


def norm(s):
    return re.sub(r'[^A-Z]', '', (s or '').upper())


def similar(a, b, limit=0.8):
    import difflib
    return difflib.SequenceMatcher(None, a, b).ratio() >= limit


GENERIC = {'dinanagar', 'punjab', 'gurdaspur', 'road', 'near', 'ward', 'mohalla', 'colony', 'nagar', 'house', 'street', 'gali', 'opp', 'behind', 'village', 'distt', 'dist', 'teh', 'tehsil', 'chowk', 'market', 'bazar', 'bazaar', 'wali', 'city', 'main'}


def _tok1(s):
    t = re.sub(r'[^a-z ]', '', (s or '').lower()).split()
    return t[0] if t else ''


def _skel(t):
    t = re.sub(r'[^a-z]', '', (t or '').lower()).replace('w', 'v')
    if not t:
        return ''
    t = t[0] + re.sub(r'[aeiouyh]', '', t[1:])
    return re.sub(r'(.)\1+', r'\1', t)


def _tokeq(a, b):
    import difflib
    if not a or not b:
        return False
    if a == b or a.startswith(b) or b.startswith(a):
        return True
    sa, sb = _skel(a), _skel(b)
    return bool(sa and sb) and (sa == sb or (min(len(sa), len(sb)) >= 3 and (sa.startswith(sb) or sb.startswith(sa))) or difflib.SequenceMatcher(None, a, b).ratio() >= 0.8)


def veto(cur, rec):
    """Mother's name AND address both different = another child (the date of birth is never used: it was often a placeholder)."""
    m1, m2 = _tok1(cur.get('mother')), _tok1(rec.get('mother'))
    mcl = bool(m1 and m2) and not _tokeq(m1, m2)
    a1 = {t for t in re.findall(r'[a-z]{4,}', (cur.get('addr') or '').lower()) if t not in GENERIC}
    a2 = {t for t in re.findall(r'[a-z]{4,}', (rec.get('addr') or '').lower()) if t not in GENERIC}
    return mcl and bool(a1 and a2) and not (a1 & a2)


def three_fields(cur, rec):
    """The same child in two years: the name (and father, they gave the key) agree - a THIRD field must agree too (mother, address or mobile)."""
    if _tokeq(_tok1(cur.get('mother')), _tok1(rec.get('mother'))):
        return True
    a1 = {w for w in re.findall(r'[a-z]{4,}', (cur.get('addr') or '').lower()) if w not in GENERIC}
    a2 = {w for w in re.findall(r'[a-z]{4,}', (rec.get('addr') or '').lower()) if w not in GENERIC}
    if a1 & a2:
        return True
    m1, m2 = re.sub(r'\D', '', cur.get('mobile') or ''), re.sub(r'\D', '', rec.get('mobile') or '')
    return len(m1) >= 10 and m1 == m2


def _atoks(a):
    return {x for x in re.findall(r'[a-z]{4,}', (a or '').lower()) if x not in GENERIC}


def agree(c, rec):
    """How many of name, father, mother, address, mobile agree between a stored child / candidate `c` and a record. (the date of birth is never used)"""
    n = _tokeq(c.get('n1') or _tok1(c.get('first')), _tok1(rec.get('first')))
    f = _tokeq(c.get('f1') or _tok1(c.get('father')), _tok1(rec.get('father')))
    m = _tokeq(c.get('m1') or _tok1(c.get('mother')), _tok1(rec.get('mother')))
    ca = set(c.get('a') or _atoks(c.get('addr')))
    a = bool(ca and _atoks(rec.get('addr')) and ca & _atoks(rec.get('addr')))
    mob = bool(re.sub(r'\D', '', c.get('mob') or c.get('mobile') or '')[-10:]) and re.sub(r'\D', '', c.get('mob') or c.get('mobile') or '')[-10:] == re.sub(r'\D', '', rec.get('mobile') or '')[-10:]
    return n, f, m, a, mob


def same_enough(c, rec):
    """AT LEAST 3 agreeing fields (the given name is one of them) and not (mother AND address both different)."""
    n, f, m, a, mob = agree(c, rec)
    mcl = bool((c.get('m1') or _tok1(c.get('mother'))) and _tok1(rec.get('mother'))) and not m
    acl = bool(set(c.get('a') or _atoks(c.get('addr'))) and _atoks(rec.get('addr'))) and not a
    return n and not (mcl and acl) and sum([f, m, a, mob]) >= 2


def ident(first, last, father):
    return norm(f'{first} {last}'), norm(father)


class Command(BaseCommand):
    def add_arguments(self, p):
        p.add_argument('folder')
        p.add_argument('--session', required=True)
        p.add_argument('--also', action='append', default=[])
        p.add_argument('--authority', default='', help='json file {"name|father": admission no}: numbers that are the school\'s real lifetime numbers')
        p.add_argument('--apply', action='store_true')

    @staticmethod
    def _load(folder):
        folder = Path(folder)
        f = next((folder / n for n in ('A.DBF', 'a.dbf', 'A.dbf') if (folder / n).is_file()), None)
        if f is None:
            raise CommandError(f'A.DBF (the student file) was not found in {folder}')
        rows = [r for r in read_dbf(f, 'latin-1') if r.get('REGD') and (r.get('NAME') or '').strip()]
        adm_date = {}
        feef = next((folder / n for n in ('FEE.DBF', 'fee.dbf') if (folder / n).is_file()), None)
        if feef:
            for r in read_dbf(feef, 'latin-1'):
                if r.get('FLAG') in ('ADM', 'RE-ADM') and r.get('DATE') and r.get('REGD'):
                    adm_date[r['REGD']] = min(adm_date.get(r['REGD'], r['DATE']), r['DATE'])
        return f, rows, adm_date

    def handle(self, *a, **o):
        ses = o['session'].strip()
        if not re.match(r'^\d{4}-\d{4}$', ses):
            raise CommandError('--session must look like 2009-2010')
        f, rows, adm_date = self._load(o['folder'])
        filled = 0
        for extra in o['also']:                                   # other copies of the same year only FILL BLANKS of the main copy (same number and same name)
            _, orows, odate = self._load(extra)
            by = {r['REGD']: r for r in orows}
            for r in rows:
                x = by.get(r['REGD'])
                if x and norm(x['NAME']) == norm(r['NAME']):
                    for k, v in x.items():
                        if r.get(k) in (None, '') and v not in (None, ''):
                            r[k] = v
                            filled += 1
            for k, v in odate.items():
                adm_date.setdefault(k, v)
        authority = json.loads(Path(o['authority']).read_text(encoding='utf-8')) if o['authority'] else {}
        auth_nums = set(authority.values())
        in_ses = {s.adm_no for s in Student.objects.filter(session=ses)}
        idx, owned = {}, {}
        for pr in Person.objects.all():
            d = pr.data or {}
            idx.setdefault(ident(d.get('first'), d.get('last'), d.get('father')), []).append((pr.adm_no, d.get('dob') or ''))
            owned[pr.adm_no] = d
        todo, out, claimed = [], [], set()
        st = collections.Counter()
        for r in rows:
            rec, fixed, has_dob, cls = build(r, adm_date.get(r['REGD']))
            st['dob fixed'] += fixed
            st['no dob'] += 0 if has_dob else 1
            st['class not recognised'] += 0 if cls else 1
            st['admission date unknown'] += 0 if rec['date'] else 1
            key = ident(rec['first'], rec['last'], rec['father'])
            old_no = rec['adm']
            hit = next(((n, '') for n, dob in idx.get(key, []) if n not in claimed and same_enough(owned[n], rec)), None)
            ac = {'no': authority['|'.join(key)]} if '|'.join(key) in authority else None      # checked with 3 agreeing fields when the list was made
            if ac:                                                  # the child has a real lifetime number in the later program: use it in every year
                want = ac['no']
                if want in claimed:                                 # the same child entered twice in this old file
                    out.append([old_no, want, rec['first'], rec['last'], rec['father'], rec['mother'], rec['dob'], rec['cls'], rec['sec'], 'second entry of the same child in this year - skipped'])
                    continue
                hit = (want, '') if (want in owned and same_enough(owned[want], rec)) else None
            if hit:
                adm = hit[0]
                if adm in in_ses:
                    out.append([old_no, adm, rec['first'], rec['last'], rec['father'], rec['mother'], rec['dob'], rec['cls'], rec['sec'], 'already in this session - skipped'])
                    claimed.add(adm)
                    continue
                state = 'same child as in an earlier session' + ('' if adm == old_no else f' (old number {old_no} -> keeps {adm})')
                st['continuing'] += 1
            else:
                adm = ac['no'] if ac else old_no
                n = 1
                while adm in owned or adm in claimed or (not ac and adm in auth_nums):
                    n += 1
                    adm = f'{old_no}A{n}'                           # the old number belongs to another child: 'A2' at the end
                state = 'NEW child' if adm == old_no else (f'NEW child - lifetime number {adm}' if ac else f'NEW child - number {old_no} belongs to another child, given {adm}')
                st['new'] += 1
                st['number reused by another child'] += (not ac and adm != old_no)
            claimed.add(adm)
            rec['adm'] = adm
            if adm != old_no:
                rec['remarks'] += f' Number in the old program: {old_no}.'
            todo.append((rec, hit is not None))
            out.append([old_no, adm, rec['first'], rec['last'], rec['father'], rec['mother'], rec['dob'], rec['cls'], rec['sec'], state])
        csvp = settings.DATA_DIR / f'import_preview_{ses}.csv'
        with open(csvp, 'w', newline='', encoding='utf-8-sig') as fh:
            w = csv.writer(fh)
            w.writerow(['Old number', 'Admission No', 'First name', 'Last name', 'Father', 'Mother', 'DOB', 'Class', 'Sec', 'Result'])
            w.writerows(out)
        self.stdout.write(f'\nStudent file: {f}   ->   session {ses}\n')
        self.stdout.write(f'  students in the old file          : {len(rows)}' + (f'   (blanks filled from the other copies: {filled})' if o['also'] else ''))
        self.stdout.write(f'  will be ADDED to the session      : {len(todo)}   of them continuing children: {st["continuing"]}, new children: {st["new"]}')
        self.stdout.write(f'  already in this session (skipped) : {len(rows) - len(todo)}')
        self.stdout.write(f'  new child, number was used by another child (A2 added): {st["number reused by another child"]}')
        self.stdout.write(f'  date of birth fixed (19xx->20xx)  : {st["dob fixed"]}      without date of birth: {st["no dob"]}')
        self.stdout.write(f'  admission date unknown            : {st["admission date unknown"]}      class not recognised: {st["class not recognised"]}')
        self.stdout.write(f'  list of every row: {csvp}')
        if not o['apply']:
            self.stdout.write(self.style.WARNING('\nPREVIEW ONLY - nothing was saved. Add  --apply  to save.'))
            return
        call_command('backup_data', stdout=self.stdout)
        from sync.views import _put_kv, note
        with transaction.atomic():
            for rec, cont in todo:
                adm = rec['adm']
                if cont:                                           # a child already known: this year's details win where filled; a LATER session already stored keeps its own
                    cur = owned[adm]
                    later = Student.objects.filter(adm_no=adm, session__gt=ses).exists()
                    mine = person.split(rec)[0]
                    newp = dict(cur)
                    for k, v in mine.items():
                        if k == 'family':
                            continue
                        if v not in ('', None, [], {}) and (not later or cur.get(k) in ('', None, [], {})):
                            newp[k] = v
                    rec = person.merge(newp, person.split(rec)[1])
                    if later:
                        rec['date'] = rec.get('date', '')
                fields = store.student_fields(rec)
                stu = Student.objects.create(session=ses, adm_no=adm, **fields)
                note('adm', f'{ses}|{adm}')
                for other in stu.touched:
                    note('adm', f'{other}|{adm}')
            d = Doc.objects.filter(coll='kv', key='eacademics_sessions').first()
            cur = json.loads(store.load('eacademics_sessions', d.data)) if d else [{'id': '2026-2027'}]
            if not any(s.get('id') == ses for s in cur):
                cur.append({'id': ses, 'from': '', 'at': datetime.now().strftime('%d-%b-%Y, %I:%M %p'), 'carried': 0, 'imported': True})
                cur.sort(key=lambda s: s.get('id', ''))
                r = _put_kv('eacademics_sessions', json.dumps(cur), d.version if d else None)
                if r.status_code != 200:
                    raise CommandError('The session list could not be saved.')
        self.stdout.write(self.style.SUCCESS(f'\nDone: {len(todo)} students added to {ses}. Open the software, Switch Session -> {ses}.'))
