"""Replaces ALL school data (database + photos) with the contents of a file made by export_data. A safety backup is made first."""
import json
import shutil
import tempfile
import zipfile
from pathlib import Path

from django.conf import settings
from django.core.management import call_command
from django.core.management.base import BaseCommand, CommandError

from sync import dbtools

LABELS = [('students', 'Students'), ('receipts', 'Fee receipts'), ('attendance', 'Attendance rows'), ('marks', 'Marks'), ('gate_passes', 'Gate passes'), ('reference_entries', 'Reference register entries'), ('last_activity', 'Last activity')]


class Command(BaseCommand):
    def add_arguments(self, p):
        p.add_argument('file', nargs='?')
        p.add_argument('--yes', action='store_true')

    def _config(self, src):
        """config.env inside the file: copied when this PC has none; if this PC already has one it is NOT replaced (ports / addresses belong to the PC) - the file's copy is saved beside it."""
        if not src.is_file():
            return
        dst = settings.DATA_DIR / 'config.env'
        if not dst.exists():
            shutil.copy2(src, dst)
            self.stdout.write(self.style.SUCCESS('config.env was restored from the file.'))
        elif dst.read_bytes() != src.read_bytes():
            shutil.copy2(src, settings.DATA_DIR / 'config_from_backup.env')
            self.stdout.write(self.style.WARNING('This PC already has a config.env, so it was kept. The one from the file is saved as data\\config_from_backup.env.'))

    def handle(self, *a, **o):
        f = Path(o['file']) if o['file'] else None
        if f is None:
            zips = sorted((settings.DATA_DIR.parent / 'imports').glob('*.zip'), key=lambda p: p.stat().st_mtime)
            if not zips:
                raise CommandError('No data file found. Put the school_data_....zip file in the "imports" folder.')
            f = zips[-1]
        if not f.exists():
            raise CommandError(f'File not found: {f}')
        if not zipfile.is_zipfile(f):
            raise CommandError('This is not a school data file (it is not a valid zip).')
        with zipfile.ZipFile(f) as z:
            if 'meta.json' not in z.namelist():
                raise CommandError('This is not a school data file (meta.json is missing).')
            meta = json.loads(z.read('meta.json'))
            names = z.namelist()
            if any(n.startswith('/') or '..' in Path(n).parts for n in names):
                raise CommandError('The file is not safe.')
            if meta.get('engine') != dbtools.engine():
                raise CommandError(f'The file was made with {meta.get("engine")} but this school uses {dbtools.engine()}. Use the same database type on both PCs (see HELP.html, move_to_postgres).')
            unknown = set(meta.get('migrations', [])) - dbtools.known_migrations()
            if unknown:
                raise CommandError('The file comes from a NEWER program version. First install the newer version here (ERP.bat, option 3), then import again.')
            cur, new = dbtools.summary(), meta.get('summary', {})
            self.stdout.write(f'\nFile: {f.name}   (made {meta.get("created")}, program {meta.get("program_version")})\n')
            self.stdout.write(f'{"":28}{"THIS PC NOW":>20}{"IN THE FILE":>20}')
            for k, label in LABELS:
                self.stdout.write(f'{label:28}{str(cur.get(k, "")):>20}{str(new.get(k, "")):>20}')
            if cur['last_activity'] > new.get('last_activity', ''):
                self.stdout.write(self.style.WARNING('\nWARNING: this PC has NEWER work than the file. Importing will DELETE that newer work (a safety backup is made first).'))
            if not o['yes'] and input('\nType YES (capital letters) to replace ALL current school data with the file: ').strip() != 'YES':
                self.stdout.write('Cancelled. Nothing was changed.')
                return
            call_command('backup_data', stdout=self.stdout)
            with tempfile.TemporaryDirectory() as tmp:
                tmp = Path(tmp)
                z.extractall(tmp)
                dbtools.restore_db(tmp / meta['db_file'])
                if (tmp / 'media').exists() or meta.get('media', True) is not False:
                    if settings.MEDIA_ROOT.exists():
                        shutil.rmtree(settings.MEDIA_ROOT)
                    if (tmp / 'media').exists():
                        shutil.copytree(tmp / 'media', settings.MEDIA_ROOT)
                else:
                    self.stdout.write(self.style.WARNING('This backup has the database only (no photos / documents). The photos and documents already on this PC were kept.'))
                self._config(tmp / 'config.env')
        call_command('migrate', verbosity=0)
        call_command('normalize_data', stdout=self.stdout)
        self.stdout.write(self.style.SUCCESS('Done. The school data was replaced. Restart the server now.'))
