"""Moves data saved by an older version (whole documents) into the proper tables. Safe to run more than once."""
from django.core.management.base import BaseCommand
from django.db import transaction

from sync import mediafix, medianame, store
from sync.models import Doc, Student


class Command(BaseCommand):
    def handle(self, *a, **o):
        moved = adm = 0
        with transaction.atomic():
            for d in Doc.objects.filter(coll='adm'):
                ses, _, no = d.key.partition('|')
                if ses and no and isinstance(d.data, dict):
                    Student.objects.update_or_create(session=ses, adm_no=no, defaults=store.student_fields(d.data))
                    adm += 1
                d.delete()
            for d in Doc.objects.filter(coll='kv'):
                codec, _ = store.codec_for(d.key)
                if codec and not d.data.startswith(store.TAB):
                    new = store.store(d.key, d.data)
                    if new != d.data:
                        d.data = new
                        d.save(update_fields=['data'])
                        moved += 1
        files = mediafix.move_files()
        links = mediafix.fix_links()
        named = medianame.rename_all()
        self.stdout.write(f'{adm} admissions and {moved} documents moved into tables.' + (f' {files} photo files moved to data/media, {links} records updated.' if files or links else ''))
        if any(named):
            self.stdout.write(f'Photos renamed: {named[0]} admission records, {named[1]} school settings.')
