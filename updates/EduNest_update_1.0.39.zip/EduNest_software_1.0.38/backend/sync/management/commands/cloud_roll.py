"""One round of class roll call sync (ERP attendance <-> Reception app roll call) for today."""
from django.core.management.base import BaseCommand, CommandError

from sync import cloud_roll


class Command(BaseCommand):
    help = 'Sync today\'s class roll call between the cloud and the ERP attendance.'

    def handle(self, *args, **opts):
        cfg = cloud_roll.config()
        if not cfg:
            raise CommandError('Set CLOUD_ROLL_URL in data/config.env first (see HELP.html).')
        b = cloud_roll.Bridge(cfg)
        self.stdout.write('result : ' + str(b.run_once()))
        for k, v in getattr(b, 'last', {}).items():
            self.stdout.write(f'  {k}: {v}')
