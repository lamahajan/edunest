"""Bring biometric scans of the last few days into the ERP attendance (the server does today's by itself, live)."""
from datetime import datetime, timedelta

from django.core.management.base import BaseCommand, CommandError

from sync import cloud_att, cloud_gp


class Command(BaseCommand):
    help = 'Mark scanned students Present in the ERP attendance for the last N days (default 1 = today).'

    def add_arguments(self, parser):
        parser.add_argument('--days', type=int, default=1)

    def handle(self, *args, **opts):
        cfg = cloud_att.config()
        if not cfg:
            raise CommandError('Set CLOUD_ATT_URL in data/config.env first (see HELP.html).')
        now = datetime.now(cloud_gp.IST)
        days = [(now - timedelta(days=i)).strftime('%Y-%m-%d') for i in range(max(1, opts['days']))]
        self.stdout.write(str(cloud_att.Bridge(cfg).run_once(days)))
