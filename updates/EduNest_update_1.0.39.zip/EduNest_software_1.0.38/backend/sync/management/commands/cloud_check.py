"""Plain-language check of every cloud sync: is it set up, can the server reach the cloud database, and (for Gate Pass) why a pass was not sent."""
import os
import time
import urllib.error

from django.core.management.base import BaseCommand

from sync import cloud_att, cloud_fee, cloud_gp, cloud_result, cloud_roll
from sync.models import GatePass


def _test(fb, label, out):
    """Read, write and delete a small test node: tells a wrong address / secret / rule problem apart."""
    try:
        fb.get('')
    except urllib.error.HTTPError as e:
        out(f'   X {label}: the cloud answered "{e.code} {e.reason}". ' + ('The database secret / rules do not allow reading.' if e.code in (401, 403) else 'Check the address (URL) and the code.'))
        return False
    except Exception as e:
        out(f'   X {label}: cannot reach the cloud ({e}). Check the internet and the URL.')
        return False
    try:
        fb.put('_erp_check', {'at': int(time.time())})
        fb.delete('_erp_check')
    except Exception as e:
        out(f'   X {label}: can read but NOT write ({e}). The database secret is missing / wrong, or the rules block writing.')
        return False
    out(f'   OK {label}: reachable, readable and writable.')
    return True


class Command(BaseCommand):
    help = 'Check the cloud sync set-up (Gate Pass, Result portal, Online fee, Attendance) and say what is wrong.'

    def handle(self, *args, **opts):
        out = self.stdout.write
        out('\n1. Gate Pass  (ERP <-> Reception Suite / eGateSys)')
        cfg = cloud_gp.config()
        if not cfg:
            missing = [k for k in ('CLOUD_FB_URL', 'CLOUD_FB_CODE') if not os.environ.get(k, '').strip()]
            out('   OFF: not set up. Missing in data\\config.env: ' + ', '.join(missing) + '  (remove the # in front of the line, save, restart the server)')
        elif _test(cloud_gp.Firebase(cfg), f"{cfg['url']}/{cfg['code']}", out):
            from datetime import datetime
            today = datetime.now(cloud_gp.IST).strftime('%Y-%m-%d')
            rows = [dict(r.data) for r in GatePass.objects.filter(date=today)]
            out(f'   Passes cut in the ERP today ({today}): {len(rows)}')
            for e in rows[-8:]:
                why = 'goes to the cloud' if cloud_gp.approved(e) else 'WAITING FOR PRINCIPAL APPROVAL: sent only after it is approved'
                out(f"     - {e.get('id')}  {e.get('name', '')}  {e.get('time', '')}: {why}")
            if not rows:
                out('   (No pass for today in the ERP: check that the pass was saved and that this PC\'s date is right.)')
            try:
                cloud = cloud_gp.Firebase(cfg).get('passes') or {}
                here = [k for k, v in cloud.items() if isinstance(v, dict) and v.get('date') == today]
                out(f'   Passes for today found in the cloud under "{cfg["code"]}/passes": {len(here)}   (eGateSys must use the SAME code)')
            except Exception:
                pass

        out('\n2. Result portal')
        cfg = cloud_result.config()
        if not cfg:
            out('   OFF: set CLOUD_RESULT_URL and CLOUD_RESULT_SECRET (and CLOUD_RESULT_PATH) in data\\config.env to use it.')
        else:
            _test(cloud_gp.Firebase(cfg), f"{cfg['url']}/{cfg['code']}", out)

        out('\n3. Online fee (UPI-Redirect)')
        cfg = cloud_fee.config()
        if not cfg:
            out('   OFF: set CLOUD_FEE_DUE_* and CLOUD_FEE_TXN_* in data\\config.env to use it.')
        else:
            for k, name in (('due', 'Due List'), ('txn', 'Payments')):
                if cfg[k]:
                    _test(cloud_gp.Firebase(cfg[k]), f'{name} {cfg[k]["url"]}/{cfg[k]["code"]}', out)
                else:
                    out(f'   X {name}: not set up.')
            if not cfg.get('worker'):
                out('   (Optional) CLOUD_FEE_WORKER_URL + CLOUD_FEE_APP_TOKEN not set: old QR codes will not be closed automatically.')

        out('\n4. Biometric attendance')
        cfg = cloud_att.config()
        if not cfg:
            out('   OFF: set CLOUD_ATT_URL (and CLOUD_ATT_PATH if the worker has a code) in data\\config.env to use it.')
        else:
            _test(cloud_gp.Firebase(cfg), f"{cfg['url']}/{cfg['code']}", out)
        out('\n5. Class roll call (Reception app attendance)')
        cfg = cloud_roll.config()
        if not cfg:
            out('   OFF: set CLOUD_ROLL_URL (and CLOUD_ROLL_PATH if the worker has a code) in data\\config.env to use it (CLOUD_ROLL_WORKER_URL is optional).')
        else:
            _test(cloud_gp.Firebase(cfg), f"{cfg['url']}/{cfg['code']}", out)
            out('   ERP attendance -> cloud: ' + ('through the worker ' + cfg['worker'] + ' (bus tally and Sheet updated too)' if cfg['worker'] else 'written straight into the Firebase (no worker address: bus tally / Sheet history are not updated)'))
        out('\nAfter changing data\\config.env, restart the server (ERP.bat, option 2). The server window / data\\server.log shows "... cloud sync started".\n')
