"""Backup while the server is running: ONE zip (database + photos) in the "backups" folder. The same file can be restored with import_data."""
from django.core.management.base import BaseCommand

from sync import dbtools


class Command(BaseCommand):
    def handle(self, *a, **o):
        p = dbtools.make_backup()
        self.stdout.write(self.style.SUCCESS(f'Backup saved: {p}\nCopy this file to a pen drive or another PC as well.'))
