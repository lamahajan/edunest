"""Forgot the Administrator password? Run ERP.bat (option 8) on the server PC."""
import getpass
import json

from django.core.management.base import BaseCommand, CommandError
from rest_framework.authtoken.models import Token

from sync import perms
from sync.models import Change, Doc


class Command(BaseCommand):
    help = 'Set a new password for a user'

    def add_arguments(self, p):
        p.add_argument('username', nargs='?'); p.add_argument('--password')

    def handle(self, *a, **o):
        users = perms.load_users()
        if not users:
            raise CommandError('No users yet. Run setup_school first.')
        un = (o['username'] or input('Username to reset: ').strip()).lower()
        rec = next((u for u in users if str(u.get('username', '')).lower() == un), None)
        if not rec:
            raise CommandError('Users: ' + ', '.join(str(u.get('username')) for u in users) + '. No such username: ' + un)
        pw = o['password'] or getpass.getpass('New password (at least 8 characters): ')
        if len(pw) < 8:
            raise CommandError('The password needs at least 8 characters.')
        rec['pass'] = perms.hash_h1(pw)
        rec['active'] = True
        d = Doc.objects.get(coll='kv', key=perms.USERS_KEY)
        d.data, d.version = json.dumps(users), d.version + 1
        d.save()
        Change.objects.create(coll='kv', key=perms.USERS_KEY, action='put')
        Token.objects.filter(user__username=un).delete()
        self.stdout.write(self.style.SUCCESS(f'Password changed for "{un}".'))
