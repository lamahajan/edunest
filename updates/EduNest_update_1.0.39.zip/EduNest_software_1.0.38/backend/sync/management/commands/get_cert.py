"""Trusted https for every device: a real certificate (Let's Encrypt) for a name that points to this PC's address on the school network.
Needs ERP_DOMAIN + a DNS token in data/config.env (see HELP.html). Renewal is automatic (serve.py checks twice a day)."""
import datetime as dt
import importlib.util
import os
import shutil
import subprocess
import sys
import urllib.parse
import urllib.request

from cryptography import x509
from django.conf import settings
from django.core.management.base import BaseCommand, CommandError


def _has(module):
    return importlib.util.find_spec(module) is not None

import json
import socket
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[3]))
import acmedns_client  # noqa: E402

from .make_cert import local_addresses

RUN = "import sys; from certbot.main import main; sys.exit(main(sys.argv[1:]))"


def primary_ip():
    ips = sorted(i for i in local_addresses()[0] if not i.startswith('127.'))
    import socket
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); s.connect(('10.255.255.255', 1)); ip = s.getsockname()[0]; s.close()
        return ip
    except OSError:
        return ips[0] if ips else ''


def update_duckdns(domain, token, ip):
    sub = domain.split('.duckdns.org')[0]
    url = 'https://www.duckdns.org/update?' + urllib.parse.urlencode({'domains': sub, 'token': token, 'ip': ip})
    with urllib.request.urlopen(url, timeout=20) as r:
        return r.read().decode().strip()


def days_left(path):
    try:
        c = x509.load_pem_x509_certificate(path.read_bytes())
        return (c.not_valid_after_utc - dt.datetime.now(dt.timezone.utc)).days
    except (OSError, ValueError):
        return -1


class Command(BaseCommand):
    help = 'Get / renew the trusted https certificate'

    def add_arguments(self, p):
        p.add_argument('--force', action='store_true')

    def handle(self, *a, **o):
        env = os.environ
        domain = env.get('ERP_DOMAIN', '').strip().lower()
        if not domain:
            self.stdout.write('Trusted https is not set up (no ERP_DOMAIN in data/config.env). Using the school certificate instead.')
            return
        dns = env.get('ERP_DNS', 'duckdns').strip().lower()
        email = env.get('ERP_ACME_EMAIL', '').strip()
        data = settings.DATA_DIR
        certs, le = data / 'certs', data / 'letsencrypt'
        certs.mkdir(parents=True, exist_ok=True)
        ip = primary_ip()
        if dns == 'duckdns':                                     # keep the name pointing at this PC even if the router gives it a new address
            token = env.get('DUCKDNS_TOKEN', '').strip()
            if not token:
                raise CommandError('DUCKDNS_TOKEN is missing in data/config.env')
            try:
                self.stdout.write(f'DuckDNS: {domain} -> {ip}: ' + update_duckdns(domain, token, ip))
            except Exception as e:
                self.stderr.write(f'Could not update DuckDNS ({e}). Is the internet working?')
        live = le / 'live' / domain
        if not o['force'] and days_left(live / 'fullchain.pem') > 30:
            self._publish(live, certs)
            self.stdout.write(f'Trusted certificate is valid for {days_left(live / "fullchain.pem")} more days.')
            return
        if not email:
            raise CommandError('ERP_ACME_EMAIL is missing in data/config.env (Let\'s Encrypt needs an email address)')
        cert_env = None
        args = ['certonly', '--non-interactive', '--agree-tos', '-m', email, '-d', domain, '--config-dir', str(le), '--work-dir', str(data / 'le-work'),
                '--logs-dir', str(data / 'le-logs'), '--keep-until-expiring', '--cert-name', domain]
        if dns == 'duckdns':
            args += ['--authenticator', 'dns-duckdns', '--dns-duckdns-token', env.get('DUCKDNS_TOKEN', '').strip(), '--dns-duckdns-propagation-seconds', '45']
        elif dns == 'cloudflare':
            if not _has('certbot_dns_cloudflare'):
                raise CommandError('Cloudflare DNS is not part of this build. Use ERP_DNS=acmedns (works with any domain) or duckdns.')
            ini = data / 'cloudflare.ini'
            ini.write_text('dns_cloudflare_api_token = ' + env.get('CLOUDFLARE_API_TOKEN', '').strip() + '\n')
            try:
                os.chmod(ini, 0o600)
            except OSError:
                pass
            args += ['--authenticator', 'dns-cloudflare', '--dns-cloudflare-credentials', str(ini), '--dns-cloudflare-propagation-seconds', '30']
        elif dns == 'acmedns':                       # domain at a host without a DNS API (e.g. Wix): one CNAME record, set once
            base = env.get('ERP_ACMEDNS_URL', 'https://auth.acme-dns.io')
            cf = data / 'acmedns.json'
            if not cf.exists():
                try:
                    cf.write_text(json.dumps(acmedns_client.register(base)))
                except Exception as e:
                    raise CommandError(f'Could not register with acme-dns ({e}). Is the internet working?')
                try:
                    os.chmod(cf, 0o600)
                except OSError:
                    pass
            creds = json.loads(cf.read_text())
            labels = domain.split('.')
            keep = 3 if '.'.join(labels[-2:]) in ('co.in', 'org.in', 'ac.in', 'edu.in', 'net.in', 'gov.in', 'nic.in', 'firm.in', 'gen.in', 'ind.in') else 2
            host = '_acme-challenge' + ('.' + '.'.join(labels[:-keep]) if len(labels) > keep else '')
            if acmedns_client.cname_ok('_acme-challenge.' + domain, creds['fulldomain']) is False:
                a_host = '.'.join(labels[:-keep]) or '@'
                raise CommandError('ONE-TIME STEP. In Wix open  Domains > your domain > Manage DNS Records  and add these TWO records:\n'
                                   f'  1) Type : A      Host : {a_host}      Value: {ip}      (this PC - if an A record for {a_host} already exists, change its Value to this)\n'
                                   f'  2) Type : CNAME  Host : {host}      Value: {creds["fulldomain"]}      (only for the certificate)\n'
                                   'The A record is what lets other devices find this PC; without it they show "site can\'t be reached".\n'
                                   'Wait 5-10 minutes, then run ERP.bat > More > option 5 again.')
            try:
                if socket.gethostbyname(domain) != ip:
                    self.stderr.write(f'Note: {domain} points to {socket.gethostbyname(domain)} but this PC is {ip}. Fix the A record (Host: {labels[0]}) in your domain settings.')
            except OSError:
                self.stderr.write(f'Note: {domain} does not resolve yet. Add the A record (Host: {labels[0]}, Value: {ip}) in your domain settings.')
            hook = Path(__file__).resolve().parents[3] / 'acmedns_hook.py'
            args += ['--manual', '--preferred-challenges', 'dns', '--disable-hook-validation', '--manual-auth-hook', ('& ' if os.name == 'nt' else '') + f'"{sys.executable}" "{hook}"']   # certbot runs hooks through PowerShell on Windows: quoted path needs &
            cert_env = dict(os.environ, ACMEDNS_FILE=str(cf), ACMEDNS_URL=base)
        else:
            raise CommandError('ERP_DNS must be duckdns, cloudflare or acmedns')
        if env.get('ERP_ACME_STAGING') == '1':
            args.append('--test-cert')
        self.stdout.write('Asking Let\'s Encrypt for the certificate (about 1-2 minutes) ...')
        r = subprocess.run([sys.executable, '-c', RUN] + args, capture_output=True, text=True, env=cert_env)
        if r.returncode or not (live / 'fullchain.pem').exists():
            tail = (r.stdout + r.stderr).strip().splitlines()[-6:]
            raise CommandError('The certificate could not be obtained:\n  ' + '\n  '.join(tail) + '\nCheck the internet connection, the domain name and the token in data/config.env.')
        self._publish(live, certs)
        self.stdout.write(self.style.SUCCESS(f'Done. Open https://{domain} on any device - no certificate to install.'))

    def _publish(self, live, certs):
        shutil.copyfile(live / 'fullchain.pem', certs / 'trusted.crt')
        shutil.copyfile(live / 'privkey.pem', certs / 'trusted.key')
        try:
            os.chmod(certs / 'trusted.key', 0o600)
        except OSError:
            pass
