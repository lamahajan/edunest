"""Copies everything from the old SQLite file (data/db.sqlite3) into the PostgreSQL database set in data/config.env."""
from django.conf import settings
from django.contrib.auth import get_user_model
from django.core.management import call_command
from django.core.management.base import BaseCommand, CommandError
from django.core.management.color import no_style
from django.db import connection, connections, transaction
from rest_framework.authtoken.models import Token

from sync import models as m


class Command(BaseCommand):
    def handle(self, *a, **o):
        if 'postgresql' not in settings.DATABASES['default']['ENGINE']:
            raise CommandError('PostgreSQL is not configured. Put the POSTGRES_* lines in data/config.env first (see HELP.html).')
        old = settings.DATA_DIR / 'db.sqlite3'
        if not old.exists():
            raise CommandError(f'No old database found at {old}')
        connections.databases['old'] = {**settings.DATABASES['default'], 'ENGINE': 'django.db.backends.sqlite3', 'NAME': str(old), 'OPTIONS': {}, 'USER': '', 'PASSWORD': '', 'HOST': '', 'PORT': ''}
        call_command('migrate', verbosity=0)
        order = [get_user_model(), Token, m.Doc, m.ReceiptDoc, m.Change, m.Person, m.Student, m.GatePass, m.RefEntry, m.AttendanceMark, m.Mark, m.CoGrade]
        with transaction.atomic():
            if any(mod.objects.exists() for mod in order if mod is not get_user_model()) :
                raise CommandError('The PostgreSQL database already has school data. Use an empty database.')
            get_user_model().objects.all().delete()
            for mod in order:
                rows = list(mod.objects.using('old').all().iterator(chunk_size=2000))
                mod.objects.bulk_create(rows, batch_size=500)
                self.stdout.write(f'{mod.__name__}: {len(rows)}')
            with connection.cursor() as c:
                for sql in connection.ops.sequence_reset_sql(no_style(), order):
                    c.execute(sql)
        self.stdout.write(self.style.SUCCESS('Done. Everything is now in PostgreSQL. Restart the server.'))
