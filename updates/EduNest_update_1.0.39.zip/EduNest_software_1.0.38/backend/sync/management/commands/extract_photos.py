"""One-off: moves photos/PDFs already stored inside records (as data URLs) into files under MEDIA_ROOT."""
import base64
import hashlib
import json
import re

from django.core.management.base import BaseCommand
from django.db import transaction

from sync.models import Doc
from sync.views import EXT, media_path, note

RE = re.compile(r'data:(image/(?:jpeg|png|webp|gif)|application/pdf);base64,([A-Za-z0-9+/=]{1500,})')


class Command(BaseCommand):
    def handle(self, *a, **o):
        files = docs = 0

        def sub(m):
            nonlocal files
            raw = base64.b64decode(m.group(2))
            ext = EXT[m.group(1)]
            name = hashlib.sha256(raw).hexdigest()[:32]
            p = media_path(name, ext)
            p.parent.mkdir(parents=True, exist_ok=True)
            if not p.exists():
                p.write_bytes(raw)
                files += 1
            return f'/media/{name}.{ext}'

        for d in Doc.objects.filter(coll__in=['kv', 'adm']):
            txt = json.dumps(d.data)
            new = RE.sub(sub, txt)
            if new != txt:
                with transaction.atomic():
                    d.data, d.version = json.loads(new), d.version + 1
                    d.save()
                    note(d.coll, d.key)
                docs += 1
        self.stdout.write(f'{files} files written, {docs} records updated')
