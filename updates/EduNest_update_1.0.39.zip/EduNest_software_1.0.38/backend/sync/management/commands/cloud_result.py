"""Result portal <-> ERP.  `push` sends classes/subjects/students to the portal, `pull` brings the teachers' marks into the ERP."""
from django.core.management.base import BaseCommand, CommandError

from sync import cloud_result


class Command(BaseCommand):
    help = 'push: ERP setup + students -> Result portal.  pull: marks entered by teachers -> ERP.'

    def add_arguments(self, parser):
        parser.add_argument('what', choices=['push', 'pull'])
        parser.add_argument('--new-session', action='store_true', help='push only: clear the portal marks (start of a new session; pull first!)')

    def handle(self, *args, **opts):
        cfg = cloud_result.config()
        if not cfg:
            raise CommandError('Set CLOUD_RESULT_URL and CLOUD_RESULT_SECRET in data/config.env first (see HELP.html).')
        b = cloud_result.Bridge(cfg)
        try:
            self.stdout.write(str(b.push(opts['new_session']) if opts['what'] == 'push' else b.pull()))
        except ValueError as e:
            raise CommandError(str(e))
