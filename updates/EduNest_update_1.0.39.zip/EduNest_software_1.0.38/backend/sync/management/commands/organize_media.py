"""Builds a readable copy of all uploaded photos / documents:  media_named/<AdmNo>_<Student name>/<AdmNo>_<Name>_<Document>.jpg

The real files in data/media keep their content-hash names (that is what stops duplicates and keeps records safe).
This command only makes extra links (hard links: no extra disk space, plain copies if the drive does not allow links) with proper names.
It can be run any time; the media_named folder is rebuilt from scratch and nothing else is touched."""
import json
import os
import re
import shutil
from pathlib import Path

from django.conf import settings
from django.core.management.base import BaseCommand

from sync.models import Doc, Student

URL = re.compile(r'/media/(?:f/)?([0-9a-z]{16,64})\.(jpg|png|webp|gif|pdf)')
ADM_DOCS = ['Birth Certificate', 'Aadhaar Card (Student)', 'Aadhaar Card (Father)', 'Aadhaar Card (Mother)', 'Transfer Certificate',
            'Previous Class Report Card', 'Passport Size Photographs', 'Address Proof', 'Caste Certificate (if applicable)',
            'EWS Certificate (if applicable)', 'Medical / Fitness Certificate', 'PEN / APAAR ID Proof', 'Sibling Proof (if applicable)']
PHOTO = {'ward': 'Student photo', 'father': 'Father photo', 'mother': 'Mother photo', 'guardian': 'Guardian photo'}
MARK = '.made_by_erp_organize_media'


def clean(s, n=60):
    s = re.sub(r'[\\/:*?"<>|\r\n\t]+', ' ', str(s or ''))
    s = re.sub(r'\s+', ' ', s).strip(' .')
    return s[:n].strip(' .')


def walk(node, path=()):
    """yields (path, container, url-match) for every stored file reference inside a record."""
    if isinstance(node, str):
        for m in URL.finditer(node):
            yield path, m
        return
    if isinstance(node, dict):
        for k, v in node.items():
            yield from walk(v, path + (str(k),))
    elif isinstance(node, list):
        for i, v in enumerate(node):
            yield from walk(v, path + (str(i),))


def label_for(path, rec):
    """Human name of the file from where it sits in the admission record."""
    p = list(path)
    if p[:1] == ['photos'] and len(p) >= 2:
        return PHOTO.get(p[1], 'Photo ' + p[1])
    if p[:1] == ['docFiles'] and len(p) >= 2:
        f = (rec.get('docFiles') or {}).get(p[1]) or {}
        try:
            return ADM_DOCS[int(p[1])]
        except (ValueError, IndexError):
            return clean(os.path.splitext(str(f.get('name', '')))[0]) or 'Document ' + p[1]
    if p[:2] == ['prev', 'tcFile']:
        return 'Transfer Certificate'
    return ' '.join(x for x in p if x not in ('data', 'url', 'file')) or 'File'


class Command(BaseCommand):
    help = 'Make media_named/ with proper file names (links to the real files).'

    def add_arguments(self, parser):
        parser.add_argument('--out', help='output folder (default: data/media_named)')

    def handle(self, *a, **o):
        root = Path(settings.MEDIA_ROOT)
        out = Path(o.get('out') or root.parent / 'media_named')
        if out.exists():
            if not (out / MARK).exists():
                self.stderr.write(f'{out} already exists and was not made by this command - nothing done.')
                return
            shutil.rmtree(out)
        out.mkdir(parents=True)
        (out / MARK).write_text('This folder is rebuilt by organize_media. The real files are in data/media.\n')

        used, seen, n_link, missing = set(), set(), 0, 0

        def put(folder, base, h, ext):
            nonlocal n_link, missing
            src = next((c for c in (root / f'{h}.{ext}', root / 'f' / f'{h}.{ext}') if c.exists()), root / f'{h}.{ext}')
            if not src.exists():
                missing += 1
                return
            if (folder, h) in seen:
                return
            seen.add((folder, h))
            d = out / folder
            d.mkdir(parents=True, exist_ok=True)
            name, i = f'{base}.{ext}', 2
            while (folder, name.lower()) in used:
                name, i = f'{base} ({i}).{ext}', i + 1
            used.add((folder, name.lower()))
            try:
                os.link(src, d / name)
            except OSError:
                shutil.copy2(src, d / name)
            n_link += 1

        linked_hashes = set()
        for st in Student.objects.all().order_by('adm_no', 'session'):
            who = clean(' '.join(x for x in (st.first_name, st.middle_name, st.last_name) if x)) or 'Student'
            folder = clean(f'{st.adm_no}_{who}', 80)
            for path, m in walk(st.data):
                h, ext = m.group(1), m.group(2)
                linked_hashes.add(h)
                put(folder, clean(f'{st.adm_no}_{who}_{label_for(path, st.data)}', 120), h, ext)

        for d in Doc.objects.filter(coll__in=['kv', 'adm']):          # photos that belong to other records (gate pass, registers, ...)
            data = d.data
            if isinstance(data, dict) and isinstance(data.get('v'), str):
                try:
                    data = json.loads(data['v'])
                except ValueError:
                    data = data['v']
            keyname = clean(d.key.replace('eacademics_', ''), 40) or 'other'
            for path, m in walk(data):
                h, ext = m.group(1), m.group(2)
                if h in linked_hashes:
                    continue
                linked_hashes.add(h)
                put('_Other records/' + keyname, clean(f'{keyname} ' + ' '.join(path) + f' {h[:6]}', 120), h, ext)

        left = 0
        for fdir in (root, root / 'f'):
            if not fdir.exists():
                continue
            for f in fdir.iterdir():
                if f.is_file() and re.fullmatch(r'[0-9a-z]{16,64}', f.stem) and f.suffix.lstrip('.') in ('jpg', 'png', 'webp', 'gif', 'pdf') and f.stem not in linked_hashes:
                    left += 1
                    put('_Not linked to any record', f.stem[:12], f.stem, f.suffix.lstrip('.'))
        self.stdout.write(f'{n_link} files organised into {out}  ({left} not linked to any record, {missing} listed in records but missing on disk)')
