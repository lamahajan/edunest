"""One file with the school's data (database + photos) to take to another PC, e.g. to work on it at home."""
import json
import shutil
import tempfile
import zipfile
from datetime import datetime
from pathlib import Path

from django.conf import settings
from django.core.management.base import BaseCommand

from sync import dbtools


class Command(BaseCommand):
    def add_arguments(self, p):
        p.add_argument('--out')

    def handle(self, *a, **o):
        ts = datetime.now().strftime('%Y%m%d_%H%M')
        out = Path(o['out']) if o['out'] else settings.DATA_DIR.parent / 'exports' / f'school_data_{ts}.zip'
        out.parent.mkdir(parents=True, exist_ok=True)
        ver = settings.DATA_DIR.parent / 'VERSION'
        meta = dbtools.write_export_zip(out)
        self.stdout.write(self.style.SUCCESS(f'Data file saved: {out}\n{meta["summary"]}'))
