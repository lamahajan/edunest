"""Creates (once) the school's own certificate authority and a server certificate for this PC's addresses,
so the app can be opened with https:// (needed for the camera on other computers).
The authority stays the same forever, so PCs that installed it never have to install it again."""
import datetime as dt
import ipaddress
import os
import socket

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.x509.oid import ExtendedKeyUsageOID, NameOID
from django.conf import settings
from django.core.management.base import BaseCommand

PEM = serialization.Encoding.PEM
NOENC = serialization.NoEncryption()


def local_addresses():
    ips, names = {'127.0.0.1'}, {'localhost'}
    host = socket.gethostname()
    names.add(host)
    try:
        ips.update(socket.gethostbyname_ex(host)[2])
    except OSError:
        pass
    try:                                    # the address used to reach the network (no data is sent)
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('10.255.255.255', 1))
        ips.add(s.getsockname()[0])
        s.close()
    except OSError:
        pass
    for extra in filter(None, (x.strip() for x in os.environ.get('ERP_EXTRA_NAMES', '').split(','))):
        try:
            ips.add(str(ipaddress.ip_address(extra)))
        except ValueError:
            names.add(extra)
    return ips, names


def _key():
    return rsa.generate_private_key(public_exponent=65537, key_size=2048)


def _save(path, data):
    path.write_bytes(data)
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass


class Command(BaseCommand):
    help = 'Create / refresh the https certificate'

    def handle(self, *a, **o):
        d = settings.DATA_DIR / 'certs'
        d.mkdir(parents=True, exist_ok=True)
        now = dt.datetime.now(dt.timezone.utc)
        # ---- certificate authority (created once)
        if not (d / 'ca.crt').exists():
            ca_key = _key()
            name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, 'School ERP local CA'), x509.NameAttribute(NameOID.ORGANIZATION_NAME, 'School ERP')])
            ca = (x509.CertificateBuilder().subject_name(name).issuer_name(name).public_key(ca_key.public_key())
                  .serial_number(x509.random_serial_number()).not_valid_before(now - dt.timedelta(days=1)).not_valid_after(now + dt.timedelta(days=3650))
                  .add_extension(x509.BasicConstraints(ca=True, path_length=0), critical=True)
                  .add_extension(x509.KeyUsage(digital_signature=True, key_cert_sign=True, crl_sign=True, content_commitment=False, key_encipherment=False,
                                               data_encipherment=False, key_agreement=False, encipher_only=False, decipher_only=False), critical=True)
                  .sign(ca_key, hashes.SHA256()))
            _save(d / 'ca.key', ca_key.private_bytes(PEM, serialization.PrivateFormat.TraditionalOpenSSL, NOENC))
            (d / 'ca.crt').write_bytes(ca.public_bytes(PEM))
            self.stdout.write('Created the school certificate authority.')
        ca_key = serialization.load_pem_private_key((d / 'ca.key').read_bytes(), None)
        ca = x509.load_pem_x509_certificate((d / 'ca.crt').read_bytes())
        # ---- server certificate for this PC's addresses (kept while it still covers them)
        ips, names = local_addresses()
        old = None
        if (d / 'server.crt').exists() and (d / 'server.key').exists():
            old = x509.load_pem_x509_certificate((d / 'server.crt').read_bytes())
            try:
                san = old.extensions.get_extension_for_class(x509.SubjectAlternativeName).value
                ips |= {str(i) for i in san.get_values_for_type(x509.IPAddress)}
                names |= set(san.get_values_for_type(x509.DNSName))
            except x509.ExtensionNotFound:
                pass
        ips, names = sorted(ips)[:20], sorted(names)[:20]
        want = {str(i) for i in ips} | set(names)
        have = set()
        if old is not None:
            try:
                san = old.extensions.get_extension_for_class(x509.SubjectAlternativeName).value
                have = {str(i) for i in san.get_values_for_type(x509.IPAddress)} | set(san.get_values_for_type(x509.DNSName))
            except x509.ExtensionNotFound:
                pass
        fresh = old is not None and have == want and old.not_valid_after_utc > now + dt.timedelta(days=30) and old.issuer == ca.subject
        if not fresh:
            key = _key()
            cert = (x509.CertificateBuilder().subject_name(x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, 'School ERP server')])).issuer_name(ca.subject)
                    .public_key(key.public_key()).serial_number(x509.random_serial_number()).not_valid_before(now - dt.timedelta(days=1)).not_valid_after(now + dt.timedelta(days=800))
                    .add_extension(x509.SubjectAlternativeName([x509.DNSName(n) for n in names] + [x509.IPAddress(ipaddress.ip_address(i)) for i in ips]), critical=False)
                    .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
                    .add_extension(x509.ExtendedKeyUsage([ExtendedKeyUsageOID.SERVER_AUTH]), critical=False)
                    .sign(ca_key, hashes.SHA256()))
            _save(d / 'server.key', key.private_bytes(PEM, serialization.PrivateFormat.TraditionalOpenSSL, NOENC))
            (d / 'server.crt').write_bytes(cert.public_bytes(PEM))
            self.stdout.write('Created the https certificate for: ' + ', '.join(ips + names))
        else:
            self.stdout.write('https certificate is up to date.')
