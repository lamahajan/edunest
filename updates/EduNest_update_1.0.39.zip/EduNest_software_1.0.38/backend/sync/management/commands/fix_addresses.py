"""Cleans the written address of every child (no Vill / V.P.O / P.O, proper capitals) and fills the PIN code (and district / state when empty) from the internet.

    python manage.py fix_addresses                 (preview: nothing is saved; data/address_review.csv shows every change and every address that needs a person's look)
    python manage.py fix_addresses --apply         (saves; a backup is made first)
Options: --state Punjab   --districts Gurdaspur,Pathankot   (the place names are searched in this state; if two PIN codes fit, these districts decide)
         --recheck  (also look up children that already have a PIN code and report where it differs)
"""
import csv

from django.conf import settings
from django.core.management import call_command
from django.core.management.base import BaseCommand
from django.db import transaction
from django.db.models import F

from sync import addrfix
from sync.models import Person, Student


class Command(BaseCommand):
    def add_arguments(self, p):
        p.add_argument('--apply', action='store_true')
        p.add_argument('--state', default='Punjab')
        p.add_argument('--districts', default='Gurdaspur,Pathankot')
        p.add_argument('--recheck', action='store_true')

    def handle(self, *a, **o):
        pin = addrfix.PinLookup(settings.DATA_DIR / 'pin_cache.json', o['state'], [d.strip() for d in o['districts'].split(',') if d.strip()])
        changes, review, stats = [], [], {'address cleaned': 0, 'PIN filled': 0, 'PIN differs (not changed)': 0, 'needs a look': 0, 'nothing to do': 0}
        for pr in Person.objects.order_by('adm_no'):
            d = dict(pr.data or {})
            new = dict(d)
            name = ' '.join(x for x in (d.get('first'), d.get('last')) if x)
            parsed = addrfix.parse_address(d.get('addr'), d.get('city') if d.get('city') and not d.get('city') == o['state'] else '')
            addr = parsed['addr']
            if addr != (d.get('addr') or ''):
                new['addr'] = addr
                stats['address cleaned'] += 1
            cur = str(d.get('pin') or '').strip() or parsed['pin']
            note = ''
            if not cur or o['recheck']:
                found = None
                for nm in addrfix.lookup_names(addr):
                    found = pin.find(nm)
                    if found:
                        break
                if found and not cur:
                    new['pin'] = found['pin']
                    if not d.get('city'):
                        new['city'] = found['district']
                    if not d.get('state'):
                        new['state'] = found['state']
                    stats['PIN filled'] += 1
                    note = f'PIN {found["pin"]} ({found["how"]})'
                elif found and cur and cur != found['pin']:
                    stats['PIN differs (not changed)'] += 1
                    note = f'has {cur}, internet says {found["pin"]}'
                elif not found and not cur:
                    stats['needs a look'] += 1
                    note = 'PIN not found / not clear' + (' (no internet?)' if pin.errors else '')
            elif parsed['pin'] and not d.get('pin'):
                new['pin'] = parsed['pin']
            if new == d:
                stats['nothing to do'] += 1
                continue
            changes.append((pr, new))
            review.append([pr.adm_no, name, d.get('addr', ''), new.get('addr', ''), new.get('pin', ''), new.get('city', ''), note])
        for pr in Person.objects.order_by('adm_no'):                       # addresses that stay without a PIN are listed too
            d = pr.data or {}
            if not d.get('pin') and not any(r[0] == pr.adm_no for r in review):
                review.append([pr.adm_no, ' '.join(x for x in (d.get('first'), d.get('last')) if x), d.get('addr', ''), d.get('addr', ''), '', d.get('city', ''), 'no PIN, nothing found'])
        out = settings.DATA_DIR / 'address_review.csv'
        with open(out, 'w', newline='', encoding='utf-8-sig') as fh:
            w = csv.writer(fh)
            w.writerow(['Adm No', 'Name', 'Address before', 'Address after', 'PIN', 'District', 'Note'])
            w.writerows(review)
        for k, v in stats.items():
            self.stdout.write(f'  {k:28}: {v}')
        if pin.errors:
            self.stdout.write(self.style.WARNING(f'  The PIN service could not be reached {pin.errors} time(s): check the internet and run again (answers already received are kept).'))
        self.stdout.write(f'  list of every change: {out}')
        if not o['apply']:
            self.stdout.write(self.style.WARNING('\nPREVIEW ONLY - nothing was saved. Add  --apply  to save.'))
            return
        call_command('backup_data', stdout=self.stdout)
        from sync.views import note
        with transaction.atomic():
            for pr, new in changes:
                pr.data, pr.version = new, pr.version + 1
                pr.save()
                for st in Student.objects.filter(adm_no=pr.adm_no):
                    Student.objects.filter(pk=st.pk).update(version=F('version') + 1)
                    note('adm', f'{st.session}|{pr.adm_no}')
        self.stdout.write(self.style.SUCCESS(f'\nDone: {len(changes)} children updated.'))
