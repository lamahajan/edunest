"""One admission number = ONE copy of the child's / family's details (table Person). Each academic session keeps only its own small record
(class, section, roll, house, fee, left-status ... = Student.sdata). split() / merge() convert between the two and the full admission form the UI uses."""

# What belongs to the CHILD / FAMILY (the same in every academic session).
PERSONAL_TOP = ('regNo', 'pen', 'apaar', 'first', 'middle', 'last', 'gender', 'dob', 'nationality', 'motherTongue', 'aadhar', 'castCat', 'minority',
                'fatherSal', 'father', 'motherSal', 'mother', 'mobile', 'mobiles', 'addr', 'city', 'state', 'pin', 'ews', 'onlyChild', 'onlyGirl', 'bpl',
                'photos', 'docFiles', 'docV', 'checklist', 'checkRemark', 'prev')
SESSION_FAMILY = ('admClass', 'admDate')          # family.ward.* items that describe the admission into a class, not the person


def split(rec):
    """full admission record -> (personal part, session part)"""
    rec = rec or {}
    personal = {k: rec[k] for k in PERSONAL_TOP if k in rec}
    sess = {k: v for k, v in rec.items() if k not in PERSONAL_TOP and k != 'family'}
    if 'family' in rec:
        fam = rec['family']
        if isinstance(fam, dict):
            pf, sf = {}, {}
            for k, v in fam.items():
                if k == 'ward' and isinstance(v, dict):
                    pf[k] = {a: b for a, b in v.items() if a not in SESSION_FAMILY}
                    sw = {a: b for a, b in v.items() if a in SESSION_FAMILY}
                    if sw:
                        sf['ward'] = sw
                else:
                    pf[k] = v
            personal['family'] = pf
            if sf:
                sess['family'] = sf
        else:
            personal['family'] = fam
    return personal, sess


def merge(personal, sess):
    """(personal part, session part) -> full admission record"""
    personal, sess = personal or {}, sess or {}
    rec = dict(personal)
    rec.update({k: v for k, v in sess.items() if k != 'family'})
    fp, fs = personal.get('family'), sess.get('family')
    if isinstance(fs, dict) or isinstance(fp, dict):
        fam = dict(fp) if isinstance(fp, dict) else {}
        for k, v in (fs or {}).items():
            fam[k] = {**(fam.get('ward') or {}), **v} if (k == 'ward' and isinstance(v, dict)) else v
        rec['family'] = fam
    return rec


def clearly_different(cur, rec):
    """Is `rec` clearly another child than the stored personal data `cur` (nothing agrees: not the given name, not the father, not the mother)? Used when a NEW admission wants a number that exists."""
    import difflib
    import re
    def t1(x):
        t = re.sub(r'[^a-z ]', '', str(x or '').lower()).split()
        return t[0] if t else ''
    def eq(a, b):
        return bool(a and b) and (a.startswith(b) or b.startswith(a) or difflib.SequenceMatcher(None, a, b).ratio() >= 0.75)
    return not (eq(t1(cur.get('first')), t1(rec.get('first'))) or eq(t1(cur.get('father')), t1(rec.get('father'))) or eq(t1(cur.get('mother')), t1(rec.get('mother'))))
