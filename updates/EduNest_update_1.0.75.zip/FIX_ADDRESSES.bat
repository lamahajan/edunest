@echo off
title EduNest - clean addresses and fill PIN codes
cd /d "%~dp0"
set "PYEXE=%~dp0venv\Scripts\python.exe"
if exist "%~dp0runtime\python.exe" set "PYEXE=%~dp0runtime\python.exe"
if not exist "%PYEXE%" (
  echo.
  echo  The program is not installed yet. Double-click setup.bat first.
  echo.
  pause
  exit /b 1
)
set PYTHONDONTWRITEBYTECODE=1
echo.
echo  Writes every address without Vill / V.P.O / P.O, with proper capital letters,
echo  and fills the PIN code from the internet (India Post). This PC needs internet now.
echo.
cd backend
"%PYEXE%" manage.py fix_addresses
if errorlevel 1 goto end
echo.
echo  The list of every change is saved in the data folder: address_review.csv
set "OK="
set /p OK= Type YES (capital letters) to SAVE the changes, anything else cancels: 
if not "%OK%"=="YES" (
  echo  Cancelled. Nothing was saved.
  goto end
)
"%PYEXE%" manage.py fix_addresses --apply
:end
echo.
pause
