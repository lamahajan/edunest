/**
 * EduNest -> Google Contacts (ONE WAY: the ERP is the master, nothing is read back).
 * The ERP sends students' parents' and teachers' numbers here; this script creates / updates / removes the contacts
 * in the Google account that owns this script, and puts them in the label "EduNest".
 * Setup: see SETUP.txt. Needs the "People API" advanced service (Services + > Google People API) and a Script Property TOKEN.
 */
const GROUP_NAME = 'EduNest';
const KEY_TYPE = 'EduNest';          // every contact we create carries the ERP key in its "external ID" of this type

function doPost(e) {
  try {
    const body = JSON.parse(e.postData.contents);
    const token = PropertiesService.getScriptProperties().getProperty('TOKEN');
    if (!token || body.token !== token) return out_({ ok: false, error: 'Wrong token: it must be the same in Script Properties (TOKEN) and in data/config.env (CONTACTS_SCRIPT_TOKEN).' });
    if (body.action === 'ping') return out_({ ok: true, message: 'Connected to the Google Contacts of ' + Session.getEffectiveUser().getEmail() });
    const lock = LockService.getScriptLock();
    lock.waitLock(120000);
    try {
      if (body.action === 'upsert') return out_(upsert_(body.items || []));
      if (body.action === 'delete') return out_(remove_(body.keys || []));
    } finally {
      lock.releaseLock();
    }
    return out_({ ok: false, error: 'Unknown action' });
  } catch (err) {
    return out_({ ok: false, error: String(err) });
  }
}

function doGet() {
  return out_({ ok: true, message: 'EduNest contacts script is running. The ERP talks to it with POST.' });
}

function out_(o) {
  return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);
}

function group_() {
  const props = PropertiesService.getScriptProperties();
  let g = props.getProperty('GROUP');
  if (g) return g;
  const list = (People.ContactGroups.list({ pageSize: 200 }).contactGroups || []).filter(function (x) { return x.name === GROUP_NAME && x.groupType === 'USER_CONTACT_GROUP'; });
  g = list.length ? list[0].resourceName : People.ContactGroups.create({ contactGroup: { name: GROUP_NAME } }).resourceName;
  props.setProperty('GROUP', g);
  return g;
}

// {erpKey: person} of the contacts this script made earlier
function loadMap_() {
  const map = {};
  let token;
  do {
    const r = People.People.Connections.list('people/me', { personFields: 'names,phoneNumbers,externalIds', pageSize: 1000, pageToken: token });
    (r.connections || []).forEach(function (p) {
      (p.externalIds || []).forEach(function (x) { if (x.type === KEY_TYPE) map[x.value] = p; });
    });
    token = r.nextPageToken;
  } while (token);
  return map;
}

function upsert_(items) {
  const map = loadMap_(), group = group_();
  const create = [], update = {};
  items.forEach(function (it) {
    const person = {
      names: [{ givenName: it.name }],
      phoneNumbers: [{ value: it.phone, type: 'mobile' }],
      externalIds: [{ value: it.key, type: KEY_TYPE }]
    };
    const ex = map[it.key];
    if (!ex) {
      person.memberships = [{ contactGroupMembership: { contactGroupResourceName: group } }];
      create.push({ contactPerson: person });
      return;
    }
    const n0 = (ex.names || [])[0] || {}, p0 = (ex.phoneNumbers || [])[0] || {};
    const sameName = (n0.givenName || '') === it.name && !n0.familyName && !n0.middleName;
    const samePhone = String(p0.canonicalForm || p0.value || '').replace(/[\s\-()]/g, '') === it.phone;
    if (sameName && samePhone) return;
    person.etag = ex.etag;
    update[ex.resourceName] = person;
  });
  if (create.length) People.People.batchCreateContacts({ contacts: create, readMask: 'names' });
  const keys = Object.keys(update);
  if (keys.length) {
    if (create.length) Utilities.sleep(1500);
    People.People.batchUpdateContacts({ contacts: update, updateMask: 'names,phoneNumbers', readMask: 'names' });
  }
  return { ok: true, created: create.length, updated: keys.length };
}

function remove_(keys) {
  const map = loadMap_();
  const names = keys.map(function (k) { return map[k] && map[k].resourceName; }).filter(Boolean);
  if (names.length) People.People.batchDeleteContacts({ resourceNames: names });
  return { ok: true, deleted: names.length };
}
