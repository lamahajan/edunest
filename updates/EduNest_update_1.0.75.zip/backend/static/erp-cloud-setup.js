/* Setup > School Setup > "Cloud Sync" tab (administrators only): connect the cloud apps (eGateSys, Result portal, online fee, attendance) to this ERP.
   Fill a card, press Test, then Save: it is saved on the school server (data/config.env) and starts working at once (no restart).
   Disconnect stops that app's sync at once and forgets its address / secrets. A secret is never shown again.
   Parent App (Firestore): the service account JSON goes in a text box, and the card has "Reset a password" (cloud_parent.reset_password).
   The tab and its panel are part of the ERP page (see build_frontend.py); this file fills the panel in.
   1.0.53: "Force push all data now" bar at the top (fresh Parent App + due list snapshot from this page, then every connected app sends
   everything again: runtime.push_all), and "Notices & announcements" on the Parent App card (cloud_parent.notices_save -> notices/board). */
(function () {
  'use strict';
  var G = [], TOKEN = function () { return localStorage.getItem('erp_token'); };
  var $ = function (id) { return document.getElementById(id); };
  var esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };
  function api(method, url, body) {
    return fetch('/api/sync/' + url, { method: method, headers: { 'Authorization': 'Token ' + TOKEN(), 'Content-Type': 'application/json' }, body: body === undefined ? undefined : JSON.stringify(body) })
      .then(function (r) { return r.json().catch(function () { return {}; }).then(function (j) { j.status = r.status; return j; }); });
  }
  function admin() { try { return typeof usrCan === 'function' && usrCan('adminZone', 'edit'); } catch (e) { return false; } }
  function note(text, bad) { var n = $('cloudSetupNote'), n2 = $('pappSetupNote'); if (n2) { n2.textContent = text || ''; n2.className = 'text-xs min-h-[1rem] ' + (bad ? 'text-red-600' : 'text-green-700'); } if (n) { n.textContent = text || ''; n.className = 'text-xs min-h-[1rem] ' + (bad ? 'text-red-600' : 'text-green-700'); } }

  var NOTICES = [], NEDIT = null;
  var inp = 'border:1px solid #c4c7c5;border-radius:10px;padding:7px 10px;background:transparent;color:inherit;width:100%';
  function cardHtml(g) {
      var f = g.fields.map(function (x) {
        if (x.kind === 'check') return '<div class="mf"><label class="flex items-center gap-2 text-sm cursor-pointer" style="position:static;transform:none;padding:0;background:none;pointer-events:auto"><input type="checkbox" data-key="' + x.key + '"' + (((x.value || x.default) === '1') ? ' checked' : '') + '> ' + esc(x.label) + '</label>' +
          (x.help ? '<div class="text-[11px] text-gray-500 dark:text-gray-400 mt-0.5">' + esc(x.help) + '</div>' : '') + '</div>';
        if (x.kind === 'json') return '<div class="mf"><label>' + esc(x.label) + (x.set ? ' <span class="font-normal text-gray-500"><input type="checkbox" data-clear="' + x.key + '"> remove the saved one</span>' : '') + '</label>' +
          '<textarea data-key="' + x.key + '" rows="3" autocomplete="off" autocapitalize="off" autocorrect="off" spellcheck="false" data-nocap style="width:100%;font:12px monospace;border:1px solid #c4c7c5;border-radius:10px;padding:8px;background:transparent;color:inherit" placeholder="' + (x.set ? '\u25CF\u25CF\u25CF\u25CF saved (leave empty to keep)' : '{ &quot;type&quot;: &quot;service_account&quot;, ... }') + '"></textarea>' +
          (x.help ? '<div class="text-[11px] text-gray-500 dark:text-gray-400 mt-0.5">' + esc(x.help) + '</div>' : '') + '</div>';
        var ph = x.kind === 'secret' ? (x.set ? '\u25CF\u25CF\u25CF\u25CF saved (leave empty to keep)' : '') : (x.default || '');
        return '<div class="mf"><label>' + esc(x.label) + (x.kind === 'secret' && x.set ? ' <span class="font-normal text-gray-500"><input type="checkbox" data-clear="' + x.key + '"> remove the saved one</span>' : '') + '</label>' +
          '<input ' + (x.kind === 'secret' ? 'type="password" autocomplete="new-password" autocapitalize="off"' : 'type="text" autocomplete="off" autocapitalize="off" autocorrect="off" spellcheck="false"') + ' data-key="' + x.key + '" value="' + esc(x.value) + '" placeholder="' + esc(ph) + '">' +
          (x.help ? '<div class="text-[11px] text-gray-500 dark:text-gray-400 mt-0.5">' + esc(x.help) + '</div>' : '') + '</div>';
      }).join('');
      return '<div class="rounded-2xl border border-[#e0e3e7] dark:border-[#3c4043] p-4 flex flex-col gap-3" data-cs-group="' + g.id + '">' +
        '<div class="flex items-center justify-between gap-2"><div><div class="rc-card-title"><span class="material-symbols-outlined">cloud_sync</span>' + esc(g.title) + '</div><p class="text-xs text-gray-500 dark:text-gray-400">' + esc(g.sub) + '</p></div>' +
        badge(g) + '</div>' + f +
        '<div class="flex flex-wrap gap-2"><button type="button" class="rc-btn" data-act="test" data-g="' + g.id + '">Test</button><button type="button" class="rc-btn rc-btn-primary" data-act="save" data-g="' + g.id + '">Save</button>' +
        (g.on ? '<button type="button" class="rc-btn" data-act="pushall" data-g="' + g.id + '" data-t="' + esc(g.title) + '" title="Sends everything of this app again, now. Nothing in EduNest is changed."><span class="material-symbols-outlined">cloud_upload</span>Force push now</button>' : '') +
        (g.on ? '<button type="button" class="rc-btn" data-act="fetch" data-g="' + g.id + '" title="' + (g.id === 'contacts' ? 'Sends every parent and teacher number to Google Contacts again.' : g.id === 'students' ? 'Replaces the student list in the cloud with the list of students studying now.' : 'Brings in everything the cloud has (also what came while this was not connected). Nothing in the cloud is deleted.') + '"><span class="material-symbols-outlined">download</span>' + (g.id === 'contacts' ? 'Send all contacts now' : g.id === 'students' ? 'Send student list now' : 'Fetch all data now') + '</button>' : '') +
        (g.on ? '<button type="button" class="rc-btn ml-auto text-red-600" data-act="disconnect" data-g="' + g.id + '" data-t="' + esc(g.title) + '">Disconnect</button>' : '') + '</div>' +
        '<div class="text-xs" data-cs-res="' + g.id + '"></div>' + (g.id === 'papp' && g.on ? resetBox() + '<p class="text-[11px] text-gray-500 dark:text-gray-400 border-t border-[#e0e3e7] dark:border-[#3c4043] pt-3">Notices &amp; announcements: open the 9-dot menu &gt; Front Desk &gt; Notices.</p>' : '') + '</div>';
  }
  function draw() {
    var cb = $('cloudSetupBody'), pb = $('pappSetupBody');
    if (cb) cb.innerHTML = '<p class="text-xs text-gray-500 dark:text-gray-400">The <b>Parent App</b> (Firestore) now has its own tab: Setup &gt; School Setup &gt; <b>Parent App</b>.</p>' + G.filter(function (g) { return g.id !== 'papp'; }).map(cardHtml).join('');
    if (pb) { pb.innerHTML = G.filter(function (g) { return g.id === 'papp'; }).map(cardHtml).join('') + '<div id="pappProjects"></div>'; drawProjects(); }
  }

  // ---- Notices & announcements (Parent App + Teacher App home screen)
  function secList() {
    var out = [];
    try { (typeof CLASSES !== 'undefined' ? CLASSES : []).forEach(function (c) { ((c.sections && c.sections.length) ? c.sections : ['A']).forEach(function (sc) {
      var id = window.__parentApp ? window.__parentApp.secId(c.name, sc) : String(c.name + '-' + sc).toUpperCase().replace(/[^A-Z0-9-]/g, '');
      out.push([id, c.name + ' - ' + sc]); }); }); } catch (e) {}
    return out;
  }
  function noticeBox() {
    return '<div class="flex flex-col gap-2"><p class="text-[11px] text-gray-500 dark:text-gray-400">Shown on the home screen of the Parent App and / or Teacher App within a few seconds. Teachers can also post notices to their own classes from the Teacher App.</p>' +
      '<div id="pappNoticeList" class="flex flex-col gap-2 text-sm">Loading ...</div><div id="pappNoticeForm"></div></div>';
  }
  // Separate popup (9-dot menu > Front Desk > Notices)
  window.openNotices = function () {
    var wm = $('waffleMenu'); if (wm) wm.classList.add('hidden');
    var m = $('noticeModal');
    if (!m) {
      m = document.createElement('div'); m.id = 'noticeModal';
      m.className = 'fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4';
      m.innerHTML = '<div class="w-full max-w-2xl max-h-[90vh] flex flex-col rounded-3xl bg-white dark:bg-[#282a2c] text-[#1f1f1f] dark:text-[#e3e3e3] border border-[#dadce0] dark:border-[#3c4043] shadow-2xl">' +
        '<div class="flex items-center justify-between gap-3 px-5 py-4 border-b border-[#e0e3e7] dark:border-[#3c4043]"><div class="rc-card-title" style="margin:0"><span class="material-symbols-outlined">notifications_active</span>Notices &amp; Announcements</div>' +
        '<button type="button" class="rc-btn" data-act="nclose" title="Close"><span class="material-symbols-outlined">close</span></button></div>' +
        '<div id="noticeModalBody" class="overflow-y-auto p-5"></div></div>';
      m.addEventListener('click', function (e) { if (e.target === m) m.classList.add('hidden'); });
      document.body.appendChild(m);
    }
    m.classList.remove('hidden');
    $('noticeModalBody').innerHTML = noticeBox();
    if (!TOKEN()) { $('pappNoticeList').innerHTML = '<p class="text-sm text-red-600">Please log in to the ERP first.</p>'; return; }
    NEDIT = null; loadNotices();
  };
  function loadNotices() {
    api('GET', 'cloud-setup/notices/').then(function (j) {
      if (j.status === 403) { var L = $('pappNoticeList'); if (L) L.innerHTML = '<p class="text-sm text-red-600">Only an administrator can post notices. Log in as the administrator.</p>'; var F = $('pappNoticeForm'); if (F) F.innerHTML = ''; return; }
      NOTICES = j.list || []; drawNotices();
    });
  }
  function audText(n) { return (n.aud === 'p' ? 'Parents' : n.aud === 't' ? 'Teachers' : 'Everyone') + (n.secs && n.secs.length ? ' of ' + n.secs.join(', ') : ''); }
  function drawNotices() {
    var L = $('pappNoticeList'), F = $('pappNoticeForm'); if (!L) return;
    L.innerHTML = NOTICES.length ? NOTICES.map(function (n, i) {
      var old = n.exp && n.exp < new Date().toISOString().slice(0, 10);
      return '<div class="rounded-xl border border-[#e0e3e7] dark:border-[#3c4043] p-3 flex gap-3 items-start" style="' + (old ? 'opacity:.55' : '') + '"><div style="flex:1;min-width:0"><div class="font-semibold">' + (n.pin ? '\uD83D\uDCCC ' : '') + esc(n.t || '(no title)') + '</div>' +
        '<div class="text-xs text-gray-500 dark:text-gray-400">' + esc(n.date) + ' \u00B7 ' + esc(audText(n)) + (n.exp ? ' \u00B7 until ' + esc(n.exp) + (old ? ' (expired)' : '') : '') + '</div>' +
        (n.b ? '<div class="text-xs mt-1" style="white-space:pre-wrap">' + esc(n.b) + '</div>' : '') + '</div>' +
        '<button type="button" class="rc-btn" data-act="nedit" data-i="' + i + '">Edit</button><button type="button" class="rc-btn text-red-600" data-act="ndel" data-i="' + i + '">Delete</button></div>';
    }).join('') : '<p class="text-xs text-gray-500">No notices yet.</p>';
    var n = NEDIT || { t: '', b: '', aud: 'all', secs: [], exp: '', pin: false };
    var secs = secList();
    F.innerHTML = '<div class="rounded-xl border border-[#e0e3e7] dark:border-[#3c4043] p-3 flex flex-col gap-2"><div class="text-sm font-semibold">' + (NEDIT ? 'Edit notice' : 'New notice') + '</div>' +
      '<input id="pnT" type="text" maxlength="140" placeholder="Title, e.g. Annual Sports Day" value="' + esc(n.t) + '" style="' + inp + '">' +
      '<textarea id="pnB" rows="3" maxlength="3000" placeholder="Message" style="' + inp + '">' + esc(n.b) + '</textarea>' +
      '<div class="flex flex-wrap gap-2 items-center"><label class="text-xs">For <select id="pnA" style="' + inp + ';width:auto">' +
      [['all', 'Everyone (parents and teachers)'], ['p', 'Parents only'], ['t', 'Teachers only']].map(function (o) { return '<option value="' + o[0] + '"' + (n.aud === o[0] ? ' selected' : '') + '>' + o[1] + '</option>'; }).join('') + '</select></label>' +
      '<label class="text-xs">Show until <input id="pnE" type="date" value="' + esc(n.exp) + '" style="' + inp + ';width:auto"></label>' +
      '<label class="text-xs flex items-center gap-1"><input id="pnP" type="checkbox"' + (n.pin ? ' checked' : '') + '> Pin on top</label></div>' +
      (secs.length ? '<details' + (n.secs && n.secs.length ? ' open' : '') + '><summary class="text-xs cursor-pointer">Only some classes? (none ticked = the whole school)</summary><div class="flex flex-wrap gap-2 mt-2">' +
        secs.map(function (x) { return '<label class="text-xs flex items-center gap-1" style="border:1px solid #c4c7c5;border-radius:999px;padding:3px 9px"><input type="checkbox" data-nsec="' + esc(x[0]) + '"' + ((n.secs || []).indexOf(x[0]) >= 0 ? ' checked' : '') + '>' + esc(x[1]) + '</label>'; }).join('') + '</div></details>' : '') +
      '<div class="flex gap-2"><button type="button" class="rc-btn rc-btn-primary" data-act="nsave">' + (NEDIT ? 'Save changes' : 'Post notice') + '</button>' + (NEDIT ? '<button type="button" class="rc-btn" data-act="ncancel">Cancel</button>' : '') + '</div><div class="text-xs" id="pnRes"></div></div>';
  }
  function saveNotices(list, msg) {
    var r = $('pnRes'); if (r) { r.className = 'text-xs'; r.textContent = 'Saving ...'; }
    return api('POST', 'cloud-setup/notices/', { list: list }).then(function (j) {
      if (!j.ok) { if (r) { r.className = 'text-xs text-red-600'; r.textContent = j.error || ('Could not save (HTTP ' + j.status + ')'); } return; }
      NOTICES = j.list; NEDIT = null; drawNotices(); var r2 = $('pnRes'); if (r2) { r2.className = 'text-xs text-green-700'; r2.textContent = '\u2713 ' + msg; }
    });
  }
  function resetBox() {
    return '<div class="border-t border-[#e0e3e7] dark:border-[#3c4043] pt-3 flex flex-col gap-2"><div class="text-sm font-semibold">Reset a password</div>' +
      '<p class="text-[11px] text-gray-500 dark:text-gray-400">The password goes back to the mobile number (parent: Mobile No 1 of the admission form; teacher: mobile in Setup &gt; Teachers).</p>' +
      '<div class="flex flex-wrap gap-2 items-center"><select id="pappResetKind" class="rc-input" style="border:1px solid #c4c7c5;border-radius:10px;padding:7px 10px;background:transparent;color:inherit"><option value="p">Parent (admission no)</option><option value="t">Teacher (login name)</option></select>' +
      '<input id="pappResetId" type="text" autocomplete="off" autocapitalize="off" data-nocap placeholder="Admission no / login name" style="border:1px solid #c4c7c5;border-radius:10px;padding:7px 10px;background:transparent;color:inherit">' +
      '<button type="button" class="rc-btn" data-act="preset" data-g="papp">Reset password</button></div><div class="text-xs" id="pappResetRes"></div></div>';
  }
  function badge(g) {
    var st = g.running ? ['RUNNING', 'border-green-600 text-green-700'] : g.on ? ['SET UP, NOT RUNNING', 'border-amber-500 text-amber-700'] : ['OFF', 'border-gray-300 text-gray-500'];
    return '<span class="px-2 py-0.5 rounded-full text-[11px] font-bold border ' + st[1] + '">' + st[0] + '</span>';
  }
  function collect(gid) {
    var card = document.querySelector('[data-cs-group="' + gid + '"]'), values = {}, clear = [];
    card.querySelectorAll('input[data-key], textarea[data-key]').forEach(function (i) { values[i.getAttribute('data-key')] = i.type === 'checkbox' ? (i.checked ? '1' : '0') : i.value; });
    card.querySelectorAll('input[data-clear]').forEach(function (c) { if (c.checked) clear.push(c.getAttribute('data-clear')); });
    return { values: values, clear: clear };
  }
  function show(gid, lines) {
    document.querySelector('[data-cs-res="' + gid + '"]').innerHTML = lines.map(function (l) { return '<div class="' + (l.ok ? 'text-green-700' : 'text-red-600') + '">' + (l.ok ? '\u2713 ' : '\u2717 ') + esc(l.message) + '</div>'; }).join('');
  }
  function fail(text) { var h = '<p class="text-sm text-red-600">' + esc(text) + '</p>'; if ($('cloudSetupBody')) $('cloudSetupBody').innerHTML = h; if ($('pappSetupBody')) $('pappSetupBody').innerHTML = h; }

  function load() {
    note('');
    if (!TOKEN()) return fail('Please log in to the ERP first.');
    if ($('cloudSetupBody')) $('cloudSetupBody').innerHTML = '<p class="text-sm text-gray-500">Loading ...</p>';
    if ($('pappSetupBody')) $('pappSetupBody').innerHTML = '<p class="text-sm text-gray-500">Loading ...</p>';
    api('GET', 'cloud-setup/').then(function (j) {
      if (j.status === 403) return fail('Only an administrator can change the cloud connections. Log in as the administrator.');
      if (!j.groups) return fail('Could not load the settings (HTTP ' + j.status + ').');
      G = j.groups; PJ = null; draw(); loadProjects();
    });
  }
  document.addEventListener('click', function (e) {
    var b = e.target.closest && e.target.closest('#cloudSetupBody button[data-act], #pappSetupBody button[data-act], #noticeModal button[data-act]'); if (!b) return;
    var gid = b.getAttribute('data-g'), act = b.getAttribute('data-act');
    if (act.indexOf('pj-') === 0) return pjAct(b, act);
    if (act === 'nclose') { $('noticeModal').classList.add('hidden'); return; }
    if (act === 'nedit') { NEDIT = JSON.parse(JSON.stringify(NOTICES[+b.getAttribute('data-i')])); drawNotices(); $('pnT').focus(); return; }
    if (act === 'ncancel') { NEDIT = null; drawNotices(); return; }
    if (act === 'ndel') {
      var dn = NOTICES[+b.getAttribute('data-i')]; if (!window.confirm('Delete the notice "' + (dn.t || '') + '"? It disappears from the apps.')) return;
      return saveNotices(NOTICES.filter(function (x) { return x !== dn; }), 'Deleted');
    }
    if (act === 'nsave') {
      var n = { id: NEDIT ? NEDIT.id : '', date: NEDIT ? NEDIT.date : '', t: $('pnT').value.trim(), b: $('pnB').value.trim(), aud: $('pnA').value, exp: $('pnE').value, pin: $('pnP').checked,
        secs: [].slice.call(document.querySelectorAll('#pappNoticeForm input[data-nsec]:checked')).map(function (c) { return c.getAttribute('data-nsec'); }) };
      if (!n.t) { $('pnRes').className = 'text-xs text-red-600'; $('pnRes').textContent = 'Type a title'; return; }
      var list = NEDIT ? NOTICES.map(function (x) { return x.id === NEDIT.id ? n : x; }) : [n].concat(NOTICES);
      return saveNotices(list, NEDIT ? 'Saved. The apps show it within a minute.' : 'Posted. The apps show it within a minute.');
    }
    if (act === 'pushall') {
      var pt = b.getAttribute('data-t') || gid;
      if (!window.confirm('Force push ' + pt + ' now?\n\nEverything of this app is sent again. Nothing in EduNest is changed. The first time it can take a few minutes.' + (gid === 'papp' ? '\n\nFree Firebase allows 20,000 writes a day; this uses about 2 per student (7,000 for 3,500 students). Do it only when needed, not every day.' : ''))) return;
      b.disabled = true; show(gid, [{ ok: true, message: 'Preparing a fresh copy of the data on this page ...' }]);
      var pre = [];
      if (gid === 'papp' && window.__parentApp && window.__parentApp.forcePush) pre.push(window.__parentApp.forcePush().catch(function () { return null; }));
      if (gid === 'fee' && window.__feeSync && window.__feeSync.sendDues) pre.push(Promise.resolve().then(function () { return window.__feeSync.sendDues(); }).catch(function () { return null; }));
      return Promise.all(pre).then(function (r) {
        var warn = (gid === 'papp' && r[0] && r[0].error) ? [{ ok: false, message: 'Parent App: ' + r[0].error }] : [];
        return api('POST', 'cloud-setup/push/', { group: gid }).then(function (j) {
          if (!j.ok) { b.disabled = false; return show(gid, warn.concat([{ ok: false, message: j.error || ('Could not start (HTTP ' + j.status + ').') }])); }
          var tries = 0;
          (function poll() {
            api('GET', 'cloud-setup/push/').then(function (x) {
              var p = (x.one || {})[gid] || {};
              if (p.state === 'running' && tries++ < 450) { show(gid, warn.concat([{ ok: true, message: 'Pushing ...' }])); return setTimeout(poll, 2000); }
              b.disabled = false;
              show(gid, warn.concat([{ ok: p.state === 'done', message: p.state === 'running' ? 'Still running in the background.' : (p.state === 'done' ? 'Finished: ' : 'Failed: ') + (p.text || '') }]));
            });
          })();
        });
      });
    }
    if (act === 'disconnect') {
      if (!window.confirm('Disconnect ' + b.getAttribute('data-t') + '?\n\nSyncing with this app stops now and its saved address and secrets are removed from this server. Nothing in the cloud app itself is deleted. You can connect again any time.')) return;
      b.disabled = true;
      return api('POST', 'cloud-setup/disconnect/', { group: gid }).then(function (j) {
        b.disabled = false;
        if (!j.groups) return show(gid, [{ ok: false, message: 'Could not disconnect (HTTP ' + j.status + ').' }]);
        G = j.groups; draw(); note('Disconnected. Syncing with ' + b.getAttribute('data-t') + ' has stopped.');
      });
    }
    if (act === 'preset') {
      var id = ($('pappResetId').value || '').trim(), kind = $('pappResetKind').value, out = $('pappResetRes');
      if (!id) { out.className = 'text-xs text-red-600'; out.textContent = 'Type the admission no / login name'; return; }
      if (!window.confirm('Reset the password of ' + (kind === 'p' ? 'the parent of ' : 'teacher ') + id + '?\n\nThe new password will be the mobile number.')) return;
      b.disabled = true; out.className = 'text-xs'; out.textContent = 'Working ...';
      return api('POST', 'cloud-setup/parent-reset/', { kind: kind, id: id }).then(function (j) {
        b.disabled = false; out.className = 'text-xs ' + (j.ok ? 'text-green-700' : 'text-red-600'); out.textContent = (j.ok ? '\u2713 ' + j.message : '\u2717 ' + (j.error || ('HTTP ' + j.status)));
      });
    }
    if (act === 'fetch') {
      if (!window.confirm(gid === 'papp' ? 'Send everything to the Parent App now?\n\nEvery student, login and teacher is written to Firebase again (about 2 writes per student). The first time it can take 10-15 minutes.' : gid === 'contacts' ? 'Send all contacts to Google now?\n\nEvery parent and teacher number is sent again. Contacts that are already in Google are only updated, not duplicated.' : gid === 'students' ? 'Send the student list now?\n\nThe list in the cloud is deleted and the list of students studying now is written in its place.' : 'Fetch all data from the cloud now?\n\nEverything the cloud has is brought into this ERP, also what came while this app was not connected. Nothing in the cloud is deleted; what the ERP already has is not duplicated.')) return;
      b.disabled = true; show(gid, [{ ok: true, message: 'Fetching ... (this can take a minute)' }]);
      return api('POST', 'cloud-setup/fetch/', { group: gid }).then(function (j) {
        if (!j.ok) { b.disabled = false; return show(gid, [{ ok: false, message: j.error || ('Could not start (HTTP ' + j.status + ').') }]); }
        var tries = 0;
        (function poll() {
          api('GET', 'cloud-setup/fetch/').then(function (r) {
            var f = (r.fetch || {})[gid] || {};
            if (f.state === 'running' && tries++ < 300) return setTimeout(poll, 2000);
            b.disabled = false;
            show(gid, [{ ok: f.state === 'done', message: f.state === 'done' ? 'Done. ' + f.text : f.state === 'error' ? 'Failed: ' + f.text : 'Still running in the background. Press again later to see the result.' }]);
          });
        })();
      });
    }
    var c = collect(gid); b.disabled = true;
    if (act === 'test') {
      show(gid, [{ ok: true, message: 'Testing ...' }]);
      api('POST', 'cloud-setup/test/', { group: gid, values: c.values }).then(function (j) { b.disabled = false; show(gid, j.results || [{ ok: false, message: 'The test could not run (HTTP ' + j.status + ').' }]); });
    } else {
      api('POST', 'cloud-setup/', { values: c.values, clear: c.clear }).then(function (j) {
        b.disabled = false;
        if (j.status === 400 && j.errors) return show(gid, Object.keys(j.errors).map(function (k) { return { ok: false, message: k + ': ' + j.errors[k] }; }));
        if (!j.groups) return show(gid, [{ ok: false, message: 'Could not save (HTTP ' + j.status + ').' }]);
        G = j.groups; draw();
        var g = G.filter(function (x) { return x.id === gid; })[0] || {};
        show(gid, [{ ok: true, message: 'Saved.' }]);
        note(g.running ? 'Saved. Connected and running now.' : 'Saved. It starts as soon as every required box is filled in.');
      });
    }
  });


  // ---- Firebase per SECTION (1.0.64): every section of Setup > Classes has its own Firebase config boxes. Empty = OFF. The same config in several sections = they share one project.
  // The server keeps the keys in data/papp_projects.json (they never come back to this page); the page only knows which section is on which saved project (pid).
  var PJ = null, PJMAIN = '', PJRES = '', S = {};
  function classGroups() {
    var out = [];
    try { (typeof CLASSES !== 'undefined' ? CLASSES : []).forEach(function (c) {
      var secs = ((c.sections && c.sections.length) ? c.sections : ['A']).map(function (sc) {
        var id = window.__parentApp ? window.__parentApp.secId(c.name, sc) : String(c.name + '-' + sc).toUpperCase().replace(/[^A-Z0-9-]/g, '');
        return { id: id, sc: sc };
      });
      out.push({ name: String(c.name), secs: secs });
    }); } catch (e) {}
    return out;
  }
  function pjFromServer(list) {
    return (list || []).map(function (x) { return { id: x.id, name: x.name, project: x.project, web: x.web && x.web.apiKey ? JSON.stringify(x.web) : '', classes: x.classes || [], secs: x.secs || [] }; });
  }
  function buildS() {                                  // section -> {cls, pid, project, key, web} from the saved projects (a project saved class-wise before 1.0.64 is spread over its sections)
    S = {};
    var cg = classGroups();
    (PJ || []).forEach(function (p) {
      cg.forEach(function (c) {
        c.secs.forEach(function (s) {
          if (S[s.id]) return;
          if (p.secs.indexOf(s.id) >= 0 || p.classes.indexOf(c.name) >= 0) S[s.id] = { cls: c.name, pid: p.id, project: p.project, key: '', web: p.web || '' };
        });
      });
    });
  }
  function loadProjects() {
    api('GET', 'cloud-setup/parent-projects/').then(function (j) {
      if (!j.ok) return;
      PJMAIN = j.main || '';
      PJ = pjFromServer(j.list);
      buildS(); drawProjects();
      PJRES = cfgBlock(); var c = $('pjCfg'); if (c) c.innerHTML = PJRES;
    });
  }
  function webOk(t) { return /apiKey/.test(t || '') && /appId/.test(t || '') && /projectId/.test(t || ''); }
  function secState(id) { return S[id] || (S[id] = { cls: '', pid: '', project: '', key: '', web: '' }); }
  function secChip(st) {
    if (st.key.trim()) return '<span class="text-[11px] text-amber-700">new config: press Save</span>';
    if (st.pid) return '<span class="text-[11px] text-green-700">Firebase: ' + esc(st.project) + '</span>';
    return '<span class="text-[11px] text-gray-500">OFF (no Firebase)</span>';
  }
  var TA = 'width:100%;font:12px monospace;border:1px solid #c4c7c5;border-radius:10px;padding:8px;background:transparent;color:inherit';
  function drawProjects() {
    var box = $('pappProjects'); if (!box) return;
    if (PJ === null) { box.innerHTML = '<p class="text-sm text-gray-500">Loading ...</p>'; return; }
    var cg = classGroups(), nOwn = 0;
    var cards = cg.map(function (c) {
      var rows = c.secs.map(function (s) {
        var st = secState(s.id); st.cls = c.name;
        var own = !!(st.pid || st.key.trim()); if (own) nOwn++;
        return '<details class="rounded-lg border border-[#e0e3e7] dark:border-[#3c4043] px-2 py-1"' + (own ? ' open' : '') + ' data-sf-row="' + esc(s.id) + '"><summary class="text-xs cursor-pointer flex flex-wrap items-center gap-2"><b>Section ' + esc(s.sc) + '</b><span data-sf-chip="' + esc(s.id) + '">' + secChip(st) + '</span></summary>' +
          '<div class="flex flex-col gap-2 py-2">' +
          '<div class="mf"><label>Service account key (JSON)' + (st.pid ? ' <span class="font-normal text-gray-500">saved; paste a new one only to replace it</span>' : '') + '</label><textarea data-sf="key|' + esc(s.id) + '" rows="2" autocomplete="off" autocapitalize="off" spellcheck="false" data-nocap style="' + TA + '" placeholder="' + (st.pid ? '\u25CF\u25CF\u25CF\u25CF saved' : 'Firebase > Project settings > Service accounts > Generate new private key; paste the whole .json here. Empty = this section is OFF') + '">' + esc(st.key) + '</textarea></div>' +
          '<div class="mf"><label>Web app config <span class="font-normal text-gray-500">(Project settings &gt; General &gt; Your apps &gt; Web &gt; firebaseConfig)</span> ' + (webOk(st.web) ? '<span class="text-green-700 font-normal">\u2713 found</span>' : '') + '</label><textarea data-sf="web|' + esc(s.id) + '" rows="3" autocomplete="off" autocapitalize="off" spellcheck="false" data-nocap style="' + TA + '" placeholder="const firebaseConfig = { apiKey: \'...\', authDomain: \'...\', projectId: \'...\', appId: \'...\' };">' + esc(st.web) + '</textarea></div>' +
          '<div class="flex flex-wrap gap-2 items-center"><button type="button" class="rc-btn" data-act="pj-test" data-sec="' + esc(s.id) + '">Test</button><button type="button" class="rc-btn text-red-600" data-act="pj-clear" data-sec="' + esc(s.id) + '">Switch off (clear)</button><span class="text-xs" data-sf-res="' + esc(s.id) + '"></span></div></div></details>';
      }).join('');
      return '<div class="rounded-xl border border-[#e0e3e7] dark:border-[#3c4043] p-3 flex flex-col gap-2"><div class="flex flex-wrap items-center gap-2"><div class="text-sm font-semibold">Class ' + esc(c.name) + '</div>' +
        (c.secs.length > 1 ? '<button type="button" class="rc-btn ml-auto" data-act="pj-copy" data-cls="' + esc(c.name) + '" title="Copies the config of the first section that has one to every section of this class">Same config for all sections of this class</button>' : '') + '</div>' + rows + '</div>';
    }).join('') || '<p class="text-xs text-gray-500">No classes found (Setup > Classes).</p>';
    box.innerHTML = '<div class="rounded-2xl border border-[#e0e3e7] dark:border-[#3c4043] p-4 flex flex-col gap-3">' +
      '<div><div class="rc-card-title"><span class="material-symbols-outlined">dns</span>Firebase for each section (linked with Setup &gt; Classes)</div>' +
      '<p class="text-xs text-gray-500 dark:text-gray-400">One free Firebase project allows 50,000 reads and 20,000 writes a day. Open a section below and paste its own Firebase config (service account key + web app config). ' +
      'A section with <b>empty</b> boxes is <b>OFF</b>: nothing of it goes to Firebase (no student data, no parent / teacher login)' + (PJMAIN ? '; the old main project (' + esc(PJMAIN) + ') still takes the sections without a config of their own' : '') + '. To keep some sections together, paste the <b>same</b> config in each of them (or use <i>Same config for all sections of this class</i>): sections with the same Firebase project share it. ' +
      'Parents still log in with Admission No + Mobile No; a family whose children are in two projects sees all its children together (the Parent App needs the <b>firebaseMore</b> lines in <b>config.js</b>, shown after saving). ' + (nOwn ? nOwn + ' section(s) have their own config.' : 'No section has a config yet: the Parent App is OFF for every section.') + '</p></div>' +
      cards +
      '<div class="flex flex-wrap gap-2"><button type="button" class="rc-btn rc-btn-primary" data-act="pj-save">Save</button></div>' +
      '<div class="text-xs" id="pjMsg"></div><div id="pjCfg">' + (PJRES || '') + '</div></div>';
  }
  function pjMsg(t, bad) { var m = $('pjMsg'); if (m) { m.className = 'text-xs ' + (bad ? 'text-red-600' : 'text-green-700'); m.textContent = t; } }
  function cfgBlock() {
    var L = (PJ || []).filter(function (p) { return p.project; }), miss = [], items = [];
    L.forEach(function (p) {
      var w = null; try { w = JSON.parse(p.web); } catch (e) { w = null; }
      if (!w || !w.apiKey) { miss.push(p.name); return; }
      items.push({ name: String(p.name).replace(/'/g, ''), fb: "{ apiKey: '" + w.apiKey + "', authDomain: '" + (w.authDomain || (w.projectId + '.firebaseapp.com')) + "', projectId: '" + (w.projectId || p.project) + "', appId: '" + w.appId + "' }" });
    });
    if (!L.length) return '';
    var first = !PJMAIN && items.length;                               // no main project: the first project is the app's own 'firebase' block, the others are firebaseMore
    var txt = '';
    if (first) txt += '  firebase: ' + items[0].fb.replace(/, /g, ',\n    ').replace('{ ', '{\n    ').replace(' }', '\n  }') + ',\n';
    var rest = first ? items.slice(1) : items;
    txt += rest.length ? '  firebaseMore: [\n' + rest.map(function (x) { return "    { name: '" + x.name + "', firebase: " + x.fb + ' },'; }).join('\n') + '\n  ],' : '  firebaseMore: [],';
    return '<div class="rounded-xl border border-[#e0e3e7] dark:border-[#3c4043] p-3 mt-2 flex flex-col gap-2"><div class="text-sm font-semibold">Lines for config.js of the web apps</div>' +
      '<p class="text-[11px] text-gray-500 dark:text-gray-400">Open <b>config.js</b> of the Parent / Teacher App and ' + (first ? 'replace its <b>firebase: {...},</b> block and its <b>firebaseMore: [...],</b> lines with these lines (inside <b>window.EDUNEST = { ... }</b>)' : 'paste these lines inside <b>window.EDUNEST = { ... }</b> (below the <b>firebase: {...},</b> block)') + ', save, and upload config.js to GitHub again. Add the web address of the apps to <b>Authentication &gt; Settings &gt; Authorized domains</b> of EVERY project, turn on <b>Authentication &gt; Email/Password</b>, and publish firestore.rules in every project. Sections that share a project appear only once here.</p>' +
      (miss.length ? '<p class="text-xs text-amber-700">No web app config yet for: ' + esc(miss.join(', ')) + ' (paste it in one of its sections and Save again).</p>' : '') +
      (items.length ? '<textarea readonly rows="' + (txt.split('\n').length + 1) + '" onclick="this.select()" style="' + TA + '">' + esc(txt) + '</textarea>' : '') + '</div>';
  }
  function pjAct(b, act) {
    var sec = b.getAttribute('data-sec');
    if (act === 'pj-clear') { S[sec] = { cls: (S[sec] || {}).cls || '', pid: '', project: '', key: '', web: '' }; drawProjects(); return; }
    if (act === 'pj-copy') {
      var g = classGroups().filter(function (x) { return x.name === b.getAttribute('data-cls'); })[0]; if (!g) return;
      var src = null; g.secs.forEach(function (s) { var st = S[s.id]; if (!src && st && (st.pid || st.key.trim())) src = st; });
      if (!src) { pjMsg('Open a section of Class ' + g.name + ' and paste its config first.', true); return; }
      g.secs.forEach(function (s) { S[s.id] = { cls: g.name, pid: src.pid, project: src.project, key: src.key, web: src.web }; });
      drawProjects(); return;
    }
    if (act === 'pj-test') {
      var st = secState(sec), res = document.querySelector('[data-sf-res="' + sec + '"]');
      if (!st.key.trim() && !st.pid) { res.className = 'text-xs text-red-600'; res.textContent = 'Paste the service account key first (an empty section is OFF).'; return; }
      res.className = 'text-xs'; res.textContent = 'Testing ...';
      return api('POST', 'cloud-setup/parent-projects/test/', { id: st.pid, key: st.key }).then(function (j) {
        res.innerHTML = (j.results || [{ ok: false, message: 'The test could not run (HTTP ' + j.status + ').' }]).map(function (l) { return '<div class="' + (l.ok ? 'text-green-700' : 'text-red-600') + '">' + (l.ok ? '\u2713 ' : '\u2717 ') + esc(l.message) + '</div>'; }).join('');
      });
    }
    if (act === 'pj-save') {
      var items = [];
      classGroups().forEach(function (c) { c.secs.forEach(function (s) { var st = S[s.id]; if (st && (st.pid || st.key.trim())) items.push({ id: s.id, cls: c.name, pid: st.pid, key: st.key, web: st.web }); }); });
      b.disabled = true; pjMsg('Saving ...');
      return api('POST', 'cloud-setup/parent-projects/', { sections: items }).then(function (j) {
        b.disabled = false;
        if (!j.ok) return pjMsg(j.error || ('Could not save (HTTP ' + j.status + ')'), true);
        PJ = pjFromServer(j.list); buildS();
        PJRES = ''; drawProjects(); PJRES = cfgBlock(); var c = $('pjCfg'); if (c) c.innerHTML = PJRES;
        pjMsg('\u2713 Saved. Sections with a config are sent to their Firebase within a minute; sections without one are OFF. Press "Fetch all data now" above to send everything at once.');
        if (window.__parentApp && window.__parentApp.forcePush) window.__parentApp.forcePush().catch(function () { return null; });                  // the first save switches the Parent App on: send a fresh snapshot now
      });
    }
  }
  document.addEventListener('input', function (e) {
    var f = e.target && e.target.getAttribute && e.target.getAttribute('data-sf'); if (!f || !PJ) return;
    var a = f.split('|'), st = secState(a[1]); st[a[0]] = e.target.value;
    var chip = document.querySelector('[data-sf-chip="' + a[1] + '"]'); if (chip) chip.innerHTML = secChip(st);
  });

  window.cloudFill = load;                       // called by masterTab('cloud') every time the tab is opened
  window.pappFill = load;                        // masterTab('papp'): the Parent App tab (same settings, own tab since 1.0.63)
})();
