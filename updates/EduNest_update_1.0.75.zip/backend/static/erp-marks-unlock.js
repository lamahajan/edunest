/* Mark Entry > "Unlock (Teacher App)": a mark that is already entered is locked in the Teacher App (and hidden, unless the teacher has "can see entered marks").
   This window lets the school office unlock chosen students of ONE subject, so the teacher can correct them once. Saving the correction locks the mark again.
   Admin only (server checks). Costs 1 Firestore read + 1 write per click. The button is added to the Mark Entry toolbar by build_frontend.py. */
(function () {
  'use strict';
  var $ = function (id) { return document.getElementById(id); };
  var esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };
  var toast = function (m) { try { showToast(m); } catch (e) { alert(m); } };
  function close() { var o = $('meUnlockBox'); if (o) o.remove(); }

  // students of the screen that have a mark in column j (what the teacher could not change)
  var entered = function (S, j) { return S.rows.filter(function (r) { return String(r.vals[j] == null ? '' : r.vals[j]).trim() !== ''; }); };

  window.meUnlockOpen = function () {
    var S = window.meSt || (typeof meSt !== 'undefined' ? meSt : null);
    if (!S || S.mode !== 'S' || !S.rows || !S.rows.length) return toast('Press View first (Marks, one assessment).');
    close();
    var o = document.createElement('div'); o.id = 'meUnlockBox';
    o.style.cssText = 'position:fixed;inset:0;z-index:9999;background:rgba(0,0,0,.45);display:flex;align-items:center;justify-content:center;padding:12px';
    var sel = 'width:100%;padding:7px;border-radius:8px;border:1px solid rgba(128,128,128,.4);background:transparent;color:inherit';
    o.innerHTML = '<div class="bg-white dark:bg-[#1e1f20] text-gray-900 dark:text-gray-100" style="border-radius:20px;max-width:560px;width:100%;max-height:90vh;overflow:auto;padding:18px;font:14px system-ui">' +
      '<div style="display:flex;justify-content:space-between;align-items:center"><b style="font-size:16px">Unlock marks (Teacher App)</b><button data-a="close" style="border:0;background:none;font-size:20px;cursor:pointer;color:inherit">✕</button></div>' +
      '<p style="opacity:.7;font-size:12px;margin:4px 0 8px">Marks already saved are locked for the teacher. Tick the students whose mark the teacher may correct; once the teacher saves the correction it locks again. Only marks <b>saved in the ERP</b> are listed.</p>' +
      '<label style="font-size:12px;opacity:.7">Subject</label><select id="muSub" style="' + sel + '">' + S.subs.map(function (x, j) { return '<option value="' + j + '">' + esc(x.name) + '</option>'; }).join('') + '</select>' +
      '<div style="margin:10px 0 4px"><label style="font-size:13px"><input type="checkbox" id="muAll"> Select all</label></div>' +
      '<div id="muList" style="max-height:40vh;overflow:auto;border:1px solid rgba(128,128,128,.35);border-radius:12px;padding:6px"></div>' +
      '<div style="display:flex;gap:8px;margin-top:12px;align-items:center"><button data-a="go" class="rc-btn rc-btn-primary" style="border:0;border-radius:10px;padding:8px 14px;font:600 13px system-ui;cursor:pointer">Unlock selected</button><span id="muMsg" style="font-size:12px;opacity:.8"></span></div></div>';
    document.body.appendChild(o);
    function draw() {
      var j = Number($('muSub').value), L = entered(S, j);
      $('muAll').checked = false;
      $('muList').innerHTML = L.length ? L.map(function (r) {
        return '<label style="display:flex;gap:8px;align-items:center;padding:4px 6px"><input type="checkbox" class="muCk" data-adm="' + esc(r.adm) + '"> <span style="flex:1">' + esc(r.name) +
          ' <small style="opacity:.6">Adm ' + esc(r.adm) + (r.sec ? ' · ' + esc(r.sec) : '') + '</small></span><b>' + esc(r.vals[j]) + '</b></label>';
      }).join('') : '<p style="opacity:.7;padding:8px">No marks entered for this subject on this screen.</p>';
    }
    draw();
    $('muSub').addEventListener('change', draw);
    $('muAll').addEventListener('change', function () { Array.prototype.forEach.call(document.querySelectorAll('#meUnlockBox .muCk'), function (c) { c.checked = $('muAll').checked; }); });
    o.addEventListener('click', function (e) {
      var a = e.target.getAttribute && e.target.getAttribute('data-a');
      if (e.target === o || a === 'close') return close();
      if (a !== 'go') return;
      var j = Number($('muSub').value), sub = S.subs[j], P = window.__parentApp;
      var picked = Array.prototype.map.call(document.querySelectorAll('#meUnlockBox .muCk:checked'), function (c) { return c.getAttribute('data-adm'); });
      if (!picked.length) return toast('Tick at least one student.');
      if (!P || !P.secId) return toast('Cloud Sync (Parent App) is not set up.');
      var cls = $('meCls') ? $('meCls').value : '', bySec = {};
      S.rows.forEach(function (r) { if (picked.indexOf(String(r.adm)) >= 0) { var id = P.secId(cls, r.sec || 'A'); (bySec[id] = bySec[id] || []).push(String(r.adm)); } });
      var ids = Object.keys(bySec), done = 0, fail = '', msg = $('muMsg');
      msg.textContent = 'Unlocking…';
      var next = function () {
        if (!ids.length) { msg.textContent = ''; if (fail) return toast('Could not unlock: ' + fail); close(); return toast('Unlocked ' + done + ' mark(s). The teacher can correct them in the Teacher App.'); }
        var id = ids.shift();
        fetch('/api/sync/cloud-setup/marks-unlock/', { method: 'POST', headers: { 'Authorization': 'Token ' + localStorage.getItem('erp_token'), 'Content-Type': 'application/json' },
          body: JSON.stringify({ secId: id, term: S.term.id, code: S.code, subj: P.subjKey(sub.name), adms: bySec[id] }) })
          .then(function (r) { return r.json().catch(function () { return {}; }).then(function (d) { if (!r.ok || d.ok === false) throw new Error(d.error || d.detail || ('HTTP ' + r.status)); done += d.unlocked || 0; }); })
          .catch(function (er) { fail = (er && er.message) || String(er); })
          .then(next);
      };
      next();
    });
  };
})();
