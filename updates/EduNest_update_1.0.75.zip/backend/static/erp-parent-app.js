/* Parent App + Teacher App (Firestore), browser part. Server part: backend/sync/cloud_parent.py.
   Like the online-fee due list (erp-fee-sync.js), the numbers come from the ERP's OWN engines on this page, so the app shows what the ERP shows:
     fee   rpDueItems (Dues Report): due, months, period text; paid this session and the last 10 receipts (rpRecAmt)
     att   ATT ('date|cls|sec' -> {adm: P/A/L}): whole session, this month, last 30 days
     teachers  TEACH + USERS (login name, active) + ACAD subjects (subject teacher = every section of that class) + class teacher
   One snapshot of every studying student and teacher is posted to /api/sync/parent-app/ when the ERP data changes (attendance saved, receipt,
   admission ...: 5 s later) and every 10 minutes; the server writes only what changed to Firebase, and once every morning everything (full sync). Does nothing when the Parent App is not set up (Setup > School Setup > Cloud Sync).
   secId = CLASS-SECTION in capitals without spaces (5TH-A, PRENURSERY-B): the same in students/{adm}.secId, the login claims and teachers/{uid}.secs.
   Subject key = subject name in small letters, a-z 0-9 _ only (maths, social_science).
   1.0.53: gate passes of the last 30 days go with each student (gp); every teacher with a 10-digit mobile is sent, also without an EduNest
   login user (login name = the mobile then); teachers left out are listed (tskip) so the Cloud Sync card can say why;
   window.__parentApp.forcePush() sends a fresh snapshot at once (Cloud Sync > Force push all data now). */
(function () {
  'use strict';
  var TOKEN = localStorage.getItem('erp_token'), ON = null, LAST = '', LASTAT = 0, DENIED = false;
  function api(method, body) {
    return fetch('/api/sync/parent-app/', { method: method, headers: { 'Authorization': 'Token ' + TOKEN, 'Content-Type': 'application/json' }, body: body === undefined ? undefined : JSON.stringify(body) })
      .then(function (r) { if (r.status === 403) DENIED = true; return r.ok ? r.json() : null; }).catch(function () { return null; });
  }
  function ready() {
    try { return typeof rpDueItems === 'function' && typeof rpActive === 'function' && typeof RC_STUDENTS !== 'undefined' && typeof SESS !== 'undefined' && typeof ATT !== 'undefined' && typeof TEACH !== 'undefined' && typeof acadKeys === 'function'; } catch (e) { return false; }
  }
  // the session TODAY belongs to (April - March), not simply the last one: after Promotion the next session already exists while the school still works in this one
  function workSession() {
    try {
      var a = JSON.parse(localStorage.getItem('eacademics_sessions') || '[]').filter(function (x) { return !x.upcoming; }); if (!a.length) return SESS;   // an UPCOMING session (1.0.68) is not the school's session yet
      var t = rcToday(), y = +t.slice(0, 4), m = +t.slice(5, 7), start = String(m >= 4 ? y : y - 1);
      var hit = a.filter(function (x) { return String(x.id || '').indexOf(start) === 0; })[0];
      return hit ? hit.id : a[a.length - 1].id;
    } catch (e) { return SESS; }
  }
  var norm = function (s) { return String(s || '').toUpperCase().replace(/[^A-Z0-9]/g, ''); };
  function secId(cls, sec) { return norm(cls) + (norm(sec) ? '-' + norm(sec) : ''); }
  function subjKey(name) { var k = String(name || '').toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, ''); return !k ? 'subject' : /^[0-9]/.test(k) ? 's_' + k : k; }
  function ymd(d) { return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }

  function attendance(today) {
    var start = (typeof FEEPLAN !== 'undefined' && FEEPLAN && FEEPLAN.sessStart) || (String(SESS).slice(0, 4) + '-04-01');
    var d30 = new Date(today + 'T00:00:00'); d30.setDate(d30.getDate() - 29); var from30 = ymd(d30), mon = today.slice(0, 7), out = {};
    Object.keys(ATT).forEach(function (k) {
      var d = k.split('|')[0]; if (!d || d < start || d > today) return;
      var marks = ATT[k] || {};
      Object.keys(marks).forEach(function (adm) {
        var v = marks[adm]; if (v !== 'P' && v !== 'A' && v !== 'L') return;
        var o = out[adm] = out[adm] || { s: { P: 0, A: 0, L: 0 }, m: { P: 0, A: 0, L: 0 }, mon: mon, d: {} };
        o.s[v]++; if (d.slice(0, 7) === mon) o.m[v]++; if (d >= from30) o.d[d] = v;
      });
    });
    return out;
  }

  // receipts grouped by student once per snapshot (before: the whole receipt list was searched again for every student)
  function receiptsByAdm() {
    var m = {};
    RC_RECEIPTS.forEach(function (r) { if (r && !r.cancelled) (m[r.adm] = m[r.adm] || []).push(r); });
    return m;
  }
  function fees(adm, today, byAdm) {
    var f = { due: 0, months: 0, period: '', paid: 0, asOn: today, rc: [], bal: 0, sessionFee: 0 };
    try { var x = rpDueItems(adm, today); f.due = Math.max(0, Math.round(x.total)); if (f.due > 0) { f.months = x.per.length; f.period = x.per.length ? rcPeriodText(new Set(x.per)) : ''; } } catch (e) {}
    try {
      var R = (byAdm ? (byAdm[adm] || []) : RC_RECEIPTS.filter(function (r) { return r.adm === adm && !r.cancelled; })).map(function (r) { return { no: String(r.rno), date: r.date, amt: Math.round(rpRecAmt(r)), mode: r.mode || '' }; });
      f.paid = R.reduce(function (t, r) { return t + r.amt; }, 0);
      f.rc = R.sort(function (a, b) { return String(b.date).localeCompare(String(a.date)) || (+b.no || 0) - (+a.no || 0); }).slice(0, 10);
    } catch (e) {}
    try {
      var savedLgAdm = typeof lg !== 'undefined' ? lg.adm : null;
      if (typeof lg !== 'undefined') lg.adm = adm;
      var b = typeof lgBuild === 'function' ? lgBuild() : null;
      if (b && b.groups && b.groups.length) {
        var due = b.groups.reduce(function (s, g) { return s + g.due.reduce(function (a, b) { return a + b; }, 0); }, 0);
        var rec = b.groups.reduce(function (s, g) { return s + g.rec.reduce(function (a, b) { return a + b; }, 0); }, 0);
        var opn = b.groups[0].open.reduce(function (a, b) { return a + b; }, 0);
        f.bal = Math.max(0, Math.round(opn + due - rec));
        f.sessionFee = Math.round(b.groups.reduce(function (s, g) { return s + g.fee.reduce(function (a, b) { return a + b; }, 0); }, 0));
      }
      if (typeof lg !== 'undefined') lg.adm = savedLgAdm;
    } catch (e) {}
    if (!f.sessionFee) {
      f.sessionFee = f.paid + f.due;
      f.bal = f.due;
    }
    return f;
  }

  var TSKIP = [];
  function mob10(v) { var d = String(v || '').replace(/\D/g, ''); if (d.length > 10 && /^(91|0)/.test(d)) d = d.slice(-10); return /^[6-9]\d{9}$/.test(d) ? d : ''; }
  function teachers() {
    var users = typeof USERS !== 'undefined' ? USERS : [], out = [], seen = {};
    TSKIP = [];
    TEACH.forEach(function (t) {
      if (!t || !t.name) return;
      var u = users.filter(function (x) { return x.id === t.userId; })[0];
      if (u && u.active === false) { TSKIP.push(t.name + ' (login deactivated)'); return; }
      var m = mob10(t.mobile);
      var login = u && u.username ? String(u.username).toLowerCase() : m;     // no EduNest login user: the mobile number is the login name
      if (!login) { TSKIP.push(t.name + ' (no mobile number and no login)'); return; }
      if (seen[login]) { TSKIP.push(t.name + ' (same login / mobile as ' + seen[login] + ')'); return; }
      seen[login] = t.name;
      var secs = {}, subj = {}, ct = '', ctSubj = {};
      acadKeys().forEach(function (k) {
        var c = CLASSES.filter(function (x) { return x.name === k.cls; })[0] || {}, sections = (c.sections && c.sections.length) ? c.sections : ['A'];
        acadSubsOf(k.key).forEach(function (s) {
          if (s.teacher !== t.name) return;
          var key = subjKey(s.name); subj[key] = s.name;
          sections.forEach(function (sc) { var id = secId(k.cls, sc), a = secs[id] = secs[id] || []; if (a.indexOf(key) < 0) a.push(key); });
        });
      });
      if (typeof t.classTeacher === 'string' && t.classTeacher) {
        var p = t.classTeacher.split('||'); ct = secId(p[0], p[1]);
        acadKeys().forEach(function (k) { if (k.cls === p[0]) acadSubsOf(k.key).forEach(function (s) { ctSubj[subjKey(s.name)] = s.name; }); });
      }
      var pr = !!(u && /^(principal|administrator|vice principal)$/i.test(String(u.role || '')));   // may post school-wide notices from the Teacher App
      out.push({ user: login, name: t.name, mob: m || t.mobile || '', secs: secs, subj: subj, ct: ct, ctSubj: ctSubj, pr: pr, sf: !!t.showFilled });
    });
    return out;
  }

  // Teacher App mark entry (server: sync/cloud_marks.py). The same lists Mark Entry uses: active terms and their assessments, Scholastic subjects of each
  // class (- stream) with the max marks per assessment (Class-wise Assessment applied, max 0 = no marks), and the studying students of each section.
  function marksSetup() {
    try {
      if (typeof ACAD === 'undefined' || typeof mrStudents !== 'function' || typeof acadSubsOf !== 'function' || typeof amapCodes !== 'function' || typeof asByCode !== 'function') return null;
      var terms = (ACAD.terms || []).filter(function (t) { return t && t.id && t.active !== false; })
        .map(function (t) { return { id: String(t.id), n: t.name || String(t.id), c: (t.assess || []).filter(function (c) { return !!asByCode(c); }) }; });
      var as = {}; (ACAD.assess || []).forEach(function (a) { as[a.code] = a.name || a.code; });
      var secs = {};
      mrStudents().forEach(function (st) {
        if (!st.adm || /[\/\s~`]/.test(String(st.adm))) return;
        var id = secId(st.cls, st.sec), o = secs[id] = secs[id] || { keys: {}, st: [] };
        o.st.push([String(st.adm), st.name || '', String(st.roll || ''), st.key]);
        if (o.keys[st.key]) return;
        var codes = amapCodes(st.key), subs = {};
        acadSubsOf(st.key).filter(function (x) { return (x.kind || 'Scholastic') === 'Scholastic'; }).forEach(function (x) {
          var mx = {};
          codes.forEach(function (c) { var a = asByCode(c), cell = ((ACAD.marks[st.key] || {})[x.name] || {})[c] || { max: a.max }; var m = Number(cell.max) || 0; if (m > 0) mx[c] = m; });
          if (Object.keys(mx).length) subs[subjKey(x.name)] = { n: x.name, mx: mx };
        });
        o.keys[st.key] = subs;
      });
      return { terms: terms, as: as, secs: secs };
    } catch (e) { console.log('marks setup failed', e); return null; }
  }

  // gate passes of the last 30 days per student (read from storage: the gate pass screen and the eGateSys sync keep it current)
  function gatePasses(today) {
    var all = [];
    try { all = JSON.parse(localStorage.getItem('eacademics_gp') || '[]') || []; } catch (e) { try { all = typeof GP !== 'undefined' ? GP : []; } catch (x) { all = []; } }
    var d30 = new Date(today + 'T00:00:00'); d30.setDate(d30.getDate() - 30); var from = ymd(d30), out = {};
    all.forEach(function (e) {
      if (!e || e.type === 'Visitor' || !e.adm || !e.date || e.date < from || e.date > today) return;
      var st = e.outTime ? 'out' : (e.needApr && !e.apr ? 'pending' : 'issued');
      (out[e.adm] = out[e.adm] || []).push({ id: e.id || '', date: e.date, time: e.time || '', by: e.takenBy || '', rel: e.relation || '', reason: e.reason || '',
        out: e.outTime || '', outBy: e.outBy || '', st: st, ts: e.ts || 0 });
    });
    Object.keys(out).forEach(function (k) { out[k].sort(function (a, b) { return (b.date + b.time).localeCompare(a.date + a.time) || b.ts - a.ts; }); out[k] = out[k].slice(0, 10).map(function (x) { delete x.ts; return x; }); });
    return out;
  }

  // 1.0.65: the snapshot works out the fee dues of EVERY studying student. Done in one go it froze Chrome for many seconds in a big school
  // ("Page unresponsive - Wait / Exit page"), on every page load and again 5 s after every save. snapshotAsync() does the students in
  // small slices (about 25 ms each) so the page stays usable; snapshot() (all at once) is kept for tests / the console.
  function studentRow(r, today, att, gps, byAdm) {
    var st = RC_STUDENTS[r.adm] || {};
    return {
      name: admName(r) || st.name || '', cls: r.cls || st.cls || '', sec: r.sec || st.sec || '', secId: secId(r.cls || st.cls, r.sec || st.sec), roll: String(r.roll || ''),
      dob: r.dob || '', father: r.father || '', mother: r.mother || '', gender: r.gender || '', addr: [r.addr, r.city].filter(Boolean).join(', '), mob: r.mobile || '',
      fee: fees(r.adm, today, byAdm), att: att[r.adm] || { s: { P: 0, A: 0, L: 0 }, m: { P: 0, A: 0, L: 0 }, mon: today.slice(0, 7), d: {} }, gp: gps[r.adm] || []
    };
  }
  function okAdm(r) { return r && r.adm && !/[\/\s]/.test(String(r.adm)); }
  function finish(today, stu) {
    var tl = teachers();
    return { session: SESS, today: today, school: (typeof SCHOOL !== 'undefined' && SCHOOL && SCHOOL.name) || '', students: stu, teachers: tl, tskip: TSKIP.slice(), marks: marksSetup() };
  }
  function snapshot() {
    var today = rcToday(), att = attendance(today), gps = gatePasses(today), byAdm = receiptsByAdm(), stu = {};
    rpActive().forEach(function (r) { if (okAdm(r)) stu[r.adm] = studentRow(r, today, att, gps, byAdm); });
    return finish(today, stu);
  }
  function snapshotAsync() {
    return new Promise(function (resolve, reject) {
      try {
        var today = rcToday(), active = rpActive().filter(okAdm), att = attendance(today), gps = gatePasses(today), byAdm = receiptsByAdm(), stu = {}, i = 0;
        (function step() {
          try {
            var t = Date.now();
            while (i < active.length && Date.now() - t < 25) { var r = active[i++]; stu[r.adm] = studentRow(r, today, att, gps, byAdm); }
            if (i < active.length) return setTimeout(step, 0);
            setTimeout(function () { try { resolve(finish(today, stu)); } catch (e) { reject(e); } }, 0);
          } catch (e) { reject(e); }
        })();
      } catch (e) { reject(e); }
    });
  }

  var RUN = null, AGAIN = false;
  function send(force) {
    if (ON !== true || DENIED || !ready()) return Promise.resolve(null);
    if (workSession() !== SESS) return Promise.resolve(force ? { error: 'The open session is not the session of today. Switch to the current session first.' } : null);
    if (!rpActive().length) return Promise.resolve(null);                                  // nothing loaded yet: never send an empty list
    if (RUN) { if (!force) { AGAIN = true; return RUN; } return RUN.then(function () { return send(true); }); }   // never two snapshots at the same time
    RUN = snapshotAsync().then(function (s) {
      var sig = JSON.stringify(s);
      if (!force && sig === LAST && Date.now() - LASTAT < 600000) return null;
      if (force) s.force = true;
      return api('POST', s).then(function (j) { if (j) { LAST = sig; LASTAT = Date.now(); ON = j.on; } return j; });
    }, function (e) { console.log('parent app snapshot failed', e); return null; }).then(function (j) {
      RUN = null;
      if (AGAIN) { AGAIN = false; setTimeout(send, 1000); }
      return j;
    });
    return RUN;
  }
  // Cloud Sync > "Force push all data now": a fresh snapshot right now (also when nothing changed)
  function forcePush() {
    if (!TOKEN) return Promise.resolve({ error: 'not logged in' });
    var go = function () { return ready() ? send(true) : Promise.resolve({ error: 'EduNest data is still loading, try again in a minute' }); };
    if (ON === true) return go();
    return api('GET').then(function (j) { if (!j || !j.on) return { error: 'Parent App is not set up' }; ON = true; return go(); });
  }
  window.__parentApp = { snapshot: snapshot, snapshotAsync: snapshotAsync, send: send, forcePush: forcePush, secId: secId, subjKey: subjKey, marksSetup: marksSetup };

  function start() {
    if (!TOKEN) return;
    api('GET').then(function (j) {
      if (!j || !j.on) return;                                                             // not set up (or no permission): nothing runs
      ON = true;
      var wait = setInterval(function () {
        if (!ready()) return; clearInterval(wait); setTimeout(send, 15000);                // first snapshot a little after the page opened (1.0.65)
        var dt = null;
        window.addEventListener('erp-changed', function () { clearTimeout(dt); dt = setTimeout(send, 5000); });
        document.addEventListener('visibilitychange', function () { if (!document.hidden) send(); });
        setInterval(function () { if (!document.hidden) send(); }, 600000);                // safety net (and the new day's attendance)
      }, 1000);
    });
  }
  start();
})();
