/* Setup > School Setup > "Cloud Sync" tab (administrators only): connect the cloud apps (eGateSys, Result portal, online fee, attendance) to this ERP.
   Fill a card, press Test, then Save: it is saved on the school server (data/config.env) and starts working at once (no restart).
   Disconnect stops that app's sync at once and forgets its address / secrets. A secret is never shown again.
   Parent App (Firestore): the service account JSON goes in a text box, and the card has "Reset a password" (cloud_parent.reset_password).
   The tab and its panel are part of the ERP page (see build_frontend.py); this file fills the panel in.
   1.0.53: "Force push all data now" bar at the top (fresh Parent App + due list snapshot from this page, then every connected app sends
   everything again: runtime.push_all), and "Notices & announcements" on the Parent App card (cloud_parent.notices_save -> notices/board). */
(function () {
  'use strict';
  var G = [], TOKEN = function () { return localStorage.getItem('erp_token'); };
  var $ = function (id) { return document.getElementById(id); };
  var esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };
  function api(method, url, body) {
    return fetch('/api/sync/' + url, { method: method, headers: { 'Authorization': 'Token ' + TOKEN(), 'Content-Type': 'application/json' }, body: body === undefined ? undefined : JSON.stringify(body) })
      .then(function (r) { return r.json().catch(function () { return {}; }).then(function (j) { j.status = r.status; return j; }); });
  }
  function admin() { try { return typeof usrCan === 'function' && usrCan('adminZone', 'edit'); } catch (e) { return false; } }
  function note(text, bad) { var n = $('cloudSetupNote'); if (n) { n.textContent = text || ''; n.className = 'text-xs min-h-[1rem] ' + (bad ? 'text-red-600' : 'text-green-700'); } }

  var NOTICES = [], NEDIT = null;
  var inp = 'border:1px solid #c4c7c5;border-radius:10px;padding:7px 10px;background:transparent;color:inherit;width:100%';
  function draw() {
    $('cloudSetupBody').innerHTML = G.map(function (g) {
      var f = g.fields.map(function (x) {
        if (x.kind === 'check') return '<div class="mf"><label class="flex items-center gap-2 text-sm cursor-pointer" style="position:static;transform:none;padding:0;background:none;pointer-events:auto"><input type="checkbox" data-key="' + x.key + '"' + (((x.value || x.default) === '1') ? ' checked' : '') + '> ' + esc(x.label) + '</label>' +
          (x.help ? '<div class="text-[11px] text-gray-500 dark:text-gray-400 mt-0.5">' + esc(x.help) + '</div>' : '') + '</div>';
        if (x.kind === 'json') return '<div class="mf"><label>' + esc(x.label) + (x.set ? ' <span class="font-normal text-gray-500"><input type="checkbox" data-clear="' + x.key + '"> remove the saved one</span>' : '') + '</label>' +
          '<textarea data-key="' + x.key + '" rows="3" autocomplete="off" autocapitalize="off" autocorrect="off" spellcheck="false" data-nocap style="width:100%;font:12px monospace;border:1px solid #c4c7c5;border-radius:10px;padding:8px;background:transparent;color:inherit" placeholder="' + (x.set ? '\u25CF\u25CF\u25CF\u25CF saved (leave empty to keep)' : '{ &quot;type&quot;: &quot;service_account&quot;, ... }') + '"></textarea>' +
          (x.help ? '<div class="text-[11px] text-gray-500 dark:text-gray-400 mt-0.5">' + esc(x.help) + '</div>' : '') + '</div>';
        var ph = x.kind === 'secret' ? (x.set ? '\u25CF\u25CF\u25CF\u25CF saved (leave empty to keep)' : '') : (x.default || '');
        return '<div class="mf"><label>' + esc(x.label) + (x.kind === 'secret' && x.set ? ' <span class="font-normal text-gray-500"><input type="checkbox" data-clear="' + x.key + '"> remove the saved one</span>' : '') + '</label>' +
          '<input ' + (x.kind === 'secret' ? 'type="password" autocomplete="new-password" autocapitalize="off"' : 'type="text" autocomplete="off" autocapitalize="off" autocorrect="off" spellcheck="false"') + ' data-key="' + x.key + '" value="' + esc(x.value) + '" placeholder="' + esc(ph) + '">' +
          (x.help ? '<div class="text-[11px] text-gray-500 dark:text-gray-400 mt-0.5">' + esc(x.help) + '</div>' : '') + '</div>';
      }).join('');
      return '<div class="rounded-2xl border border-[#e0e3e7] dark:border-[#3c4043] p-4 flex flex-col gap-3" data-cs-group="' + g.id + '">' +
        '<div class="flex items-center justify-between gap-2"><div><div class="rc-card-title"><span class="material-symbols-outlined">cloud_sync</span>' + esc(g.title) + '</div><p class="text-xs text-gray-500 dark:text-gray-400">' + esc(g.sub) + '</p></div>' +
        badge(g) + '</div>' + f +
        '<div class="flex flex-wrap gap-2"><button type="button" class="rc-btn" data-act="test" data-g="' + g.id + '">Test</button><button type="button" class="rc-btn rc-btn-primary" data-act="save" data-g="' + g.id + '">Save</button>' +
        (g.on ? '<button type="button" class="rc-btn" data-act="pushall" data-g="' + g.id + '" data-t="' + esc(g.title) + '" title="Sends everything of this app again, now. Nothing in EduNest is changed."><span class="material-symbols-outlined">cloud_upload</span>Force push now</button>' : '') +
        (g.on ? '<button type="button" class="rc-btn" data-act="fetch" data-g="' + g.id + '" title="' + (g.id === 'contacts' ? 'Sends every parent and teacher number to Google Contacts again.' : g.id === 'students' ? 'Replaces the student list in the cloud with the list of students studying now.' : 'Brings in everything the cloud has (also what came while this was not connected). Nothing in the cloud is deleted.') + '"><span class="material-symbols-outlined">download</span>' + (g.id === 'contacts' ? 'Send all contacts now' : g.id === 'students' ? 'Send student list now' : 'Fetch all data now') + '</button>' : '') +
        (g.on ? '<button type="button" class="rc-btn ml-auto text-red-600" data-act="disconnect" data-g="' + g.id + '" data-t="' + esc(g.title) + '">Disconnect</button>' : '') + '</div>' +
        '<div class="text-xs" data-cs-res="' + g.id + '"></div>' + (g.id === 'papp' && g.on ? resetBox() + '<p class="text-[11px] text-gray-500 dark:text-gray-400 border-t border-[#e0e3e7] dark:border-[#3c4043] pt-3">Notices &amp; announcements: open the 9-dot menu &gt; Front Desk &gt; Notices.</p>' : '') + '</div>';
    }).join('');
  }

  // ---- Notices & announcements (Parent App + Teacher App home screen)
  function secList() {
    var out = [];
    try { (typeof CLASSES !== 'undefined' ? CLASSES : []).forEach(function (c) { ((c.sections && c.sections.length) ? c.sections : ['A']).forEach(function (sc) {
      var id = window.__parentApp ? window.__parentApp.secId(c.name, sc) : String(c.name + '-' + sc).toUpperCase().replace(/[^A-Z0-9-]/g, '');
      out.push([id, c.name + ' - ' + sc]); }); }); } catch (e) {}
    return out;
  }
  function noticeBox() {
    return '<div class="flex flex-col gap-2"><p class="text-[11px] text-gray-500 dark:text-gray-400">Shown on the home screen of the Parent App and / or Teacher App within a few seconds. Teachers can also post notices to their own classes from the Teacher App.</p>' +
      '<div id="pappNoticeList" class="flex flex-col gap-2 text-sm">Loading ...</div><div id="pappNoticeForm"></div></div>';
  }
  // Separate popup (9-dot menu > Front Desk > Notices)
  window.openNotices = function () {
    var wm = $('waffleMenu'); if (wm) wm.classList.add('hidden');
    var m = $('noticeModal');
    if (!m) {
      m = document.createElement('div'); m.id = 'noticeModal';
      m.className = 'fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4';
      m.innerHTML = '<div class="w-full max-w-2xl max-h-[90vh] flex flex-col rounded-3xl bg-white dark:bg-[#282a2c] text-[#1f1f1f] dark:text-[#e3e3e3] border border-[#dadce0] dark:border-[#3c4043] shadow-2xl">' +
        '<div class="flex items-center justify-between gap-3 px-5 py-4 border-b border-[#e0e3e7] dark:border-[#3c4043]"><div class="rc-card-title" style="margin:0"><span class="material-symbols-outlined">notifications_active</span>Notices &amp; Announcements</div>' +
        '<button type="button" class="rc-btn" data-act="nclose" title="Close"><span class="material-symbols-outlined">close</span></button></div>' +
        '<div id="noticeModalBody" class="overflow-y-auto p-5"></div></div>';
      m.addEventListener('click', function (e) { if (e.target === m) m.classList.add('hidden'); });
      document.body.appendChild(m);
    }
    m.classList.remove('hidden');
    $('noticeModalBody').innerHTML = noticeBox();
    if (!TOKEN()) { $('pappNoticeList').innerHTML = '<p class="text-sm text-red-600">Please log in to the ERP first.</p>'; return; }
    NEDIT = null; loadNotices();
  };
  function loadNotices() {
    api('GET', 'cloud-setup/notices/').then(function (j) {
      if (j.status === 403) { var L = $('pappNoticeList'); if (L) L.innerHTML = '<p class="text-sm text-red-600">Only an administrator can post notices. Log in as the administrator.</p>'; var F = $('pappNoticeForm'); if (F) F.innerHTML = ''; return; }
      NOTICES = j.list || []; drawNotices();
    });
  }
  function audText(n) { return (n.aud === 'p' ? 'Parents' : n.aud === 't' ? 'Teachers' : 'Everyone') + (n.secs && n.secs.length ? ' of ' + n.secs.join(', ') : ''); }
  function drawNotices() {
    var L = $('pappNoticeList'), F = $('pappNoticeForm'); if (!L) return;
    L.innerHTML = NOTICES.length ? NOTICES.map(function (n, i) {
      var old = n.exp && n.exp < new Date().toISOString().slice(0, 10);
      return '<div class="rounded-xl border border-[#e0e3e7] dark:border-[#3c4043] p-3 flex gap-3 items-start" style="' + (old ? 'opacity:.55' : '') + '"><div style="flex:1;min-width:0"><div class="font-semibold">' + (n.pin ? '\uD83D\uDCCC ' : '') + esc(n.t || '(no title)') + '</div>' +
        '<div class="text-xs text-gray-500 dark:text-gray-400">' + esc(n.date) + ' \u00B7 ' + esc(audText(n)) + (n.exp ? ' \u00B7 until ' + esc(n.exp) + (old ? ' (expired)' : '') : '') + '</div>' +
        (n.b ? '<div class="text-xs mt-1" style="white-space:pre-wrap">' + esc(n.b) + '</div>' : '') + '</div>' +
        '<button type="button" class="rc-btn" data-act="nedit" data-i="' + i + '">Edit</button><button type="button" class="rc-btn text-red-600" data-act="ndel" data-i="' + i + '">Delete</button></div>';
    }).join('') : '<p class="text-xs text-gray-500">No notices yet.</p>';
    var n = NEDIT || { t: '', b: '', aud: 'all', secs: [], exp: '', pin: false };
    var secs = secList();
    F.innerHTML = '<div class="rounded-xl border border-[#e0e3e7] dark:border-[#3c4043] p-3 flex flex-col gap-2"><div class="text-sm font-semibold">' + (NEDIT ? 'Edit notice' : 'New notice') + '</div>' +
      '<input id="pnT" type="text" maxlength="140" placeholder="Title, e.g. Annual Sports Day" value="' + esc(n.t) + '" style="' + inp + '">' +
      '<textarea id="pnB" rows="3" maxlength="3000" placeholder="Message" style="' + inp + '">' + esc(n.b) + '</textarea>' +
      '<div class="flex flex-wrap gap-2 items-center"><label class="text-xs">For <select id="pnA" style="' + inp + ';width:auto">' +
      [['all', 'Everyone (parents and teachers)'], ['p', 'Parents only'], ['t', 'Teachers only']].map(function (o) { return '<option value="' + o[0] + '"' + (n.aud === o[0] ? ' selected' : '') + '>' + o[1] + '</option>'; }).join('') + '</select></label>' +
      '<label class="text-xs">Show until <input id="pnE" type="date" value="' + esc(n.exp) + '" style="' + inp + ';width:auto"></label>' +
      '<label class="text-xs flex items-center gap-1"><input id="pnP" type="checkbox"' + (n.pin ? ' checked' : '') + '> Pin on top</label></div>' +
      (secs.length ? '<details' + (n.secs && n.secs.length ? ' open' : '') + '><summary class="text-xs cursor-pointer">Only some classes? (none ticked = the whole school)</summary><div class="flex flex-wrap gap-2 mt-2">' +
        secs.map(function (x) { return '<label class="text-xs flex items-center gap-1" style="border:1px solid #c4c7c5;border-radius:999px;padding:3px 9px"><input type="checkbox" data-nsec="' + esc(x[0]) + '"' + ((n.secs || []).indexOf(x[0]) >= 0 ? ' checked' : '') + '>' + esc(x[1]) + '</label>'; }).join('') + '</div></details>' : '') +
      '<div class="flex gap-2"><button type="button" class="rc-btn rc-btn-primary" data-act="nsave">' + (NEDIT ? 'Save changes' : 'Post notice') + '</button>' + (NEDIT ? '<button type="button" class="rc-btn" data-act="ncancel">Cancel</button>' : '') + '</div><div class="text-xs" id="pnRes"></div></div>';
  }
  function saveNotices(list, msg) {
    var r = $('pnRes'); if (r) { r.className = 'text-xs'; r.textContent = 'Saving ...'; }
    return api('POST', 'cloud-setup/notices/', { list: list }).then(function (j) {
      if (!j.ok) { if (r) { r.className = 'text-xs text-red-600'; r.textContent = j.error || ('Could not save (HTTP ' + j.status + ')'); } return; }
      NOTICES = j.list; NEDIT = null; drawNotices(); var r2 = $('pnRes'); if (r2) { r2.className = 'text-xs text-green-700'; r2.textContent = '\u2713 ' + msg; }
    });
  }
  function resetBox() {
    return '<div class="border-t border-[#e0e3e7] dark:border-[#3c4043] pt-3 flex flex-col gap-2"><div class="text-sm font-semibold">Reset a password</div>' +
      '<p class="text-[11px] text-gray-500 dark:text-gray-400">The password goes back to the mobile number (parent: Mobile No 1 of the admission form; teacher: mobile in Setup &gt; Teachers).</p>' +
      '<div class="flex flex-wrap gap-2 items-center"><select id="pappResetKind" class="rc-input" style="border:1px solid #c4c7c5;border-radius:10px;padding:7px 10px;background:transparent;color:inherit"><option value="p">Parent (admission no)</option><option value="t">Teacher (login name)</option></select>' +
      '<input id="pappResetId" type="text" autocomplete="off" autocapitalize="off" data-nocap placeholder="Admission no / login name" style="border:1px solid #c4c7c5;border-radius:10px;padding:7px 10px;background:transparent;color:inherit">' +
      '<button type="button" class="rc-btn" data-act="preset" data-g="papp">Reset password</button></div><div class="text-xs" id="pappResetRes"></div></div>';
  }
  function badge(g) {
    var st = g.running ? ['RUNNING', 'border-green-600 text-green-700'] : g.on ? ['SET UP, NOT RUNNING', 'border-amber-500 text-amber-700'] : ['OFF', 'border-gray-300 text-gray-500'];
    return '<span class="px-2 py-0.5 rounded-full text-[11px] font-bold border ' + st[1] + '">' + st[0] + '</span>';
  }
  function collect(gid) {
    var card = document.querySelector('[data-cs-group="' + gid + '"]'), values = {}, clear = [];
    card.querySelectorAll('input[data-key], textarea[data-key]').forEach(function (i) { values[i.getAttribute('data-key')] = i.type === 'checkbox' ? (i.checked ? '1' : '0') : i.value; });
    card.querySelectorAll('input[data-clear]').forEach(function (c) { if (c.checked) clear.push(c.getAttribute('data-clear')); });
    return { values: values, clear: clear };
  }
  function show(gid, lines) {
    document.querySelector('[data-cs-res="' + gid + '"]').innerHTML = lines.map(function (l) { return '<div class="' + (l.ok ? 'text-green-700' : 'text-red-600') + '">' + (l.ok ? '\u2713 ' : '\u2717 ') + esc(l.message) + '</div>'; }).join('');
  }
  function fail(text) { $('cloudSetupBody').innerHTML = '<p class="text-sm text-red-600">' + esc(text) + '</p>'; }

  function load() {
    note('');
    if (!TOKEN()) return fail('Please log in to the ERP first.');
    $('cloudSetupBody').innerHTML = '<p class="text-sm text-gray-500">Loading ...</p>';
    api('GET', 'cloud-setup/').then(function (j) {
      if (j.status === 403) return fail('Only an administrator can change the cloud connections. Log in as the administrator.');
      if (!j.groups) return fail('Could not load the settings (HTTP ' + j.status + ').');
      G = j.groups; draw();
    });
  }
  document.addEventListener('click', function (e) {
    var b = e.target.closest && e.target.closest('#cloudSetupBody button[data-act], #noticeModal button[data-act]'); if (!b) return;
    var gid = b.getAttribute('data-g'), act = b.getAttribute('data-act');
    if (act === 'nclose') { $('noticeModal').classList.add('hidden'); return; }
    if (act === 'nedit') { NEDIT = JSON.parse(JSON.stringify(NOTICES[+b.getAttribute('data-i')])); drawNotices(); $('pnT').focus(); return; }
    if (act === 'ncancel') { NEDIT = null; drawNotices(); return; }
    if (act === 'ndel') {
      var dn = NOTICES[+b.getAttribute('data-i')]; if (!window.confirm('Delete the notice "' + (dn.t || '') + '"? It disappears from the apps.')) return;
      return saveNotices(NOTICES.filter(function (x) { return x !== dn; }), 'Deleted');
    }
    if (act === 'nsave') {
      var n = { id: NEDIT ? NEDIT.id : '', date: NEDIT ? NEDIT.date : '', t: $('pnT').value.trim(), b: $('pnB').value.trim(), aud: $('pnA').value, exp: $('pnE').value, pin: $('pnP').checked,
        secs: [].slice.call(document.querySelectorAll('#pappNoticeForm input[data-nsec]:checked')).map(function (c) { return c.getAttribute('data-nsec'); }) };
      if (!n.t) { $('pnRes').className = 'text-xs text-red-600'; $('pnRes').textContent = 'Type a title'; return; }
      var list = NEDIT ? NOTICES.map(function (x) { return x.id === NEDIT.id ? n : x; }) : [n].concat(NOTICES);
      return saveNotices(list, NEDIT ? 'Saved. The apps show it within a minute.' : 'Posted. The apps show it within a minute.');
    }
    if (act === 'pushall') {
      var pt = b.getAttribute('data-t') || gid;
      if (!window.confirm('Force push ' + pt + ' now?\n\nEverything of this app is sent again. Nothing in EduNest is changed. The first time it can take a few minutes.' + (gid === 'papp' ? '\n\nFree Firebase allows 20,000 writes a day; this uses about 2 per student (7,000 for 3,500 students). Do it only when needed, not every day.' : ''))) return;
      b.disabled = true; show(gid, [{ ok: true, message: 'Preparing a fresh copy of the data on this page ...' }]);
      var pre = [];
      if (gid === 'papp' && window.__parentApp && window.__parentApp.forcePush) pre.push(window.__parentApp.forcePush().catch(function () { return null; }));
      if (gid === 'fee' && window.__feeSync && window.__feeSync.sendDues) pre.push(Promise.resolve().then(function () { return window.__feeSync.sendDues(); }).catch(function () { return null; }));
      return Promise.all(pre).then(function (r) {
        var warn = (gid === 'papp' && r[0] && r[0].error) ? [{ ok: false, message: 'Parent App: ' + r[0].error }] : [];
        return api('POST', 'cloud-setup/push/', { group: gid }).then(function (j) {
          if (!j.ok) { b.disabled = false; return show(gid, warn.concat([{ ok: false, message: j.error || ('Could not start (HTTP ' + j.status + ').') }])); }
          var tries = 0;
          (function poll() {
            api('GET', 'cloud-setup/push/').then(function (x) {
              var p = (x.one || {})[gid] || {};
              if (p.state === 'running' && tries++ < 450) { show(gid, warn.concat([{ ok: true, message: 'Pushing ...' }])); return setTimeout(poll, 2000); }
              b.disabled = false;
              show(gid, warn.concat([{ ok: p.state === 'done', message: p.state === 'running' ? 'Still running in the background.' : (p.state === 'done' ? 'Finished: ' : 'Failed: ') + (p.text || '') }]));
            });
          })();
        });
      });
    }
    if (act === 'disconnect') {
      if (!window.confirm('Disconnect ' + b.getAttribute('data-t') + '?\n\nSyncing with this app stops now and its saved address and secrets are removed from this server. Nothing in the cloud app itself is deleted. You can connect again any time.')) return;
      b.disabled = true;
      return api('POST', 'cloud-setup/disconnect/', { group: gid }).then(function (j) {
        b.disabled = false;
        if (!j.groups) return show(gid, [{ ok: false, message: 'Could not disconnect (HTTP ' + j.status + ').' }]);
        G = j.groups; draw(); note('Disconnected. Syncing with ' + b.getAttribute('data-t') + ' has stopped.');
      });
    }
    if (act === 'preset') {
      var id = ($('pappResetId').value || '').trim(), kind = $('pappResetKind').value, out = $('pappResetRes');
      if (!id) { out.className = 'text-xs text-red-600'; out.textContent = 'Type the admission no / login name'; return; }
      if (!window.confirm('Reset the password of ' + (kind === 'p' ? 'the parent of ' : 'teacher ') + id + '?\n\nThe new password will be the mobile number.')) return;
      b.disabled = true; out.className = 'text-xs'; out.textContent = 'Working ...';
      return api('POST', 'cloud-setup/parent-reset/', { kind: kind, id: id }).then(function (j) {
        b.disabled = false; out.className = 'text-xs ' + (j.ok ? 'text-green-700' : 'text-red-600'); out.textContent = (j.ok ? '\u2713 ' + j.message : '\u2717 ' + (j.error || ('HTTP ' + j.status)));
      });
    }
    if (act === 'fetch') {
      if (!window.confirm(gid === 'papp' ? 'Send everything to the Parent App now?\n\nEvery student, login and teacher is written to Firebase again (about 2 writes per student). The first time it can take 10-15 minutes.' : gid === 'contacts' ? 'Send all contacts to Google now?\n\nEvery parent and teacher number is sent again. Contacts that are already in Google are only updated, not duplicated.' : gid === 'students' ? 'Send the student list now?\n\nThe list in the cloud is deleted and the list of students studying now is written in its place.' : 'Fetch all data from the cloud now?\n\nEverything the cloud has is brought into this ERP, also what came while this app was not connected. Nothing in the cloud is deleted; what the ERP already has is not duplicated.')) return;
      b.disabled = true; show(gid, [{ ok: true, message: 'Fetching ... (this can take a minute)' }]);
      return api('POST', 'cloud-setup/fetch/', { group: gid }).then(function (j) {
        if (!j.ok) { b.disabled = false; return show(gid, [{ ok: false, message: j.error || ('Could not start (HTTP ' + j.status + ').') }]); }
        var tries = 0;
        (function poll() {
          api('GET', 'cloud-setup/fetch/').then(function (r) {
            var f = (r.fetch || {})[gid] || {};
            if (f.state === 'running' && tries++ < 300) return setTimeout(poll, 2000);
            b.disabled = false;
            show(gid, [{ ok: f.state === 'done', message: f.state === 'done' ? 'Done. ' + f.text : f.state === 'error' ? 'Failed: ' + f.text : 'Still running in the background. Press again later to see the result.' }]);
          });
        })();
      });
    }
    var c = collect(gid); b.disabled = true;
    if (act === 'test') {
      show(gid, [{ ok: true, message: 'Testing ...' }]);
      api('POST', 'cloud-setup/test/', { group: gid, values: c.values }).then(function (j) { b.disabled = false; show(gid, j.results || [{ ok: false, message: 'The test could not run (HTTP ' + j.status + ').' }]); });
    } else {
      api('POST', 'cloud-setup/', { values: c.values, clear: c.clear }).then(function (j) {
        b.disabled = false;
        if (j.status === 400 && j.errors) return show(gid, Object.keys(j.errors).map(function (k) { return { ok: false, message: k + ': ' + j.errors[k] }; }));
        if (!j.groups) return show(gid, [{ ok: false, message: 'Could not save (HTTP ' + j.status + ').' }]);
        G = j.groups; draw();
        var g = G.filter(function (x) { return x.id === gid; })[0] || {};
        show(gid, [{ ok: true, message: 'Saved.' }]);
        note(g.running ? 'Saved. Connected and running now.' : 'Saved. It starts as soon as every required box is filled in.');
      });
    }
  });

  window.cloudFill = load;                       // called by masterTab('cloud') every time the tab is opened
})();
