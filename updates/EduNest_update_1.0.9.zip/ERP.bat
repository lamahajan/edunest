@echo off
title EduNest
cd /d "%~dp0"
set "PYEXE=venv\Scripts\python.exe"
if exist runtime\python.exe set "PYEXE=runtime\python.exe"
if not exist %PYEXE% (
  echo.
  echo  The program is not installed yet. Double-click setup.bat first.
  echo.
  pause
  exit /b 1
)
set PYTHONDONTWRITEBYTECODE=1
set "CTL=%PYEXE% tools\erpctl.py"

:menu
cls
echo.
echo    E D U N E S T
echo    ----------------------------------------------------------
echo     1   Start the server in this window  (keep it open)
echo     2   Restart the server
echo     3   Update the ERP to a new version
echo     4   Backup now
echo     5   Check the cloud connections
echo     6   Start by itself when the computer starts   (asks for permission)
echo     7   Stop starting by itself                    (asks for permission)
echo     8   Reset a user's password
echo     9   More ...   (status, export / import data, photos folder, trusted https, PostgreSQL)
echo     0   Close this menu
echo.
set "c="
set /p c="    Type a number and press Enter: "
if "%c%"=="1" call run_server.bat show
if "%c%"=="2" %CTL% restart
if "%c%"=="3" (
  %CTL% update
  echo.
  echo  Closing this menu: open ERP.bat again.  ^(The update replaced this file.^)
  pause
  exit
)
if "%c%"=="4" %CTL% backup
if "%c%"=="5" %CTL% cloud-check
if "%c%"=="6" %CTL% autostart-on
if "%c%"=="7" %CTL% autostart-off
if "%c%"=="8" %CTL% reset-password
if "%c%"=="9" goto more
if "%c%"=="0" exit /b 0
echo.
pause
goto menu

:more
cls
echo.
echo    M O R E
echo    ----------------------------------------------------------
echo     1   Status  (is the server running, how to open it)
echo     2   Export all data to a file (pen drive / another PC)
echo     3   Import data from a file   (REPLACES everything on this PC)
echo     4   Make a folder of photos and documents with proper names
echo     5   Set up trusted https (your own domain name)
echo     6   Move the data to PostgreSQL
echo     7   REMOVE the program from this computer  (a safety backup is saved first)
echo     0   Back
echo.
set "m="
set /p m="    Type a number and press Enter: "
if "%m%"=="1" %CTL% status
if "%m%"=="2" %CTL% export-data
if "%m%"=="3" %CTL% import-data
if "%m%"=="4" %CTL% organize-media
if "%m%"=="5" %CTL% setup-https
if "%m%"=="6" %CTL% to-postgres
if "%m%"=="7" (
  %CTL% uninstall
  echo.
  pause
  exit
)
if "%m%"=="0" goto menu
echo.
pause
goto more
