"""Automatic update over the internet. Runs every time the school server starts (tools/supervise.py) and from ERP.bat > Update.
1. asks  <update address>/latest.json  whether a newer EduNest exists (silently does nothing when offline),
2. downloads the update zip and CHECKS it: SHA-256 and the vendor's signature (Ed25519) - an unsigned or changed file is never installed,
3. keeps a copy of the current program files, runs tools/update.py (a data backup is made first), and puts the old files back if anything fails.
School data (data, backups folders) is never touched.  Switch off with  ERP_AUTOUPDATE=0  in data/config.env.
Exit codes: 0 updated | 10 already newest | 11 offline / not set up / switched off | 12 refused (signature, version) | 13 update failed (old version restored)."""
import base64
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import time
import urllib.request
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PUBLIC_KEY = 'GcSEuutH+tPFgZ0S4yVJobd5+PFySNwjarekAckO8tM='          # the vendor's public key: only updates signed with the matching private key are installed
THROTTLE_SECONDS = 600       # a server that restarts again and again asks the internet at most every 10 minutes
KEEP_DIRS = {'data', 'backups', 'venv', 'runtime', 'updates', 'imports', 'exports'}


def say(m):
    print(' [update] ' + m, flush=True)


def config():
    cfg = {}
    f = ROOT / 'data' / 'config.env'
    if f.exists():
        for line in f.read_text(encoding='utf-8-sig').splitlines():
            if '=' in line and not line.strip().startswith('#'):
                k, v = line.split('=', 1)
                cfg[k.strip()] = v.strip().strip('"').strip("'")
    cfg.update({k: v for k, v in os.environ.items() if k.startswith('ERP_')})
    return cfg


def version_tuple(text):
    m = re.search(r'\d+(?:\.\d+)*', text or '')
    return tuple(int(x) for x in m.group(0).split('.')) if m else (0,)


def current_version():
    f = ROOT / 'VERSION'
    return f.read_text().strip() if f.exists() else '0'


def _state_file():
    return ROOT / 'data' / 'autoupdate.json'


def load_state():
    try:
        return json.loads(_state_file().read_text())
    except (OSError, ValueError):
        return {}


def save_state(st):
    try:
        _state_file().parent.mkdir(exist_ok=True)
        _state_file().write_text(json.dumps(st, indent=1))
    except OSError:
        pass


def verify_signature(version, sha256, sig):
    from cryptography.exceptions import InvalidSignature
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
    try:
        Ed25519PublicKey.from_public_bytes(base64.b64decode(PUBLIC_KEY)).verify(base64.urlsafe_b64decode(sig + '=' * (-len(sig) % 4)), f'EduNestUpdate|{version}|{sha256}'.encode())
        return True
    except (InvalidSignature, ValueError, TypeError):
        return False


def fetch(url, timeout):
    req = urllib.request.Request(url, headers={'User-Agent': 'EduNest-updater'})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def snapshot(keep=2):
    """Zip of the current program files (not data) so a failed update can be undone."""
    d = ROOT / 'updates' / 'previous'
    d.mkdir(parents=True, exist_ok=True)
    z = d / f'before_{re.sub(r"[^0-9A-Za-z.-]", "_", current_version())}_{int(time.time())}.zip'
    with zipfile.ZipFile(z, 'w', zipfile.ZIP_DEFLATED) as zf:
        for item in ROOT.iterdir():
            if item.name in KEEP_DIRS:
                continue
            for p in ([item] if item.is_file() else item.rglob('*')):
                if p.is_file() and '__pycache__' not in p.parts:
                    zf.write(p, p.relative_to(ROOT).as_posix())
    olds = sorted(d.glob('before_*.zip'), key=lambda p: p.stat().st_mtime)
    for o in olds[:-keep]:
        o.unlink(missing_ok=True)
    return z


def restore(z):
    with zipfile.ZipFile(z) as zf:
        zf.extractall(ROOT)


def check(force=False):
    cfg = config()
    if cfg.get('ERP_AUTOUPDATE', '1') == '0' and not force:
        return 11
    base = (cfg.get('ERP_UPDATE_URL') or ((ROOT / 'update_source.txt').read_text().strip() if (ROOT / 'update_source.txt').exists() else '')).rstrip('/')
    if not base:
        if force:
            say('No update address is set for this copy of EduNest.')
        return 11
    st = load_state()
    if not force and time.time() - st.get('last_check', 0) < THROTTLE_SECONDS:
        return 11
    st['last_check'] = time.time()
    try:
        man = json.loads(fetch(base + '/latest.json', 8))
    except Exception as e:                                           # offline, DNS, 404 ...: never stop the server from starting
        st['last_result'] = 'offline'
        save_state(st)
        if force:
            say(f'Could not reach the update server ({type(e).__name__}). Check the internet and try again.')
        return 11
    new, cur = str(man.get('version', '')), current_version()
    if version_tuple(new) <= version_tuple(cur):
        st['last_result'] = 'up to date'
        save_state(st)
        if force:
            say(f'You already have the newest version ({cur}).')
        return 10
    if man.get('min_version') and version_tuple(cur) < version_tuple(man['min_version']):
        st['last_result'] = f'{new} needs a new installer'
        save_state(st)
        say(f'Version {new} is available, but it needs the new EduNest installer (Setup.exe). Please ask your vendor.')
        return 12
    if not force and st.get('failed', {}).get(new, 0) > time.time() - 86400:
        return 13
    say(f'New version {new} found (you have {cur}). Downloading ...')
    try:
        data = fetch(base + '/' + str(man['url']).lstrip('/'), 120)
    except Exception as e:
        say(f'Download failed ({type(e).__name__}); will try again later.')
        save_state(st)
        return 11
    sha = hashlib.sha256(data).hexdigest()
    if sha != man.get('sha256') or not verify_signature(new, sha, str(man.get('sig', ''))):
        say('The downloaded update is NOT genuine (checksum or signature does not match). It was NOT installed.')
        st['last_result'] = 'refused: bad signature'
        save_state(st)
        return 12
    zdir = ROOT / 'updates' / 'auto'
    zdir.mkdir(parents=True, exist_ok=True)
    z = zdir / f'EduNest_update_{new}.zip'
    z.write_bytes(data)
    say('Update verified. Installing (a backup of your data is made first) ...')
    snap = snapshot()
    rc = subprocess.run([sys.executable, str(ROOT / 'tools' / 'update.py'), '--auto', str(z)], cwd=str(ROOT)).returncode
    if rc:
        say('The update did not finish: putting the previous version back.')
        restore(snap)
        st.setdefault('failed', {})[new] = time.time()
        st['last_result'] = f'{new} failed, previous version restored'
        save_state(st)
        return 13
    z.unlink(missing_ok=True)
    st['last_result'] = f'updated to {new}'
    st['updated_at'] = time.time()
    save_state(st)
    say(f'Updated to {new}.')
    return 0


if __name__ == '__main__':
    sys.exit(check(force='--force' in sys.argv))
