"""Shrinks the Material Symbols icon font to the icons EduNest really uses (3.9 MB -> 35 KB).
RE-RUN THIS whenever a NEW icon name is used in the code, then save the result as backend/static/vendor/fonts/material-symbols-subset-N.woff2
(N = next number, so browsers fetch it again) and update backend/static/vendor/fonts.css.
Source font: npm package "material-symbols" (file material-symbols-outlined.woff2).
  python make_icon_font.py <project folder> <source.woff2> out.woff2
then pin the unused axes (28 KB smaller): open out.woff2 with fontTools, call
  fontTools.varLib.instancer.instantiateVariableFont(font, {'wght': 400, 'GRAD': 0, 'opsz': 24}, inplace=True), set font.flavor = 'woff2' and save.
"""
import re, sys, pathlib
from fontTools.ttLib import TTFont
from fontTools.varLib import instancer
from fontTools import subset

proj, src, dst = pathlib.Path(sys.argv[1]), sys.argv[2], sys.argv[3]
font = TTFont(src)
print('glyphs before:', len(font.getGlyphOrder()))
if '--pin' in sys.argv: instancer.instantiateVariableFont(font, {'wght': 400, 'GRAD': 0, 'opsz': 24}, inplace=True)
cmap = font.getBestCmap(); rev = {g: chr(c) for c, g in cmap.items() if c < 0x10000 and chr(c).isascii()}
# name -> ligature glyph
tables = []
for lk in font['GSUB'].table.LookupList.Lookup:
    for st in lk.SubTable:
        st = getattr(st, 'ExtSubTable', st)
        if hasattr(st, 'ligatures'):
            tables.append(st)
names = {}
for st in tables:
    for first, ligs in st.ligatures.items():
        for lg in ligs:
            if first in rev and all(c in rev for c in lg.Component):
                names[rev[first] + ''.join(rev[c] for c in lg.Component)] = lg.LigGlyph
print('icon names in the font:', len(names))
# every token of the code that is an icon name
used = set()
files = [p for p in list(proj.glob('frontend/*.html')) + list(proj.glob('backend/static/*.js')) + list(proj.glob('backend/ui_assets/*.html')) + list(proj.glob('backend/templates/*.html')) if p.is_file()]
for f in files:
    for tok in set(re.findall(r'[a-z][a-z0-9_]*', f.read_text(encoding='utf-8', errors='ignore'))):
        if tok in names:
            used.add(tok)
extra = pathlib.Path(__file__).with_name('extra_icons.txt')
if extra.exists():
    used |= {x.strip() for x in extra.read_text().split() if x.strip() in names}
print('icon names used by EduNest:', len(used))
keep_glyphs = {names[n] for n in used}
letters = sorted({c for n in used for c in n})
# remove every ligature rule that is not needed, then subset
for st in tables:
    for first in list(st.ligatures):
        st.ligatures[first] = [lg for lg in st.ligatures[first] if rev.get(first, '?') + ''.join(rev.get(c, '?') for c in lg.Component) in used]
        if not st.ligatures[first]:
            del st.ligatures[first]
opts = subset.Options()
opts.layout_features = ['rlig', 'rclt']; opts.name_IDs = []; opts.hinting = False; opts.notdef_outline = True; opts.flavor = 'woff2'; opts.glyph_names = False
opts.drop_tables += ['STAT', 'GDEF'] if False else []
sub = subset.Subsetter(opts)
sub.populate(unicodes=[ord(c) for c in letters], glyphs=sorted(keep_glyphs))
sub.subset(font)
font.flavor = 'woff2'
font.save(dst)
print('glyphs after:', len(font.getGlyphOrder()), '| size:', pathlib.Path(dst).stat().st_size // 1024, 'KB')
open(pathlib.Path(dst).with_suffix('.names.txt'), 'w').write('\n'.join(sorted(used)))
