@echo off
cd /d "%~dp0.."
call npx --yes tailwindcss@3.4.17 -c tools\tailwind.config.js -i tools\tw_in.css -o backend\static\vendor\app.css --minify
pause
