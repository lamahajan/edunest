@echo off
title EduNest - first time setup
cd /d "%~dp0"
if exist runtime\python.exe goto :bundled
python --version >nul 2>&1
if errorlevel 1 (
  echo.
  echo  Python is not installed on this computer.
  echo  1. Open https://www.python.org/downloads/  and install "Python 3.12" ^(64-bit^)
  echo  2. IMPORTANT: tick "Add python.exe to PATH" on the first install screen
  echo  3. Then double-click setup.bat again
  echo.
  pause
  exit /b 1
)
python -c "import sys,struct; sys.exit(0 if ((3,10)<=sys.version_info[:2]<=(3,13) and struct.calcsize('P')==8) else 1)"
if errorlevel 1 (
  echo.
  echo  WARNING: this is not the recommended Python ^(64-bit Python 3.12^). Some parts may fail to install.
  echo  Best: install "Python 3.12 64-bit" from python.org, then run setup.bat again.
  echo  Press any key to try anyway, or close this window to stop.
  pause
)
set PYTHONDONTWRITEBYTECODE=1
if not exist venv python -m venv venv
call venv\Scripts\activate
cd backend
python -m pip install --no-compile --upgrade pip
pip install --no-compile -r requirements.txt
if errorlevel 1 (
  echo.
  echo  Installation failed. Please check the internet connection and run setup.bat again.
  echo  If it still fails, send a photo of this window.
  pause
  exit /b 1
)
set USEPG=0
if exist "..\data\config.env" findstr /b /c:"POSTGRES_DB" "..\data\config.env" >nul 2>&1 && set USEPG=1
if "%USEPG%"=="1" (
  echo  PostgreSQL is selected in data\config.env - installing its driver ...
  pip install --no-compile -r requirements-postgres.txt
  if errorlevel 1 pip install --no-compile psycopg
  python -c "import psycopg" >nul 2>&1
  if errorlevel 1 (
    echo.
    echo  The PostgreSQL driver could not be installed. Please read the PostgreSQL topic in HELP.html ^(Problem section^).
    pause
    exit /b 1
  )
)
set USEHTTPS=0
if exist "..\data\config.env" findstr /b /c:"ERP_DOMAIN" "..\data\config.env" >nul 2>&1 && set USEHTTPS=1
if "%USEHTTPS%"=="1" pip install --no-compile -r requirements-https.txt
python ..\tools\slim_venv.py
python manage.py migrate
if errorlevel 1 (
  echo.
  echo  The database could not be prepared. If you use PostgreSQL, check data\config.env and that PostgreSQL is running.
  pause
  exit /b 1
)
python build_frontend.py
set DJANGO_DEBUG=0
python manage.py collectstatic --noinput
python manage.py make_cert
echo.
echo  ---- Creating the first login ----
python manage.py setup_school
echo.
echo  First login:  username  admin   password  admin123   ^(change the password after you sign in: profile menu, User Management^)
echo  Setup finished. Now double-click  ERP.bat ^(or the EduNest shortcut^)   ^(option 1 starts the server, option 6 starts it by itself whenever the computer starts^)
pause
goto :eof

:bundled
rem Installed with the EduNest installer: Python and every part are already in the 'runtime' folder.
set PYTHONDONTWRITEBYTECODE=1
set DJANGO_DEBUG=0
cd backend
..\runtime\python.exe manage.py migrate
if errorlevel 1 (
  echo.
  echo  The database could not be prepared. If you use PostgreSQL, check data\config.env and that PostgreSQL is running.
  pause
  exit /b 1
)
..\runtime\python.exe build_frontend.py
..\runtime\python.exe manage.py collectstatic --noinput
if errorlevel 1 (
  echo.
  echo  The screens could not be prepared ^(collectstatic failed^). Send a photo of this window.
  pause
  exit /b 1
)
..\runtime\python.exe manage.py make_cert
echo.
echo  ---- Creating the first login ----
..\runtime\python.exe manage.py setup_school
echo.
echo  First login:  username  admin   password  admin123   ^(the Welcome screen asks you for a new password^)
echo  Setup finished. Now open EduNest ^(Desktop shortcut or ERP.bat^): option 1 starts the server, option 6 starts it by itself whenever the computer starts.
if /i not "%~1"=="/silent" pause
exit /b 0
