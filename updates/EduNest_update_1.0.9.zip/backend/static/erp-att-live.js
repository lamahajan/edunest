/* Live attendance: biometric scans (eSSL AiFace -> cloud -> server) mark students Present in the ERP all morning.
   erp-sync.js announces each change as 'erp-att'. This script keeps the page's own copy of the attendance equal to the server's (so a later
   Save on this screen can never undo a scan) and, if the Attendance screen is open on "Mark", shows the new Present marks at once.
   It only ever fills an empty mark or turns Absent into Present (marks that come from the class roll call: also Absent into an empty box); whatever the teacher chose otherwise stays. */
(function () {
  'use strict';
  window.addEventListener('erp-att', function () {
    try {
      ATT = JSON.parse(localStorage.getItem('eacademics_att') || '{}') || {};
      var pg = document.getElementById('pageAttendance');
      if (typeof att === 'undefined' || !pg || pg.offsetParent === null || att.tab !== 'mark') return;
      var srv = ATT[attKey()] || {}, changed = false;
      // a student this teacher has NOT touched on this screen follows the server exactly (biometric scan, class roll call: Present, Absent, a Leave, or a cleared mark);
      // a student the teacher changed here keeps the teacher's choice until Save
      var dirty = att.dirty || {};
      (typeof attList === 'function' ? attList() : []).forEach(function (r) { var a = r.adm; if (dirty[a]) return; var v = srv[a] || ''; if ((att.marks[a] || '') !== v) { if (v) att.marks[a] = v; else delete att.marks[a]; changed = true; } });
      if (changed) attRender();
    } catch (e) { /* the page is not ready: nothing to refresh */ }
  });
})();
