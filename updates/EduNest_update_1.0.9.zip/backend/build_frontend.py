"""Builds templates/index.html from ../frontend/UI.html by wiring it to the Django API.
Every anchor must match exactly once, so a changed UI.html fails loudly instead of silently breaking."""
from pathlib import Path

from ui_additions import FEE_INCREASE_JS, ROLL_JS

ASSETS = Path(__file__).resolve().parent / 'ui_assets'
MOBILE_CSS = (ASSETS / 'mobile_layer.html').read_text(encoding='utf-8')
MOBILE_JS = (ASSETS / 'mobile_helpers.html').read_text(encoding='utf-8')
POLISH_CSS = (ASSETS / 'polish_layer.html').read_text(encoding='utf-8')

HERE = Path(__file__).resolve().parent
src = (HERE.parent / 'frontend' / 'UI.html').read_text(encoding='utf-8')

PATCHES = [
    # 1. shared-data layer runs first (bootstrap + write-through + live polling)
    ('<head>\n', '<head>\n  <script src="/static/erp-sync.js"></script>\n'),
    # 2. receipts come from the server (not the hard-coded samples) once the school is seeded
    ("    // sample receipts that do not fit a saved non-monthly plan are dropped (receipts are not persisted in this demo)\n",
     "    if (window.ERP && ERP.boot.seeded) { RC_RECEIPTS.length = 0; ERP.boot.receipts.filter(x => x.session === SESS).forEach(x => RC_RECEIPTS.push(Object.assign({}, x.data, { _sid: x.id, _ver: x.version }))); }\n"
     "    // sample receipts that do not fit a saved non-monthly plan are dropped (receipts are not persisted in this demo)\n"),
    # 3. do not resurrect the sample students after every admission was deleted
    ("    if (!ADM.length) ADM = Object.entries(RC_STUDENTS)", "    if (!ADM.length && !(window.ERP && ERP.boot.seeded)) ADM = Object.entries(RC_STUDENTS)"),
    # 4. save / modify / cancel a receipt -> server (rolls back locally if the server refuses)
    ("      else { RC_RECEIPTS[rc.idx] = rec; showToast(`Voucher #${rec.v} updated`); }\n      const wasNew = rc.mode === 'new';\n",
     "      else { rec._sid = RC_RECEIPTS[rc.idx]._sid; rec._ver = RC_RECEIPTS[rc.idx]._ver; Object.defineProperty(rec, '_prev', { value: RC_RECEIPTS[rc.idx], enumerable: false }); RC_RECEIPTS[rc.idx] = rec; showToast(`Voucher #${rec.v} updated`); }\n"
     "      const wasNew = rc.mode === 'new';\n      if (window.ERP) ERP.pushReceipt(rec, wasNew);\n"),
    # 5. delete a receipt -> server (number becomes reusable)
    ("RC_RECEIPTS.splice(at, 1); rcCloseOverlay();", "if (window.ERP) ERP.removeReceipt(r); RC_RECEIPTS.splice(at, 1); rcCloseOverlay();"),
    # 6a. one sign-in: the server login signs the person into the app (no second login screen, no default accounts)
    ("      const u = USERS.find(x => x.id === id && x.active);\n      if (u) usrEnter(u, false); else usrLoginShow('');",
     "      const u = window.ERP ? USERS.find(x => String(x.username).toLowerCase() === ERP.user && x.active !== false) : USERS.find(x => x.id === id && x.active);\n      if (u) usrEnter(u, false); else if (window.ERP) { showToast('Your account was not found. Please sign in again.'); setTimeout(() => ERP.signOut(), 1500); } else usrLoginShow('');"),
    ("profileDropdown.classList.add('hidden'); usrLoginShow('');", "profileDropdown.classList.add('hidden'); if (window.ERP) return ERP.signOut(); usrLoginShow('');"),
    ("async function usrSeed() {\n      if (USERS.length) return;", "async function usrSeed() {\n      if (USERS.length || window.ERP) return;"),
    # 6. stoppage fees belong to a session (so a fee increase never changes the old session)
    ("'acad', 'classes', 'rp_openbal']", "'acad', 'classes', 'rp_openbal', 'stops']"),
    # 7. fee increase card + its effect when the session is closed
    ('        <div class="mx-card"><div class="rc-card-title mb-3"><span class="material-symbols-outlined">groups</span>Students by class</div>',
     '        ${prIncCard(Y)}\n        <div class="mx-card"><div class="rc-card-title mb-3"><span class="material-symbols-outlined">groups</span>Students by class</div>'),
    ('    function prSet(adm, k, v)', FEE_INCREASE_JS + '    function prSet(adm, k, v)'),
    ('writes.adm = JSON.stringify(newAdm); writes.classes = JSON.stringify(newCls);', 'writes.adm = JSON.stringify(newAdm); writes.classes = JSON.stringify(newCls); Object.assign(writes, prIncWrites());'),
    # 8. Setup > Classes: rearrange roll numbers
    ('<div id="clsRows" class="flex flex-col gap-2"></div>', '<div id="clsRows" class="flex flex-col gap-2"></div>\n        <div id="clsRollBox" class="mt-5 rounded-2xl border border-[#e0e3e7] dark:border-[#3c4043] p-4"></div>'),
    ("document.getElementById('clsCount').textContent = clsDraft.length + ' class' + (clsDraft.length === 1 ? '' : 'es');", "document.getElementById('clsCount').textContent = clsDraft.length + ' class' + (clsDraft.length === 1 ? '' : 'es'); clsRollRender();"),
    ('    function clsAdd() {', ROLL_JS + '    function clsAdd() {'),
    # 9. printing: every document gets a built-in 10 mm margin whatever the browser's Margins setting is (gate pass and the 2-up/B&W receipt designs keep their own layout)
    ("    #printArea{display:none}\n    @media print{\n      body>*:not(#printArea){display:none!important}\n      #printArea{display:block!important;color:#000}",
     "    @page{margin:0}\n    #printArea{display:none}\n    @media print{\n      body>*:not(#printArea){display:none!important}\n      #printArea{display:block!important;color:#000}\n      #printArea:not([data-nopad]){padding:10mm;box-sizing:border-box}\n      #printArea:not([data-nopad])>*{max-width:100%}"),
    ("(land ? 'landscape' : 'portrait') + ';margin:10mm}'", "(land ? 'landscape' : 'portrait') + ';margin:0}'"),
    ("window.addEventListener('afterprint', () => pg.remove(), { once: true })", "rcEl('printArea').setAttribute('data-nopad', '1'); window.addEventListener('afterprint', () => { pg.remove(); rcEl('printArea').removeAttribute('data-nopad'); }, { once: true })"),
    ("      rcEl('printArea').innerHTML = html;\n      const st = document.createElement('style'); st.textContent = '@page{' + page + '}#printArea>div:last-child{page-break-after:auto!important}'; document.head.appendChild(st);\n      const old = document.title; document.title = title; window.addEventListener('afterprint', () => { st.remove(); document.title = old; }, { once: true });",
     "      rcEl('printArea').innerHTML = html; rcEl('printArea').setAttribute('data-nopad', '1');\n      const st = document.createElement('style'); st.textContent = '@page{' + page + '}#printArea>div:last-child{page-break-after:auto!important}'; document.head.appendChild(st);\n      const old = document.title; document.title = title; window.addEventListener('afterprint', () => { st.remove(); document.title = old; rcEl('printArea').removeAttribute('data-nopad'); }, { once: true });"),
    # 10. gate pass: gate-out is marked elsewhere, so the button is removed here
    ("<button class=\"rc-btn\" onclick=\"gpGateOut('${e.id}')\"><span class=\"material-symbols-outlined\">${gpOut(e) ? 'undo' : 'logout'}</span>${gpOut(e) ? 'Clear Gate Out' : 'Gate Out'}</button>", ""),
    # 11. a concession voucher is "consumed" only when the receipt is SAVED (applying it just puts it on the receipt being made)
    ("x.usedP[p] = 'pending'; });", "});"),
    ("        if ((x.ps || []).every(p => x.usedP[p])) { x.used = true; x.usedAt = rcToday(); }\n        crSave(); rcCloseOverlay(); rcRender(); return showToast('Concession of ' + rcInr(sum)", "        rcCloseOverlay(); rcRender(); return showToast('Concession of ' + rcInr(sum)"),
    ("      if (rc.extra.some(e => e.cr === x.id)) return showToast('This concession is already on the receipt');\n      rc.extra.push({ name: 'Concession: ' + (x.head || 'Late fee') + ' (' + x.id + ')', amt: -Math.abs(x.apprAmt) }); x.used = true; x.usedAt = rcToday(); crSave(); rcCloseOverlay();",
     "      if (rc.extra.some(e => e.cr === x.id || (e.name || '').includes('(' + x.id + ')'))) return showToast('This concession is already on the receipt');\n      rc.extra.push({ name: 'Concession: ' + (x.head || 'Late fee') + ' (' + x.id + ')', amt: -Math.abs(x.apprAmt) }); rcCloseOverlay();"),
    ("const L = CR.filter(x => x.adm === rc.adm && !x.used).slice().reverse();", "const L = CR.filter(x => x.adm === rc.adm && !x.used && (x.kind === 'month' || !rc.extra.some(e => (e.name || '').includes('(' + x.id + ')')))).slice().reverse();"),
    ("q = m && CR.find(c => c.id === m[1]); if (q && q.used) { q.rno = rec.rno; q.usedAt = rec.date; } });", "q = m && CR.find(c => c.id === m[1]); if (q && q.kind !== 'month' && !x.ax) { q.used = true; q.rno = rec.rno; q.usedAt = rec.date; } else if (q && q.used) { q.rno = rec.rno; q.usedAt = rec.date; } });"),
    # 12. dues: money still owed on a part-paid receipt stays in the dues (and makes the student a defaulter once the month is overdue)
    ("      return { per, od: per.filter(i => RC_PERIODS[i][7] < asOn), items, total: items.reduce((t, x) => t + x[1], 0) };",
     "      const od = per.filter(i => RC_PERIODS[i][7] < asOn); let short = 0;\n      RC_RECEIPTS.forEach(r => { if (r.adm !== adm || r.cancelled) return; const c = rcCalc(adm, new Set(r.periods), r.recv, r.extra); if (Math.abs(c.bal) > 0.004) { short += c.bal; if (c.bal > 0) r.periods.forEach(p => { if (RC_PERIODS[p] && RC_PERIODS[p][7] < asOn && !od.includes(p)) od.push(p); }); } });\n      return { per, od, items, total: items.reduce((t, x) => t + x[1], 0) };"),
    # 10b. same in the gate pass list rows
    ("<button class=\"rc-tb\" title=\"${gpOut(e) ? 'Gate Out ' + e.outTime + ' - click to clear' : 'Record Gate Out'}\" onclick=\"gpGateOut('${e.id}')\"><span class=\"material-symbols-outlined\">${gpOut(e) ? 'check_circle' : 'logout'}</span></button> ", ""),
    # 13. mobile layer (3-column module tiles, full-width module menu, popups as bottom sheets, keyboard + notch handling) - taken from the reference google_mobile_dashboard.html
    ("    .dark .lf-item:hover{background:#2d2f31}.dark .lf-item.sel{background:#1a273b}.dark .lf-note{color:#9aa0a6}\n  </style>\n</head>\n",
     "    .dark .lf-item:hover{background:#2d2f31}.dark .lf-item.sel{background:#1a273b}.dark .lf-note{color:#9aa0a6}\n  </style>\n" + MOBILE_CSS + POLISH_CSS + "</head>\n"),
    ("    if (document.fonts && document.fonts.ready) document.fonts.ready.then(fitToViewport);\n</script>\n", "    if (document.fonts && document.fonts.ready) document.fonts.ready.then(fitToViewport);\n</script>\n" + MOBILE_JS),
    # 14. Manage Sessions: a clear way to the next year's fees from the top of the page
    ("promotes the students to the next class and starts ${esc2(Y.next)}.", "promotes the students to the next class and starts ${esc2(Y.next)}. <a href=\"#\" class=\"font-semibold text-[#0b57d0] dark:text-[#a8c7fa]\" onclick=\"document.getElementById('priCard').scrollIntoView({behavior:'smooth',block:'start'});return false\">Set the fees of ${esc2(Y.next)} &darr;</a>"),
    # 15. Manage Sessions: "Promote Session" button, choose which session to create, plan survives the dates shift
    ("const prYears = () => { const y = +String(FEEPLAN.sessStart || rcToday()).slice(0, 4); return { cur: y + '-' + (y + 1), next: (y + 1) + '-' + (y + 2), y }; };",
     "const prYears = () => { const y = +String(FEEPLAN.sessStart || rcToday()).slice(0, 4); let ty = PR.targetY; if (!ty || ty <= y) { ty = y + 1; while (ty < y + 4 && SESSIONS.some(x => x.id === ty + '-' + (ty + 1))) ty++; } return { cur: y + '-' + (y + 1), next: ty + '-' + (ty + 1), y, ty }; };"),
    ("(+v.slice(0, 4) + 1) + v.slice(4) : v); }", "(+v.slice(0, 4) + (prYears().ty - prYears().y)) + v.slice(4) : v); }"),
    ("<div class=\"mx-note\">New session</div><div class=\"text-lg font-bold text-amber-600 dark:text-amber-400\">${esc2(Y.next)}</div>", "<div class=\"mx-note\">Create session</div>${prTargetSelect(Y)}"),
    ("mxBtn('prRun()', 'event_repeat', 'Close ' + SESS + ' and start ' + Y.next, true)", "mxBtn('prRun()', 'event_repeat', 'Promote Session', true)"),
    ("rcConfirm('Close session ' + SESS + ' and start ' + Y.next + '?\\n\\n'", "rcConfirm('Promote session ' + SESS + ' to ' + Y.next + '?\\n\\n'"),
    ("Closing ${esc2(SESS)} promotes the students to the next class and starts ${esc2(Y.next)}.", "Promoting ${esc2(SESS)} moves the students to the next class and creates ${esc2(Y.next)}."),
    # 16. Users: the role list has no separate "Templates" group (edit kept from the school's copy of index.html)
    (" + (R.tpl.length ? `<optgroup label=\"Templates\">${R.tpl.map(o).join('')}</optgroup>` : '') + `<option ${umDraft.role === 'Custom'", " + `<option ${umDraft.role === 'Custom'"),
    # 17. Backup menu = the server backup (same zip as ERP.bat > Backup now), nothing is read from the browser any more
    ("showToast('Backup downloaded (' + b.n + ' data sets' + (b.certs ? ', ' + b.certs + ' saved certificates' : '') + ')');", "showToast('Backup saved on the server: ' + (b.saved || 'backups folder') + ' (a copy was also downloaded)' + (b.warn ? '. ' + b.warn : ''));"),
    ("it('download', 'Download backup file', 'appBackup()')", "it('download', 'Backup now (server + download)', 'appBackup()')"),
    ("{ method: 'PUT', headers: Object.assign({ 'Content-Type': 'application/json' }, H), body: b.blob }", "{ method: 'PUT', headers: Object.assign({ 'Content-Type': 'application/zip' }, H), body: b.blob }"),
    # 18. User Management: no built-in templates. New users start as Custom; picking an existing role copies the rights of a user who has it.
    ("role: 'Front Desk', active: true, perm: USR_ROLES['Front Desk'](), reports: null };", "role: 'Custom', active: true, perm: {}, reports: null };"),
    ("umDraft.perm = USR_ROLES[r] ? USR_ROLES[r]() : peer ? JSON.parse(JSON.stringify(peer.perm || {})) : umDraft.perm;", "umDraft.perm = peer ? JSON.parse(JSON.stringify(peer.perm || {})) : USR_ROLES[r] ? USR_ROLES[r]() : umDraft.perm;"),
    # N+1. Setup > School Setup > "Cloud Sync" tab (administrators), filled in by static/erp-cloud-setup.js
    ("<button id=\"mTab-messaging\" class=\"rc-tab\" onclick=\"masterTab('messaging')\">Telegram, WhatsApp &amp; Wix</button>\n",
     "<button id=\"mTab-messaging\" class=\"rc-tab\" onclick=\"masterTab('messaging')\">Telegram, WhatsApp &amp; Wix</button>\n"
     "        <button id=\"mTab-cloud\" class=\"rc-tab\" onclick=\"masterTab('cloud')\">Cloud Sync</button>\n"),
    ('      <div id="mPanel-messaging" class="hidden flex-1 min-h-0 overflow-y-auto px-6 py-5">',
     '      <div id="mPanel-cloud" class="hidden flex-1 min-h-0 overflow-y-auto px-6 py-5">\n'
     '        <p class="text-xs text-gray-500 dark:text-gray-400 mb-3">Connect the cloud apps (eGateSys, Result portal, online fee, attendance) to this ERP. Fill a card, press <b>Test</b>, then <b>Save</b>: it starts working at once. <b>Disconnect</b> stops it and forgets its settings (nothing in the cloud app is deleted). A secret is never shown again after saving; leave its box empty to keep the saved one. Administrator only.</p>\n'
     '        <p id="cloudSetupNote" class="text-xs min-h-[1rem] mb-2"></p>\n'
     '        <div id="cloudSetupBody" class="flex flex-col gap-4"></div>\n'
     '      </div>\n'
     '      <div id="mPanel-messaging" class="hidden flex-1 min-h-0 overflow-y-auto px-6 py-5">'),
    ("'messaging', 'printing'].forEach(k => { document.getElementById('mTab-' + k).style.display",
     "'messaging', 'printing', 'cloud'].forEach(k => { document.getElementById('mTab-' + k).style.display"),
    ("'messaging', 'printing'].forEach(k => { document.getElementById('mTab-' + k).classList.toggle('active', k === t);",
     "'messaging', 'printing', 'cloud'].forEach(k => { document.getElementById('mTab-' + k).classList.toggle('active', k === t);"),
    ("      if (t === 'messaging') msgFill();\n",
     "      if (t === 'messaging') msgFill();\n      if (t === 'cloud') window.cloudFill();\n      if (t === 'school' && window.bkFolderFill) window.bkFolderFill();\n"),
    ("'teachers', 'messaging'].includes(t);", "'teachers', 'messaging', 'cloud'].includes(t);"),
    ("tabs: ['school', 'printing', 'messaging'] },", "tabs: ['school', 'printing', 'messaging', 'cloud'] },"),
    ("sub: 'School details, logo, signatures, printing, Telegram, WhatsApp (Meta) and Wix messaging',",
     "sub: 'School details, logo, signatures, printing, Telegram, WhatsApp (Meta), Wix and cloud sync',"),
    # N+2. Gate pass: no more "delete allowed for N minutes after Gate Out" setting. Rule: once Gate Out is recorded only users with "Delete a gate pass at any time" can delete it.
    ('Once Gate Out is recorded, it can be deleted only within this many minutes after the Gate Out time. Users with <b>Delete a gate pass at any time</b> (User Management) have no limit.</p>\n'
     '          <div class="mf" style="max-width:14rem"><label>Delete allowed after Gate Out for (minutes)</label><input id="gptDelMin" type="number" min="0" max="1440" onchange="gpCfgDel(this.value)"></div>\n',
     'Once Gate Out is recorded, only a user with <b>Delete a gate pass at any time</b> (User Management) can delete it.</p>\n'),
    ("{ const lim = Math.max(0, +GPC.delMin || 0); if (gpOutAgeMin(e) > lim) return showToast('Gate Out was recorded at ' + e.outTime + ' (more than ' + lim + ' minute' + (lim === 1 ? '' : 's') + ' ago). Only a user",
     "{ return showToast('Gate Out was recorded at ' + e.outTime + '. Only a user"),
    ("rcEl('gptDelMin').value = GPC.delMin == null ? 30 : GPC.delMin; ", ""),
    ("    function gpCfgDel(v) { GPC.delMin = Math.max(0, Math.min(1440, +v || 0)); try { localStorage.setItem('eacademics_gp_cfg', JSON.stringify(GPC)); } catch (e) {} showToast('Saved'); }\n", ""),
    ("    const gpOutAgeMin = e => { const t = e.outTs || Date.parse((e.date || '') + 'T' + (e.outTime || '00:00') + ':00'); return isNaN(t) ? 0 : (Date.now() - t) / 60000; };\n", ""),
    # N+3. Setup > School Setup > school tab: "Backup folder" card (before the OneDrive backup card), filled in by static/erp-backup-folder.js
    ('        <div class="rc-card-title mt-8"><span class="material-symbols-outlined">cloud_upload</span>OneDrive backup</div>',
     '        <div class="rc-card-title mt-8"><span class="material-symbols-outlined">folder_zip</span>Backup folder (this server)</div>\n'
     '        <p class="text-xs text-gray-500 dark:text-gray-400 mb-3">Where the server keeps its backups (profile menu &gt; Backup, and <b>Backup now</b> below). Use a folder on another drive or a pen drive, for example <b>D:\\ERP-Backups</b>. If that folder cannot be used when a backup runs (pen drive not plugged in), the backup is still saved in the program\'s own folder, and you are told. Administrator only.</p>\n'
     '        <div class="mf"><label>Backup folder (full path)</label><input id="bkDir" type="text" autocomplete="off" placeholder="empty = the program\'s own backups folder"></div>\n'
     '        <div class="flex flex-wrap gap-2 mt-2"><button type="button" class="rc-btn" onclick="bkFolderAct(\'test\')">Test</button><button type="button" class="rc-btn rc-btn-primary" onclick="bkFolderAct(\'save\')">Save</button><button type="button" class="rc-btn" onclick="bkFolderAct(\'now\')">Backup now</button></div>\n'
     '        <p id="bkDirInfo" class="text-xs mt-2"></p>\n'
     '        <div class="rc-card-title mt-8"><span class="material-symbols-outlined">cloud_upload</span>OneDrive backup</div>'),
    # N+5. Mark Entry: a "Bulk tools" button (fill / paste from Excel / clear), logic in static/erp-marks-bulk.js
    ('<button type="button" id="meSaveBtn" class="rc-btn rc-btn-primary hidden" onclick="meSave()">',
     '<button type="button" id="meBulkBtn" class="rc-btn hidden" onclick="meBulkOpen()" title="Fill, paste from Excel, clear"><span class="material-symbols-outlined">dataset</span>Bulk tools</button>\n'
     '              <button type="button" id="meSaveBtn" class="rc-btn rc-btn-primary hidden" onclick="meSave()">'),
    ("      meEl('meSaveBtn').classList.remove('hidden');\n", "      meEl('meSaveBtn').classList.remove('hidden'); meEl('meBulkBtn').classList.remove('hidden');\n"),
    # N+6. Save: a box that was emptied really removes that subject's mark (before, the old mark came back when the student still had other marks)
    ("          const o = {}; S.subs.forEach((x, j) => { const v = String(r.vals[j]).trim().toUpperCase(); if (v !== '') o[x.name] = v === 'AB' ? 'AB' : Number(v); });\n"
     "          if (Object.keys(o).length) c[r.adm] = { ...(c[r.adm] || {}), ...o }; else delete c[r.adm];\n",
     "          const cur = { ...(c[r.adm] || {}) }; S.subs.forEach((x, j) => { const v = String(r.vals[j]).trim().toUpperCase(); if (v === '') delete cur[x.name]; else cur[x.name] = v === 'AB' ? 'AB' : Number(v); });\n"
     "          if (Object.keys(cur).length) c[r.adm] = cur; else delete c[r.adm];\n"),
    # N+7. Setup > School Setup: "Module icons" + "Form style" options (saved on the server like every other setting)
    ('          <div class="mf col-span-6 sm:col-span-3"><label>Authorised Signatory (name / designation)</label><input id="scSignName" autocomplete="off" placeholder="e.g. Accountant"></div>',
     '          <div class="mf col-span-6 sm:col-span-3"><label>Authorised Signatory (name / designation)</label><input id="scSignName" autocomplete="off" placeholder="e.g. Accountant"></div>\n'
     '          <div class="col-span-6 mt-2"><div class="rc-card-title"><span class="material-symbols-outlined">palette</span>Look &amp; feel (this server)</div><p class="text-xs text-gray-500 dark:text-gray-400 mt-1">Applies to everyone using this ERP, immediately. On hover the dashboard card border always turns softly to the icon colour.</p></div>\n'
     '          <div class="mf col-span-6 sm:col-span-3"><label>Dashboard module icons</label><select id="icfSel" onchange="icfSet(this.value)"><option value="0">Original (light box, coloured icon)</option><option value="1">Filled on hover (dark colour box, white icon)</option><option value="2">Always filled (dark colour box, white icon)</option></select></div>\n'
     '          <div class="mf col-span-6 sm:col-span-3"><label>Form style (input boxes)</label><select id="fsSel" onchange="fsSet(this.value)"><option value="0">Original (sharp outlined boxes)</option><option value="1">Soft (tinted boxes, light border, easier on eyes)</option><option value="2">Soft &amp; roomy (soft + taller boxes, larger text)</option><option value="3">Underline (minimal, only a line under the text)</option><option value="4">Warm paper (cream boxes, low glare for long use)</option><option value="5">Large &amp; clear (big text, thick border)</option><option value="6">Compact (small boxes, more fields on screen)</option></select></div>'),
    ("if (t === 'school' && window.bkFolderFill) window.bkFolderFill();", "if (t === 'school' && window.bkFolderFill) window.bkFolderFill();\n      if (t === 'school' && window.icfFill) window.icfFill();"),
    # N+8. Fully offline: compiled Tailwind CSS + local fonts + local pdf.js (no CDN needed on a school LAN without internet)
    ('  <script src="https://cdn.tailwindcss.com"></script>', '  <link rel="stylesheet" href="/static/vendor/app.css">'),
    ('  <link rel="preconnect" href="https://fonts.googleapis.com">', ''),
    ('  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>', ''),
    ('  <link href="https://fonts.googleapis.com/css2?family=Google+Sans:wght@400;500;600;700&family=Roboto:wght@300;400;500;700&family=Inter:wght@400;500;600;700;800&family=Montserrat:wght@400;700;800&family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200&display=swap" rel="stylesheet" />', '  <link rel="stylesheet" href="/static/vendor/fonts.css">'),
    ('tailwind.config = {', 'window.__twcfg = {'),
    ('<link rel="preconnect" href="https://fonts.googleapis.com"><link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">', '<link rel="stylesheet" href="${location.origin}/static/vendor/fonts.css">'),
    ("sc.src = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js';", "sc.src = '/static/vendor/pdfjs/pdf.min.js';"),
    ("workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';", "workerSrc = '/static/vendor/pdfjs/pdf.worker.min.js';"),
    # N+9. Setup > School Setup > Look & feel: should students who LEFT the school be shown in Fee Receipt / Mark Entry / other lists? (Admission list and Withdrawal register always show them)
    ('Compact (small boxes, more fields on screen)</option></select></div>',
     'Compact (small boxes, more fields on screen)</option></select></div>\n'
     '          <div class="mf col-span-6"><label>Students who left school</label><select id="shlSel" onchange="shlSet(this.value)"><option value="0">Hide them in Fee Receipt, Mark Entry and other lists (the Admission list and Withdrawal register always show them)</option><option value="1">Show them everywhere (to look at an old record)</option></select></div>'),
    # N+10. Browser tab icon (EduNest mark)
    ('<title>EduNest</title>', '<title>EduNest</title>\n  <link rel="icon" type="image/png" href="/static/vendor/favicon.png">'),
]
src = src.replace('location.reload()', 'ERP.reload()')   # flush unsaved writes to the server first
for old, new in PATCHES:
    assert src.count(old) == 1, f'anchor found {src.count(old)}x (expected 1): {old[:70]!r}'
    src = src.replace(old, new)

BACKUP_FN = """    async function appBackupBuild() {   // the backup is made by the server: database + photos in one zip, also kept in the server's "backups" folder
      const r = await fetch('/api/sync/backup/', { method: 'POST', headers: { Authorization: 'Token ' + localStorage.getItem('erp_token') } });
      if (r.status === 403) throw new Error('only the Administrator can take a backup');
      if (!r.ok) { let m = ''; try { m = (await r.json()).error; } catch (e) {} throw new Error(m || ('the server said ' + r.status)); }
      const blob = await r.blob(), name = (/filename="?([^";]+)/.exec(r.headers.get('Content-Disposition') || '') || [])[1] || 'school_backup.zip';
      return { blob, name, n: 0, certs: 0, saved: r.headers.get('X-Backup-Saved') || '', warn: r.headers.get('X-Backup-Warning') || '' };
    }
"""
DOCTX = """    // Saved certificates are kept on the server (not in this browser's IndexedDB), so every PC sees them and backups contain them.
    const docTx = async (st, mode, fn) => {
      const op = {}, rq = { result: undefined }, key = st === 'docs' ? 'id' : 'k', base = st === 'docs' ? 'docs/' : 'assets/';
      fn({ put: o => { op.m = 'PUT'; op.o = o; return rq; }, get: id => { op.m = 'GET'; op.id = id; return rq; }, getAll: () => { op.m = 'ALL'; return rq; }, delete: id => { op.m = 'DEL'; op.id = id; return rq; } });
      if (op.m === 'PUT') { const r = await ERP.send('PUT', base + encodeURIComponent(op.o[key]) + '/', op.o); if (!r.ok) throw new Error('the server could not save it (' + r.status + ')'); return op.o[key]; }
      if (op.m === 'GET') { const r = await ERP.api('GET', base + encodeURIComponent(op.id) + '/'); return r.ok ? r.body : undefined; }
      if (op.m === 'ALL') { const r = await ERP.api('GET', base); return r.ok ? r.body : []; }
      if (op.m === 'DEL') { await ERP.api('DELETE', base + encodeURIComponent(op.id) + '/'); return undefined; }
    };
"""
RANGES = [
    ("    async function appBackupBuild() {\n", "certs: idb ? idb.docs.length : 0 };\n    }\n", BACKUP_FN),
    ("    let DOCDBP = null;\n", "t.onabort = () => rej(t.error); }); };\n", DOCTX),
]
for start, end, new in RANGES:
    i = src.index(start); assert src.count(start) == 1, start[:40]
    j = src.index(end, i) + len(end)
    src = src[:i] + new + src[j:]
(HERE / 'templates').mkdir(exist_ok=True)
(HERE / 'templates' / 'index.html').write_text(src, encoding='utf-8')
print('built templates/index.html', len(src) // 1024, 'KB')
